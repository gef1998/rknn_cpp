// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let IbvsConstrainedGoal = require('../msg/IbvsConstrainedGoal.js');
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class IplusPerceptionReqRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.mode = null;
      this.perception_keys = null;
      this.perception_types = null;
      this.cMe_map_keys = null;
      this.cMe_map_values = null;
      this.vs_goal = null;
      this.json_string = null;
      this.int_reserve = null;
      this.double_reserve = null;
      this.string_reserve = null;
      this.pose_reserve = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = 0;
      }
      if (initObj.hasOwnProperty('perception_keys')) {
        this.perception_keys = initObj.perception_keys
      }
      else {
        this.perception_keys = [];
      }
      if (initObj.hasOwnProperty('perception_types')) {
        this.perception_types = initObj.perception_types
      }
      else {
        this.perception_types = [];
      }
      if (initObj.hasOwnProperty('cMe_map_keys')) {
        this.cMe_map_keys = initObj.cMe_map_keys
      }
      else {
        this.cMe_map_keys = [];
      }
      if (initObj.hasOwnProperty('cMe_map_values')) {
        this.cMe_map_values = initObj.cMe_map_values
      }
      else {
        this.cMe_map_values = [];
      }
      if (initObj.hasOwnProperty('vs_goal')) {
        this.vs_goal = initObj.vs_goal
      }
      else {
        this.vs_goal = new IbvsConstrainedGoal();
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
      if (initObj.hasOwnProperty('int_reserve')) {
        this.int_reserve = initObj.int_reserve
      }
      else {
        this.int_reserve = [];
      }
      if (initObj.hasOwnProperty('double_reserve')) {
        this.double_reserve = initObj.double_reserve
      }
      else {
        this.double_reserve = [];
      }
      if (initObj.hasOwnProperty('string_reserve')) {
        this.string_reserve = initObj.string_reserve
      }
      else {
        this.string_reserve = [];
      }
      if (initObj.hasOwnProperty('pose_reserve')) {
        this.pose_reserve = initObj.pose_reserve
      }
      else {
        this.pose_reserve = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IplusPerceptionReqRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [mode]
    bufferOffset = _serializer.uint8(obj.mode, buffer, bufferOffset);
    // Serialize message field [perception_keys]
    bufferOffset = _arraySerializer.string(obj.perception_keys, buffer, bufferOffset, null);
    // Serialize message field [perception_types]
    bufferOffset = _arraySerializer.string(obj.perception_types, buffer, bufferOffset, null);
    // Serialize message field [cMe_map_keys]
    bufferOffset = _arraySerializer.string(obj.cMe_map_keys, buffer, bufferOffset, null);
    // Serialize message field [cMe_map_values]
    // Serialize the length for message field [cMe_map_values]
    bufferOffset = _serializer.uint32(obj.cMe_map_values.length, buffer, bufferOffset);
    obj.cMe_map_values.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [vs_goal]
    bufferOffset = IbvsConstrainedGoal.serialize(obj.vs_goal, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    // Serialize message field [int_reserve]
    bufferOffset = _arraySerializer.int32(obj.int_reserve, buffer, bufferOffset, null);
    // Serialize message field [double_reserve]
    bufferOffset = _arraySerializer.float64(obj.double_reserve, buffer, bufferOffset, null);
    // Serialize message field [string_reserve]
    bufferOffset = _arraySerializer.string(obj.string_reserve, buffer, bufferOffset, null);
    // Serialize message field [pose_reserve]
    // Serialize the length for message field [pose_reserve]
    bufferOffset = _serializer.uint32(obj.pose_reserve.length, buffer, bufferOffset);
    obj.pose_reserve.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IplusPerceptionReqRequest
    let len;
    let data = new IplusPerceptionReqRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [mode]
    data.mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [perception_keys]
    data.perception_keys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [perception_types]
    data.perception_types = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [cMe_map_keys]
    data.cMe_map_keys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [cMe_map_values]
    // Deserialize array length for message field [cMe_map_values]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.cMe_map_values = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.cMe_map_values[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [vs_goal]
    data.vs_goal = IbvsConstrainedGoal.deserialize(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [int_reserve]
    data.int_reserve = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [double_reserve]
    data.double_reserve = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [string_reserve]
    data.string_reserve = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [pose_reserve]
    // Deserialize array length for message field [pose_reserve]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.pose_reserve = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.pose_reserve[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.perception_keys.forEach((val) => {
      length += 4 + val.length;
    });
    object.perception_types.forEach((val) => {
      length += 4 + val.length;
    });
    object.cMe_map_keys.forEach((val) => {
      length += 4 + val.length;
    });
    length += 56 * object.cMe_map_values.length;
    length += IbvsConstrainedGoal.getMessageSize(object.vs_goal);
    length += object.json_string.length;
    length += 4 * object.int_reserve.length;
    length += 8 * object.double_reserve.length;
    object.string_reserve.forEach((val) => {
      length += 4 + val.length;
    });
    length += 56 * object.pose_reserve.length;
    return length + 37;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/IplusPerceptionReqRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '29ed824082c5fc69e16fed3530b9ac94';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    uint8 mode
    uint8 PERCEPTION_START = 0
    uint8 PERCEPTION_STOP = 1
    
    
    string[] perception_keys
    
    string[] perception_types
    
    string[] cMe_map_keys
    geometry_msgs/Pose[] cMe_map_values
    
    visual_servo_msgs/IbvsConstrainedGoal vs_goal
    
    string json_string
    
    int32[] int_reserve
    float64[] double_reserve
    string[] string_reserve
    geometry_msgs/Pose[] pose_reserve
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: visual_servo_msgs/IbvsConstrainedGoal
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    #goal definition
    uint8 sensor_type
    uint8 CAMERA_SENSOR = 0
    uint8 LASER_SENSOR = 1
    uint8 ODOM_SENSOR = 2
    uint8 DUAL_CAMERA_SENSOR = 3
    uint8 MAP_FROM_TF_SENSOR = 4
    uint8 ODOM_FROM_TF_SENSOR = 5
    
    uint8 camera_type
    uint8 UP_CAMERA = 0
    uint8 DOWN_CAMERA = 1
    uint8 FRONT_CAMERA = 2
    uint8 tag_type
    uint8 SHELF_TAG = 0
    uint8 NORMAL_TAG = 1 
    uint8 FRONT_VIEW_TAG = 3
    uint8 vs_type
    uint8 TO_POINT = 0
    uint8 FOLLOW_LINE = 1
    uint8 THREE_STAGE_MOVE = 2
    uint8 STRAIGHT_LINE = 3
    uint8 ORIGINAL_PLACE_ROTATE = 4
    
    bool is_lateral_base
    
    bool useLessScan
    sensor_msgs/LaserScan templateScan
    geometry_msgs/Pose2D templateScan_baseInMap
    
    geometry_msgs/Pose ref_base2map
    sensor_msgs/Image left_image
    sensor_msgs/Image right_image
    
    geometry_msgs/Pose2D targetInWorld
    geometry_msgs/Pose targetInWorld_3d
    
    std_msgs/String reconfigure_json_string
    
    # for ICP
    float32[2] minCorner
    float32[2] maxCorner
    
    ================================================================================
    MSG: sensor_msgs/LaserScan
    # Single scan from a planar laser range-finder
    #
    # If you have another ranging device with different behavior (e.g. a sonar
    # array), please find or create a different message, since applications
    # will make fairly laser-specific assumptions about this data
    
    Header header            # timestamp in the header is the acquisition time of 
                             # the first ray in the scan.
                             #
                             # in frame frame_id, angles are measured around 
                             # the positive Z axis (counterclockwise, if Z is up)
                             # with zero angle being forward along the x axis
                             
    float32 angle_min        # start angle of the scan [rad]
    float32 angle_max        # end angle of the scan [rad]
    float32 angle_increment  # angular distance between measurements [rad]
    
    float32 time_increment   # time between measurements [seconds] - if your scanner
                             # is moving, this will be used in interpolating position
                             # of 3d points
    float32 scan_time        # time between scans [seconds]
    
    float32 range_min        # minimum range value [m]
    float32 range_max        # maximum range value [m]
    
    float32[] ranges         # range data [m] (Note: values < range_min or > range_max should be discarded)
    float32[] intensities    # intensity data [device-specific units].  If your
                             # device does not provide intensities, please leave
                             # the array empty.
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of cameara
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IplusPerceptionReqRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.mode !== undefined) {
      resolved.mode = msg.mode;
    }
    else {
      resolved.mode = 0
    }

    if (msg.perception_keys !== undefined) {
      resolved.perception_keys = msg.perception_keys;
    }
    else {
      resolved.perception_keys = []
    }

    if (msg.perception_types !== undefined) {
      resolved.perception_types = msg.perception_types;
    }
    else {
      resolved.perception_types = []
    }

    if (msg.cMe_map_keys !== undefined) {
      resolved.cMe_map_keys = msg.cMe_map_keys;
    }
    else {
      resolved.cMe_map_keys = []
    }

    if (msg.cMe_map_values !== undefined) {
      resolved.cMe_map_values = new Array(msg.cMe_map_values.length);
      for (let i = 0; i < resolved.cMe_map_values.length; ++i) {
        resolved.cMe_map_values[i] = geometry_msgs.msg.Pose.Resolve(msg.cMe_map_values[i]);
      }
    }
    else {
      resolved.cMe_map_values = []
    }

    if (msg.vs_goal !== undefined) {
      resolved.vs_goal = IbvsConstrainedGoal.Resolve(msg.vs_goal)
    }
    else {
      resolved.vs_goal = new IbvsConstrainedGoal()
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    if (msg.int_reserve !== undefined) {
      resolved.int_reserve = msg.int_reserve;
    }
    else {
      resolved.int_reserve = []
    }

    if (msg.double_reserve !== undefined) {
      resolved.double_reserve = msg.double_reserve;
    }
    else {
      resolved.double_reserve = []
    }

    if (msg.string_reserve !== undefined) {
      resolved.string_reserve = msg.string_reserve;
    }
    else {
      resolved.string_reserve = []
    }

    if (msg.pose_reserve !== undefined) {
      resolved.pose_reserve = new Array(msg.pose_reserve.length);
      for (let i = 0; i < resolved.pose_reserve.length; ++i) {
        resolved.pose_reserve[i] = geometry_msgs.msg.Pose.Resolve(msg.pose_reserve[i]);
      }
    }
    else {
      resolved.pose_reserve = []
    }

    return resolved;
    }
};

// Constants for message
IplusPerceptionReqRequest.Constants = {
  PERCEPTION_START: 0,
  PERCEPTION_STOP: 1,
}

class IplusPerceptionReqResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sucess = null;
      this.perception_keys = null;
      this.perception_topic_names = null;
      this.json_string = null;
      this.message = null;
      this.int_reserve = null;
      this.double_reserve = null;
      this.string_reserve = null;
      this.pose_reserve = null;
    }
    else {
      if (initObj.hasOwnProperty('sucess')) {
        this.sucess = initObj.sucess
      }
      else {
        this.sucess = false;
      }
      if (initObj.hasOwnProperty('perception_keys')) {
        this.perception_keys = initObj.perception_keys
      }
      else {
        this.perception_keys = [];
      }
      if (initObj.hasOwnProperty('perception_topic_names')) {
        this.perception_topic_names = initObj.perception_topic_names
      }
      else {
        this.perception_topic_names = [];
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('int_reserve')) {
        this.int_reserve = initObj.int_reserve
      }
      else {
        this.int_reserve = [];
      }
      if (initObj.hasOwnProperty('double_reserve')) {
        this.double_reserve = initObj.double_reserve
      }
      else {
        this.double_reserve = [];
      }
      if (initObj.hasOwnProperty('string_reserve')) {
        this.string_reserve = initObj.string_reserve
      }
      else {
        this.string_reserve = [];
      }
      if (initObj.hasOwnProperty('pose_reserve')) {
        this.pose_reserve = initObj.pose_reserve
      }
      else {
        this.pose_reserve = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IplusPerceptionReqResponse
    // Serialize message field [sucess]
    bufferOffset = _serializer.bool(obj.sucess, buffer, bufferOffset);
    // Serialize message field [perception_keys]
    bufferOffset = _arraySerializer.string(obj.perception_keys, buffer, bufferOffset, null);
    // Serialize message field [perception_topic_names]
    bufferOffset = _arraySerializer.string(obj.perception_topic_names, buffer, bufferOffset, null);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [int_reserve]
    bufferOffset = _arraySerializer.int32(obj.int_reserve, buffer, bufferOffset, null);
    // Serialize message field [double_reserve]
    bufferOffset = _arraySerializer.float64(obj.double_reserve, buffer, bufferOffset, null);
    // Serialize message field [string_reserve]
    bufferOffset = _arraySerializer.string(obj.string_reserve, buffer, bufferOffset, null);
    // Serialize message field [pose_reserve]
    // Serialize the length for message field [pose_reserve]
    bufferOffset = _serializer.uint32(obj.pose_reserve.length, buffer, bufferOffset);
    obj.pose_reserve.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IplusPerceptionReqResponse
    let len;
    let data = new IplusPerceptionReqResponse(null);
    // Deserialize message field [sucess]
    data.sucess = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [perception_keys]
    data.perception_keys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [perception_topic_names]
    data.perception_topic_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [int_reserve]
    data.int_reserve = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [double_reserve]
    data.double_reserve = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [string_reserve]
    data.string_reserve = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [pose_reserve]
    // Deserialize array length for message field [pose_reserve]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.pose_reserve = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.pose_reserve[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.perception_keys.forEach((val) => {
      length += 4 + val.length;
    });
    object.perception_topic_names.forEach((val) => {
      length += 4 + val.length;
    });
    length += object.json_string.length;
    length += object.message.length;
    length += 4 * object.int_reserve.length;
    length += 8 * object.double_reserve.length;
    object.string_reserve.forEach((val) => {
      length += 4 + val.length;
    });
    length += 56 * object.pose_reserve.length;
    return length + 33;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/IplusPerceptionReqResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7f90b5bdc54ff0ee4f7245e09c4065fd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool sucess
    string[] perception_keys
    string[] perception_topic_names
    string json_string
    string message
    
    int32[] int_reserve
    float64[] double_reserve
    string[] string_reserve
    geometry_msgs/Pose[] pose_reserve
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IplusPerceptionReqResponse(null);
    if (msg.sucess !== undefined) {
      resolved.sucess = msg.sucess;
    }
    else {
      resolved.sucess = false
    }

    if (msg.perception_keys !== undefined) {
      resolved.perception_keys = msg.perception_keys;
    }
    else {
      resolved.perception_keys = []
    }

    if (msg.perception_topic_names !== undefined) {
      resolved.perception_topic_names = msg.perception_topic_names;
    }
    else {
      resolved.perception_topic_names = []
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.int_reserve !== undefined) {
      resolved.int_reserve = msg.int_reserve;
    }
    else {
      resolved.int_reserve = []
    }

    if (msg.double_reserve !== undefined) {
      resolved.double_reserve = msg.double_reserve;
    }
    else {
      resolved.double_reserve = []
    }

    if (msg.string_reserve !== undefined) {
      resolved.string_reserve = msg.string_reserve;
    }
    else {
      resolved.string_reserve = []
    }

    if (msg.pose_reserve !== undefined) {
      resolved.pose_reserve = new Array(msg.pose_reserve.length);
      for (let i = 0; i < resolved.pose_reserve.length; ++i) {
        resolved.pose_reserve[i] = geometry_msgs.msg.Pose.Resolve(msg.pose_reserve[i]);
      }
    }
    else {
      resolved.pose_reserve = []
    }

    return resolved;
    }
};

module.exports = {
  Request: IplusPerceptionReqRequest,
  Response: IplusPerceptionReqResponse,
  md5sum() { return '591aab0cc3adf04a96e4b49ee17912d7'; },
  datatype() { return 'visual_servo_msgs/IplusPerceptionReq'; }
};
