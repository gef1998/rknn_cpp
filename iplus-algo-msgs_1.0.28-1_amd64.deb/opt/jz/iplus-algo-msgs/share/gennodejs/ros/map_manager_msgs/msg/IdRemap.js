// Auto-generated. Do not edit!

// (in-package map_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class IdRemap {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ns = null;
      this.origin_id = null;
      this.new_id = null;
    }
    else {
      if (initObj.hasOwnProperty('ns')) {
        this.ns = initObj.ns
      }
      else {
        this.ns = '';
      }
      if (initObj.hasOwnProperty('origin_id')) {
        this.origin_id = initObj.origin_id
      }
      else {
        this.origin_id = 0;
      }
      if (initObj.hasOwnProperty('new_id')) {
        this.new_id = initObj.new_id
      }
      else {
        this.new_id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IdRemap
    // Serialize message field [ns]
    bufferOffset = _serializer.string(obj.ns, buffer, bufferOffset);
    // Serialize message field [origin_id]
    bufferOffset = _serializer.int32(obj.origin_id, buffer, bufferOffset);
    // Serialize message field [new_id]
    bufferOffset = _serializer.int32(obj.new_id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IdRemap
    let len;
    let data = new IdRemap(null);
    // Deserialize message field [ns]
    data.ns = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [origin_id]
    data.origin_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [new_id]
    data.new_id = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.ns.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'map_manager_msgs/IdRemap';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9fe8412592a28e00965d25a2350cf6d9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string ns
    int32 origin_id
    int32 new_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IdRemap(null);
    if (msg.ns !== undefined) {
      resolved.ns = msg.ns;
    }
    else {
      resolved.ns = ''
    }

    if (msg.origin_id !== undefined) {
      resolved.origin_id = msg.origin_id;
    }
    else {
      resolved.origin_id = 0
    }

    if (msg.new_id !== undefined) {
      resolved.new_id = msg.new_id;
    }
    else {
      resolved.new_id = 0
    }

    return resolved;
    }
};

module.exports = IdRemap;
