// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ScanSaferLaserRegion {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.config_topic = null;
      this.region_alert_inner = null;
      this.region_alert_mid = null;
      this.region_alert_outer = null;
      this.regions_ignored = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('config_topic')) {
        this.config_topic = initObj.config_topic
      }
      else {
        this.config_topic = '';
      }
      if (initObj.hasOwnProperty('region_alert_inner')) {
        this.region_alert_inner = initObj.region_alert_inner
      }
      else {
        this.region_alert_inner = new geometry_msgs.msg.Polygon();
      }
      if (initObj.hasOwnProperty('region_alert_mid')) {
        this.region_alert_mid = initObj.region_alert_mid
      }
      else {
        this.region_alert_mid = new geometry_msgs.msg.Polygon();
      }
      if (initObj.hasOwnProperty('region_alert_outer')) {
        this.region_alert_outer = initObj.region_alert_outer
      }
      else {
        this.region_alert_outer = new geometry_msgs.msg.Polygon();
      }
      if (initObj.hasOwnProperty('regions_ignored')) {
        this.regions_ignored = initObj.regions_ignored
      }
      else {
        this.regions_ignored = [];
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ScanSaferLaserRegion
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [config_topic]
    bufferOffset = _serializer.string(obj.config_topic, buffer, bufferOffset);
    // Serialize message field [region_alert_inner]
    bufferOffset = geometry_msgs.msg.Polygon.serialize(obj.region_alert_inner, buffer, bufferOffset);
    // Serialize message field [region_alert_mid]
    bufferOffset = geometry_msgs.msg.Polygon.serialize(obj.region_alert_mid, buffer, bufferOffset);
    // Serialize message field [region_alert_outer]
    bufferOffset = geometry_msgs.msg.Polygon.serialize(obj.region_alert_outer, buffer, bufferOffset);
    // Serialize message field [regions_ignored]
    // Serialize the length for message field [regions_ignored]
    bufferOffset = _serializer.uint32(obj.regions_ignored.length, buffer, bufferOffset);
    obj.regions_ignored.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Polygon.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ScanSaferLaserRegion
    let len;
    let data = new ScanSaferLaserRegion(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [config_topic]
    data.config_topic = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [region_alert_inner]
    data.region_alert_inner = geometry_msgs.msg.Polygon.deserialize(buffer, bufferOffset);
    // Deserialize message field [region_alert_mid]
    data.region_alert_mid = geometry_msgs.msg.Polygon.deserialize(buffer, bufferOffset);
    // Deserialize message field [region_alert_outer]
    data.region_alert_outer = geometry_msgs.msg.Polygon.deserialize(buffer, bufferOffset);
    // Deserialize message field [regions_ignored]
    // Deserialize array length for message field [regions_ignored]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.regions_ignored = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.regions_ignored[i] = geometry_msgs.msg.Polygon.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.config_topic.length;
    length += geometry_msgs.msg.Polygon.getMessageSize(object.region_alert_inner);
    length += geometry_msgs.msg.Polygon.getMessageSize(object.region_alert_mid);
    length += geometry_msgs.msg.Polygon.getMessageSize(object.region_alert_outer);
    object.regions_ignored.forEach((val) => {
      length += geometry_msgs.msg.Polygon.getMessageSize(val);
    });
    length += object.json_string.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'emma_tools_msgs/ScanSaferLaserRegion';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bed5b2fef8ff6569e5dc6a6ebfd2a97a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    string config_topic
    
    geometry_msgs/Polygon region_alert_inner
    geometry_msgs/Polygon region_alert_mid
    geometry_msgs/Polygon region_alert_outer
    geometry_msgs/Polygon[] regions_ignored
    
    string json_string
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Polygon
    #A specification of a polygon where the first and last points are assumed to be connected
    Point32[] points
    
    ================================================================================
    MSG: geometry_msgs/Point32
    # This contains the position of a point in free space(with 32 bits of precision).
    # It is recommeded to use Point wherever possible instead of Point32.  
    # 
    # This recommendation is to promote interoperability.  
    #
    # This message is designed to take up less space when sending
    # lots of points at once, as in the case of a PointCloud.  
    
    float32 x
    float32 y
    float32 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ScanSaferLaserRegion(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.config_topic !== undefined) {
      resolved.config_topic = msg.config_topic;
    }
    else {
      resolved.config_topic = ''
    }

    if (msg.region_alert_inner !== undefined) {
      resolved.region_alert_inner = geometry_msgs.msg.Polygon.Resolve(msg.region_alert_inner)
    }
    else {
      resolved.region_alert_inner = new geometry_msgs.msg.Polygon()
    }

    if (msg.region_alert_mid !== undefined) {
      resolved.region_alert_mid = geometry_msgs.msg.Polygon.Resolve(msg.region_alert_mid)
    }
    else {
      resolved.region_alert_mid = new geometry_msgs.msg.Polygon()
    }

    if (msg.region_alert_outer !== undefined) {
      resolved.region_alert_outer = geometry_msgs.msg.Polygon.Resolve(msg.region_alert_outer)
    }
    else {
      resolved.region_alert_outer = new geometry_msgs.msg.Polygon()
    }

    if (msg.regions_ignored !== undefined) {
      resolved.regions_ignored = new Array(msg.regions_ignored.length);
      for (let i = 0; i < resolved.regions_ignored.length; ++i) {
        resolved.regions_ignored[i] = geometry_msgs.msg.Polygon.Resolve(msg.regions_ignored[i]);
      }
    }
    else {
      resolved.regions_ignored = []
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = ScanSaferLaserRegion;
