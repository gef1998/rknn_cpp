// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

let ModelDtectorResult = require('../msg/ModelDtectorResult.js');

//-----------------------------------------------------------

class AutoModelDetectRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map_path = null;
      this.model_path = null;
      this.thresh = null;
      this.region = null;
      this.markers = null;
      this.tag2map = null;
      this.tag2opti = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('map_path')) {
        this.map_path = initObj.map_path
      }
      else {
        this.map_path = '';
      }
      if (initObj.hasOwnProperty('model_path')) {
        this.model_path = initObj.model_path
      }
      else {
        this.model_path = '';
      }
      if (initObj.hasOwnProperty('thresh')) {
        this.thresh = initObj.thresh
      }
      else {
        this.thresh = 0.0;
      }
      if (initObj.hasOwnProperty('region')) {
        this.region = initObj.region
      }
      else {
        this.region = new geometry_msgs.msg.Polygon();
      }
      if (initObj.hasOwnProperty('markers')) {
        this.markers = initObj.markers
      }
      else {
        this.markers = [];
      }
      if (initObj.hasOwnProperty('tag2map')) {
        this.tag2map = initObj.tag2map
      }
      else {
        this.tag2map = [];
      }
      if (initObj.hasOwnProperty('tag2opti')) {
        this.tag2opti = initObj.tag2opti
      }
      else {
        this.tag2opti = [];
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AutoModelDetectRequest
    // Serialize message field [map_path]
    bufferOffset = _serializer.string(obj.map_path, buffer, bufferOffset);
    // Serialize message field [model_path]
    bufferOffset = _serializer.string(obj.model_path, buffer, bufferOffset);
    // Serialize message field [thresh]
    bufferOffset = _serializer.float32(obj.thresh, buffer, bufferOffset);
    // Serialize message field [region]
    bufferOffset = geometry_msgs.msg.Polygon.serialize(obj.region, buffer, bufferOffset);
    // Serialize message field [markers]
    // Serialize the length for message field [markers]
    bufferOffset = _serializer.uint32(obj.markers.length, buffer, bufferOffset);
    obj.markers.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [tag2map]
    // Serialize the length for message field [tag2map]
    bufferOffset = _serializer.uint32(obj.tag2map.length, buffer, bufferOffset);
    obj.tag2map.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [tag2opti]
    // Serialize the length for message field [tag2opti]
    bufferOffset = _serializer.uint32(obj.tag2opti.length, buffer, bufferOffset);
    obj.tag2opti.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AutoModelDetectRequest
    let len;
    let data = new AutoModelDetectRequest(null);
    // Deserialize message field [map_path]
    data.map_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [model_path]
    data.model_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [thresh]
    data.thresh = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [region]
    data.region = geometry_msgs.msg.Polygon.deserialize(buffer, bufferOffset);
    // Deserialize message field [markers]
    // Deserialize array length for message field [markers]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.markers = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.markers[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [tag2map]
    // Deserialize array length for message field [tag2map]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tag2map = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tag2map[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [tag2opti]
    // Deserialize array length for message field [tag2opti]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tag2opti = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tag2opti[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.map_path.length;
    length += object.model_path.length;
    length += geometry_msgs.msg.Polygon.getMessageSize(object.region);
    length += 24 * object.markers.length;
    length += 24 * object.tag2map.length;
    length += 24 * object.tag2opti.length;
    length += object.json_string.length;
    return length + 28;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/AutoModelDetectRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4f2752bd8b7dc22f6387dc6bf82b96a2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string map_path
    string model_path
    float32 thresh
    geometry_msgs/Polygon region
    geometry_msgs/Point[] markers
    geometry_msgs/Point[] tag2map
    geometry_msgs/Point[] tag2opti
    string json_string
    
    ================================================================================
    MSG: geometry_msgs/Polygon
    #A specification of a polygon where the first and last points are assumed to be connected
    Point32[] points
    
    ================================================================================
    MSG: geometry_msgs/Point32
    # This contains the position of a point in free space(with 32 bits of precision).
    # It is recommeded to use Point wherever possible instead of Point32.  
    # 
    # This recommendation is to promote interoperability.  
    #
    # This message is designed to take up less space when sending
    # lots of points at once, as in the case of a PointCloud.  
    
    float32 x
    float32 y
    float32 z
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AutoModelDetectRequest(null);
    if (msg.map_path !== undefined) {
      resolved.map_path = msg.map_path;
    }
    else {
      resolved.map_path = ''
    }

    if (msg.model_path !== undefined) {
      resolved.model_path = msg.model_path;
    }
    else {
      resolved.model_path = ''
    }

    if (msg.thresh !== undefined) {
      resolved.thresh = msg.thresh;
    }
    else {
      resolved.thresh = 0.0
    }

    if (msg.region !== undefined) {
      resolved.region = geometry_msgs.msg.Polygon.Resolve(msg.region)
    }
    else {
      resolved.region = new geometry_msgs.msg.Polygon()
    }

    if (msg.markers !== undefined) {
      resolved.markers = new Array(msg.markers.length);
      for (let i = 0; i < resolved.markers.length; ++i) {
        resolved.markers[i] = geometry_msgs.msg.Point.Resolve(msg.markers[i]);
      }
    }
    else {
      resolved.markers = []
    }

    if (msg.tag2map !== undefined) {
      resolved.tag2map = new Array(msg.tag2map.length);
      for (let i = 0; i < resolved.tag2map.length; ++i) {
        resolved.tag2map[i] = geometry_msgs.msg.Point.Resolve(msg.tag2map[i]);
      }
    }
    else {
      resolved.tag2map = []
    }

    if (msg.tag2opti !== undefined) {
      resolved.tag2opti = new Array(msg.tag2opti.length);
      for (let i = 0; i < resolved.tag2opti.length; ++i) {
        resolved.tag2opti[i] = geometry_msgs.msg.Point.Resolve(msg.tag2opti[i]);
      }
    }
    else {
      resolved.tag2opti = []
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

class AutoModelDetectResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
      this.model_width = null;
      this.model_height = null;
      this.results = null;
      this.errors_x = null;
      this.errors_y = null;
      this.errors_theta = null;
      this.errors = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('model_width')) {
        this.model_width = initObj.model_width
      }
      else {
        this.model_width = 0.0;
      }
      if (initObj.hasOwnProperty('model_height')) {
        this.model_height = initObj.model_height
      }
      else {
        this.model_height = 0.0;
      }
      if (initObj.hasOwnProperty('results')) {
        this.results = initObj.results
      }
      else {
        this.results = [];
      }
      if (initObj.hasOwnProperty('errors_x')) {
        this.errors_x = initObj.errors_x
      }
      else {
        this.errors_x = [];
      }
      if (initObj.hasOwnProperty('errors_y')) {
        this.errors_y = initObj.errors_y
      }
      else {
        this.errors_y = [];
      }
      if (initObj.hasOwnProperty('errors_theta')) {
        this.errors_theta = initObj.errors_theta
      }
      else {
        this.errors_theta = [];
      }
      if (initObj.hasOwnProperty('errors')) {
        this.errors = initObj.errors
      }
      else {
        this.errors = [];
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AutoModelDetectResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [model_width]
    bufferOffset = _serializer.float32(obj.model_width, buffer, bufferOffset);
    // Serialize message field [model_height]
    bufferOffset = _serializer.float32(obj.model_height, buffer, bufferOffset);
    // Serialize message field [results]
    // Serialize the length for message field [results]
    bufferOffset = _serializer.uint32(obj.results.length, buffer, bufferOffset);
    obj.results.forEach((val) => {
      bufferOffset = ModelDtectorResult.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [errors_x]
    bufferOffset = _arraySerializer.float32(obj.errors_x, buffer, bufferOffset, null);
    // Serialize message field [errors_y]
    bufferOffset = _arraySerializer.float32(obj.errors_y, buffer, bufferOffset, null);
    // Serialize message field [errors_theta]
    bufferOffset = _arraySerializer.float32(obj.errors_theta, buffer, bufferOffset, null);
    // Serialize message field [errors]
    // Serialize the length for message field [errors]
    bufferOffset = _serializer.uint32(obj.errors.length, buffer, bufferOffset);
    obj.errors.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AutoModelDetectResponse
    let len;
    let data = new AutoModelDetectResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [model_width]
    data.model_width = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [model_height]
    data.model_height = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [results]
    // Deserialize array length for message field [results]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.results = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.results[i] = ModelDtectorResult.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [errors_x]
    data.errors_x = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [errors_y]
    data.errors_y = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [errors_theta]
    data.errors_theta = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [errors]
    // Deserialize array length for message field [errors]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.errors = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.errors[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    length += 60 * object.results.length;
    length += 4 * object.errors_x.length;
    length += 4 * object.errors_y.length;
    length += 4 * object.errors_theta.length;
    length += 56 * object.errors.length;
    length += object.json_string.length;
    return length + 37;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/AutoModelDetectResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '192a65726f28d563fa15c1c5ba5697c8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    float32 model_width
    float32 model_height
    ModelDtectorResult[] results
    float32[] errors_x
    float32[] errors_y
    float32[] errors_theta
    geometry_msgs/Pose[] errors
    string json_string
    
    
    
    
    ================================================================================
    MSG: emma_tools_msgs/ModelDtectorResult
    float32 best_value
    geometry_msgs/Pose model2map
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AutoModelDetectResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.model_width !== undefined) {
      resolved.model_width = msg.model_width;
    }
    else {
      resolved.model_width = 0.0
    }

    if (msg.model_height !== undefined) {
      resolved.model_height = msg.model_height;
    }
    else {
      resolved.model_height = 0.0
    }

    if (msg.results !== undefined) {
      resolved.results = new Array(msg.results.length);
      for (let i = 0; i < resolved.results.length; ++i) {
        resolved.results[i] = ModelDtectorResult.Resolve(msg.results[i]);
      }
    }
    else {
      resolved.results = []
    }

    if (msg.errors_x !== undefined) {
      resolved.errors_x = msg.errors_x;
    }
    else {
      resolved.errors_x = []
    }

    if (msg.errors_y !== undefined) {
      resolved.errors_y = msg.errors_y;
    }
    else {
      resolved.errors_y = []
    }

    if (msg.errors_theta !== undefined) {
      resolved.errors_theta = msg.errors_theta;
    }
    else {
      resolved.errors_theta = []
    }

    if (msg.errors !== undefined) {
      resolved.errors = new Array(msg.errors.length);
      for (let i = 0; i < resolved.errors.length; ++i) {
        resolved.errors[i] = geometry_msgs.msg.Pose.Resolve(msg.errors[i]);
      }
    }
    else {
      resolved.errors = []
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: AutoModelDetectRequest,
  Response: AutoModelDetectResponse,
  md5sum() { return '540d33d4eb3294e6486fc2b02b7e3612'; },
  datatype() { return 'emma_tools_msgs/AutoModelDetect'; }
};
