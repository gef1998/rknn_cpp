// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class LandmarkNewEntry {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ns = null;
      this.id = null;
      this.visible = null;
      this.normal_x = null;
      this.normal_y = null;
      this.normal_z = null;
      this.tracking_from_landmark_transform = null;
      this.translation_weight = null;
      this.rotation_weight = null;
      this.pole_radius = null;
    }
    else {
      if (initObj.hasOwnProperty('ns')) {
        this.ns = initObj.ns
      }
      else {
        this.ns = '';
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = '';
      }
      if (initObj.hasOwnProperty('visible')) {
        this.visible = initObj.visible
      }
      else {
        this.visible = 0;
      }
      if (initObj.hasOwnProperty('normal_x')) {
        this.normal_x = initObj.normal_x
      }
      else {
        this.normal_x = 0.0;
      }
      if (initObj.hasOwnProperty('normal_y')) {
        this.normal_y = initObj.normal_y
      }
      else {
        this.normal_y = 0.0;
      }
      if (initObj.hasOwnProperty('normal_z')) {
        this.normal_z = initObj.normal_z
      }
      else {
        this.normal_z = 0.0;
      }
      if (initObj.hasOwnProperty('tracking_from_landmark_transform')) {
        this.tracking_from_landmark_transform = initObj.tracking_from_landmark_transform
      }
      else {
        this.tracking_from_landmark_transform = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('translation_weight')) {
        this.translation_weight = initObj.translation_weight
      }
      else {
        this.translation_weight = 0.0;
      }
      if (initObj.hasOwnProperty('rotation_weight')) {
        this.rotation_weight = initObj.rotation_weight
      }
      else {
        this.rotation_weight = 0.0;
      }
      if (initObj.hasOwnProperty('pole_radius')) {
        this.pole_radius = initObj.pole_radius
      }
      else {
        this.pole_radius = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LandmarkNewEntry
    // Serialize message field [ns]
    bufferOffset = _serializer.string(obj.ns, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = _serializer.string(obj.id, buffer, bufferOffset);
    // Serialize message field [visible]
    bufferOffset = _serializer.int32(obj.visible, buffer, bufferOffset);
    // Serialize message field [normal_x]
    bufferOffset = _serializer.float64(obj.normal_x, buffer, bufferOffset);
    // Serialize message field [normal_y]
    bufferOffset = _serializer.float64(obj.normal_y, buffer, bufferOffset);
    // Serialize message field [normal_z]
    bufferOffset = _serializer.float64(obj.normal_z, buffer, bufferOffset);
    // Serialize message field [tracking_from_landmark_transform]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.tracking_from_landmark_transform, buffer, bufferOffset);
    // Serialize message field [translation_weight]
    bufferOffset = _serializer.float64(obj.translation_weight, buffer, bufferOffset);
    // Serialize message field [rotation_weight]
    bufferOffset = _serializer.float64(obj.rotation_weight, buffer, bufferOffset);
    // Serialize message field [pole_radius]
    bufferOffset = _serializer.float64(obj.pole_radius, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LandmarkNewEntry
    let len;
    let data = new LandmarkNewEntry(null);
    // Deserialize message field [ns]
    data.ns = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [visible]
    data.visible = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [normal_x]
    data.normal_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [normal_y]
    data.normal_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [normal_z]
    data.normal_z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [tracking_from_landmark_transform]
    data.tracking_from_landmark_transform = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [translation_weight]
    data.translation_weight = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [rotation_weight]
    data.rotation_weight = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pole_radius]
    data.pole_radius = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.ns.length;
    length += object.id.length;
    return length + 116;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/LandmarkNewEntry';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '15e77972964b7f4fb51d7e3d7be88988';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # 2018 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    string ns
    string id
    int32 visible
    float64 normal_x
    float64 normal_y
    float64 normal_z
    geometry_msgs/Pose tracking_from_landmark_transform
    float64 translation_weight
    float64 rotation_weight
    float64 pole_radius
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LandmarkNewEntry(null);
    if (msg.ns !== undefined) {
      resolved.ns = msg.ns;
    }
    else {
      resolved.ns = ''
    }

    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = ''
    }

    if (msg.visible !== undefined) {
      resolved.visible = msg.visible;
    }
    else {
      resolved.visible = 0
    }

    if (msg.normal_x !== undefined) {
      resolved.normal_x = msg.normal_x;
    }
    else {
      resolved.normal_x = 0.0
    }

    if (msg.normal_y !== undefined) {
      resolved.normal_y = msg.normal_y;
    }
    else {
      resolved.normal_y = 0.0
    }

    if (msg.normal_z !== undefined) {
      resolved.normal_z = msg.normal_z;
    }
    else {
      resolved.normal_z = 0.0
    }

    if (msg.tracking_from_landmark_transform !== undefined) {
      resolved.tracking_from_landmark_transform = geometry_msgs.msg.Pose.Resolve(msg.tracking_from_landmark_transform)
    }
    else {
      resolved.tracking_from_landmark_transform = new geometry_msgs.msg.Pose()
    }

    if (msg.translation_weight !== undefined) {
      resolved.translation_weight = msg.translation_weight;
    }
    else {
      resolved.translation_weight = 0.0
    }

    if (msg.rotation_weight !== undefined) {
      resolved.rotation_weight = msg.rotation_weight;
    }
    else {
      resolved.rotation_weight = 0.0
    }

    if (msg.pole_radius !== undefined) {
      resolved.pole_radius = msg.pole_radius;
    }
    else {
      resolved.pole_radius = 0.0
    }

    return resolved;
    }
};

module.exports = LandmarkNewEntry;
