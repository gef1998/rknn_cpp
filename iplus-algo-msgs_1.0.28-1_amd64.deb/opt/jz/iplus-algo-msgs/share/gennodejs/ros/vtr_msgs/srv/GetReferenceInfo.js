// Auto-generated. Do not edit!

// (in-package vtr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class GetReferenceInfoRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetReferenceInfoRequest
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetReferenceInfoRequest
    let len;
    let data = new GetReferenceInfoRequest(null);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.json_string.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/GetReferenceInfoRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '99611b8ec56704fa6a4948fbcc54e25b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string json_string
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetReferenceInfoRequest(null);
    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

class GetReferenceInfoResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.base2map = null;
      this.base2reference = null;
      this.reference_id = null;
      this.json_string = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('base2map')) {
        this.base2map = initObj.base2map
      }
      else {
        this.base2map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('base2reference')) {
        this.base2reference = initObj.base2reference
      }
      else {
        this.base2reference = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('reference_id')) {
        this.reference_id = initObj.reference_id
      }
      else {
        this.reference_id = 0;
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetReferenceInfoResponse
    // Serialize message field [base2map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.base2map, buffer, bufferOffset);
    // Serialize message field [base2reference]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.base2reference, buffer, bufferOffset);
    // Serialize message field [reference_id]
    bufferOffset = _serializer.int32(obj.reference_id, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetReferenceInfoResponse
    let len;
    let data = new GetReferenceInfoResponse(null);
    // Deserialize message field [base2map]
    data.base2map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [base2reference]
    data.base2reference = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [reference_id]
    data.reference_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.json_string.length;
    length += object.error_message.length;
    return length + 124;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/GetReferenceInfoResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3c852c83cd17c15b41b428291dd55353';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Pose base2map
    geometry_msgs/Pose base2reference
    int32 reference_id
    string json_string
    string error_message
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetReferenceInfoResponse(null);
    if (msg.base2map !== undefined) {
      resolved.base2map = geometry_msgs.msg.Pose.Resolve(msg.base2map)
    }
    else {
      resolved.base2map = new geometry_msgs.msg.Pose()
    }

    if (msg.base2reference !== undefined) {
      resolved.base2reference = geometry_msgs.msg.Pose.Resolve(msg.base2reference)
    }
    else {
      resolved.base2reference = new geometry_msgs.msg.Pose()
    }

    if (msg.reference_id !== undefined) {
      resolved.reference_id = msg.reference_id;
    }
    else {
      resolved.reference_id = 0
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GetReferenceInfoRequest,
  Response: GetReferenceInfoResponse,
  md5sum() { return '62bb5fce8993b21bb5220c2efade1eb5'; },
  datatype() { return 'vtr_msgs/GetReferenceInfo'; }
};
