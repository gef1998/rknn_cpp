// Auto-generated. Do not edit!

// (in-package move_task_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class GetBCCPathRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.waypoints = null;
      this.curvature_limits = null;
    }
    else {
      if (initObj.hasOwnProperty('waypoints')) {
        this.waypoints = initObj.waypoints
      }
      else {
        this.waypoints = [];
      }
      if (initObj.hasOwnProperty('curvature_limits')) {
        this.curvature_limits = initObj.curvature_limits
      }
      else {
        this.curvature_limits = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetBCCPathRequest
    // Serialize message field [waypoints]
    // Serialize the length for message field [waypoints]
    bufferOffset = _serializer.uint32(obj.waypoints.length, buffer, bufferOffset);
    obj.waypoints.forEach((val) => {
      bufferOffset = geometry_msgs.msg.PoseStamped.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [curvature_limits]
    bufferOffset = _arraySerializer.float64(obj.curvature_limits, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetBCCPathRequest
    let len;
    let data = new GetBCCPathRequest(null);
    // Deserialize message field [waypoints]
    // Deserialize array length for message field [waypoints]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.waypoints = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.waypoints[i] = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [curvature_limits]
    data.curvature_limits = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.waypoints.forEach((val) => {
      length += geometry_msgs.msg.PoseStamped.getMessageSize(val);
    });
    length += 8 * object.curvature_limits.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'move_task_msgs/GetBCCPathRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6ba16b10c16794c81dafdc7b403f4908';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/PoseStamped[] waypoints
    float64[] curvature_limits
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetBCCPathRequest(null);
    if (msg.waypoints !== undefined) {
      resolved.waypoints = new Array(msg.waypoints.length);
      for (let i = 0; i < resolved.waypoints.length; ++i) {
        resolved.waypoints[i] = geometry_msgs.msg.PoseStamped.Resolve(msg.waypoints[i]);
      }
    }
    else {
      resolved.waypoints = []
    }

    if (msg.curvature_limits !== undefined) {
      resolved.curvature_limits = msg.curvature_limits;
    }
    else {
      resolved.curvature_limits = []
    }

    return resolved;
    }
};

class GetBCCPathResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.plan_success = null;
      this.message = null;
      this.bcc_path = null;
      this.curvatures = null;
    }
    else {
      if (initObj.hasOwnProperty('plan_success')) {
        this.plan_success = initObj.plan_success
      }
      else {
        this.plan_success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('bcc_path')) {
        this.bcc_path = initObj.bcc_path
      }
      else {
        this.bcc_path = [];
      }
      if (initObj.hasOwnProperty('curvatures')) {
        this.curvatures = initObj.curvatures
      }
      else {
        this.curvatures = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetBCCPathResponse
    // Serialize message field [plan_success]
    bufferOffset = _serializer.bool(obj.plan_success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [bcc_path]
    // Serialize the length for message field [bcc_path]
    bufferOffset = _serializer.uint32(obj.bcc_path.length, buffer, bufferOffset);
    obj.bcc_path.forEach((val) => {
      bufferOffset = geometry_msgs.msg.PoseStamped.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [curvatures]
    bufferOffset = _arraySerializer.float64(obj.curvatures, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetBCCPathResponse
    let len;
    let data = new GetBCCPathResponse(null);
    // Deserialize message field [plan_success]
    data.plan_success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [bcc_path]
    // Deserialize array length for message field [bcc_path]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.bcc_path = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.bcc_path[i] = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [curvatures]
    data.curvatures = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    object.bcc_path.forEach((val) => {
      length += geometry_msgs.msg.PoseStamped.getMessageSize(val);
    });
    length += 8 * object.curvatures.length;
    return length + 13;
  }

  static datatype() {
    // Returns string type for a service object
    return 'move_task_msgs/GetBCCPathResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8983336e4d0cf97e5260c71845ff6272';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool plan_success
    string message
    geometry_msgs/PoseStamped[] bcc_path
    float64[] curvatures
    
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetBCCPathResponse(null);
    if (msg.plan_success !== undefined) {
      resolved.plan_success = msg.plan_success;
    }
    else {
      resolved.plan_success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.bcc_path !== undefined) {
      resolved.bcc_path = new Array(msg.bcc_path.length);
      for (let i = 0; i < resolved.bcc_path.length; ++i) {
        resolved.bcc_path[i] = geometry_msgs.msg.PoseStamped.Resolve(msg.bcc_path[i]);
      }
    }
    else {
      resolved.bcc_path = []
    }

    if (msg.curvatures !== undefined) {
      resolved.curvatures = msg.curvatures;
    }
    else {
      resolved.curvatures = []
    }

    return resolved;
    }
};

module.exports = {
  Request: GetBCCPathRequest,
  Response: GetBCCPathResponse,
  md5sum() { return 'bf98daa762dbb6c5884718f290274bec'; },
  datatype() { return 'move_task_msgs/GetBCCPath'; }
};
