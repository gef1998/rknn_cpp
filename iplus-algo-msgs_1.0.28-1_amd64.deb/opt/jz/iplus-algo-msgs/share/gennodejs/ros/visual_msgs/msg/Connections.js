// Auto-generated. Do not edit!

// (in-package visual_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Connections {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.node_i = null;
      this.node_j = null;
    }
    else {
      if (initObj.hasOwnProperty('node_i')) {
        this.node_i = initObj.node_i
      }
      else {
        this.node_i = [];
      }
      if (initObj.hasOwnProperty('node_j')) {
        this.node_j = initObj.node_j
      }
      else {
        this.node_j = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Connections
    // Serialize message field [node_i]
    bufferOffset = _arraySerializer.int32(obj.node_i, buffer, bufferOffset, null);
    // Serialize message field [node_j]
    bufferOffset = _arraySerializer.int32(obj.node_j, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Connections
    let len;
    let data = new Connections(null);
    // Deserialize message field [node_i]
    data.node_i = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [node_j]
    data.node_j = _arrayDeserializer.int32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.node_i.length;
    length += 4 * object.node_j.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_msgs/Connections';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '336595181b9a8d08a5eb468935c0ed5b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32[] node_i
    int32[] node_j
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Connections(null);
    if (msg.node_i !== undefined) {
      resolved.node_i = msg.node_i;
    }
    else {
      resolved.node_i = []
    }

    if (msg.node_j !== undefined) {
      resolved.node_j = msg.node_j;
    }
    else {
      resolved.node_j = []
    }

    return resolved;
    }
};

module.exports = Connections;
