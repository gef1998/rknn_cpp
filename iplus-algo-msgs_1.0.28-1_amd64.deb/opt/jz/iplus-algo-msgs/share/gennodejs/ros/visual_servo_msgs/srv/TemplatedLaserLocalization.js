// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class TemplatedLaserLocalizationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.template_id = null;
      this.templete_image = null;
      this.templete_threshold = null;
      this.templete_path = null;
      this.minCorner = null;
      this.maxCorner = null;
      this.angleThreashOnDegree = null;
      this.configure_json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('template_id')) {
        this.template_id = initObj.template_id
      }
      else {
        this.template_id = 0;
      }
      if (initObj.hasOwnProperty('templete_image')) {
        this.templete_image = initObj.templete_image
      }
      else {
        this.templete_image = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('templete_threshold')) {
        this.templete_threshold = initObj.templete_threshold
      }
      else {
        this.templete_threshold = 0;
      }
      if (initObj.hasOwnProperty('templete_path')) {
        this.templete_path = initObj.templete_path
      }
      else {
        this.templete_path = '';
      }
      if (initObj.hasOwnProperty('minCorner')) {
        this.minCorner = initObj.minCorner
      }
      else {
        this.minCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('maxCorner')) {
        this.maxCorner = initObj.maxCorner
      }
      else {
        this.maxCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('angleThreashOnDegree')) {
        this.angleThreashOnDegree = initObj.angleThreashOnDegree
      }
      else {
        this.angleThreashOnDegree = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TemplatedLaserLocalizationRequest
    // Serialize message field [template_id]
    bufferOffset = _serializer.int32(obj.template_id, buffer, bufferOffset);
    // Serialize message field [templete_image]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.templete_image, buffer, bufferOffset);
    // Serialize message field [templete_threshold]
    bufferOffset = _serializer.int32(obj.templete_threshold, buffer, bufferOffset);
    // Serialize message field [templete_path]
    bufferOffset = _serializer.string(obj.templete_path, buffer, bufferOffset);
    // Check that the constant length array field [minCorner] has the right length
    if (obj.minCorner.length !== 2) {
      throw new Error('Unable to serialize array field minCorner - length must be 2')
    }
    // Serialize message field [minCorner]
    bufferOffset = _arraySerializer.float32(obj.minCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [maxCorner] has the right length
    if (obj.maxCorner.length !== 2) {
      throw new Error('Unable to serialize array field maxCorner - length must be 2')
    }
    // Serialize message field [maxCorner]
    bufferOffset = _arraySerializer.float32(obj.maxCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [angleThreashOnDegree] has the right length
    if (obj.angleThreashOnDegree.length !== 2) {
      throw new Error('Unable to serialize array field angleThreashOnDegree - length must be 2')
    }
    // Serialize message field [angleThreashOnDegree]
    bufferOffset = _arraySerializer.float32(obj.angleThreashOnDegree, buffer, bufferOffset, 2);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TemplatedLaserLocalizationRequest
    let len;
    let data = new TemplatedLaserLocalizationRequest(null);
    // Deserialize message field [template_id]
    data.template_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [templete_image]
    data.templete_image = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [templete_threshold]
    data.templete_threshold = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [templete_path]
    data.templete_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [minCorner]
    data.minCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [maxCorner]
    data.maxCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [angleThreashOnDegree]
    data.angleThreashOnDegree = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += sensor_msgs.msg.Image.getMessageSize(object.templete_image);
    length += object.templete_path.length;
    length += object.configure_json_string.length;
    return length + 40;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/TemplatedLaserLocalizationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a0c147dd347f21ea18a893f6d3ccb4ec';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 template_id
    sensor_msgs/Image templete_image
    int32  templete_threshold
    string templete_path
    
    float32[2] minCorner
    float32[2] maxCorner
    float32[2] angleThreashOnDegree
    string configure_json_string
    
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of cameara
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TemplatedLaserLocalizationRequest(null);
    if (msg.template_id !== undefined) {
      resolved.template_id = msg.template_id;
    }
    else {
      resolved.template_id = 0
    }

    if (msg.templete_image !== undefined) {
      resolved.templete_image = sensor_msgs.msg.Image.Resolve(msg.templete_image)
    }
    else {
      resolved.templete_image = new sensor_msgs.msg.Image()
    }

    if (msg.templete_threshold !== undefined) {
      resolved.templete_threshold = msg.templete_threshold;
    }
    else {
      resolved.templete_threshold = 0
    }

    if (msg.templete_path !== undefined) {
      resolved.templete_path = msg.templete_path;
    }
    else {
      resolved.templete_path = ''
    }

    if (msg.minCorner !== undefined) {
      resolved.minCorner = msg.minCorner;
    }
    else {
      resolved.minCorner = new Array(2).fill(0)
    }

    if (msg.maxCorner !== undefined) {
      resolved.maxCorner = msg.maxCorner;
    }
    else {
      resolved.maxCorner = new Array(2).fill(0)
    }

    if (msg.angleThreashOnDegree !== undefined) {
      resolved.angleThreashOnDegree = msg.angleThreashOnDegree;
    }
    else {
      resolved.angleThreashOnDegree = new Array(2).fill(0)
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    return resolved;
    }
};

class TemplatedLaserLocalizationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.templateInLaser = null;
      this.laserInBase = null;
      this.templateWidth = null;
      this.templateHeight = null;
      this.matchingValue = null;
      this.configure_json_string = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('templateInLaser')) {
        this.templateInLaser = initObj.templateInLaser
      }
      else {
        this.templateInLaser = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('laserInBase')) {
        this.laserInBase = initObj.laserInBase
      }
      else {
        this.laserInBase = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('templateWidth')) {
        this.templateWidth = initObj.templateWidth
      }
      else {
        this.templateWidth = 0.0;
      }
      if (initObj.hasOwnProperty('templateHeight')) {
        this.templateHeight = initObj.templateHeight
      }
      else {
        this.templateHeight = 0.0;
      }
      if (initObj.hasOwnProperty('matchingValue')) {
        this.matchingValue = initObj.matchingValue
      }
      else {
        this.matchingValue = 0.0;
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TemplatedLaserLocalizationResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [templateInLaser]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.templateInLaser, buffer, bufferOffset);
    // Serialize message field [laserInBase]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.laserInBase, buffer, bufferOffset);
    // Serialize message field [templateWidth]
    bufferOffset = _serializer.float32(obj.templateWidth, buffer, bufferOffset);
    // Serialize message field [templateHeight]
    bufferOffset = _serializer.float32(obj.templateHeight, buffer, bufferOffset);
    // Serialize message field [matchingValue]
    bufferOffset = _serializer.float32(obj.matchingValue, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TemplatedLaserLocalizationResponse
    let len;
    let data = new TemplatedLaserLocalizationResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [templateInLaser]
    data.templateInLaser = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [laserInBase]
    data.laserInBase = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [templateWidth]
    data.templateWidth = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [templateHeight]
    data.templateHeight = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [matchingValue]
    data.matchingValue = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.configure_json_string.length;
    length += object.error_message.length;
    return length + 68;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/TemplatedLaserLocalizationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8414a565f01804ecd4c3aec95e746731';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    
    
    
    
    geometry_msgs/Pose2D templateInLaser
    geometry_msgs/Pose2D laserInBase
    float32 templateWidth
    float32 templateHeight
    float32 matchingValue
    string configure_json_string
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TemplatedLaserLocalizationResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.templateInLaser !== undefined) {
      resolved.templateInLaser = geometry_msgs.msg.Pose2D.Resolve(msg.templateInLaser)
    }
    else {
      resolved.templateInLaser = new geometry_msgs.msg.Pose2D()
    }

    if (msg.laserInBase !== undefined) {
      resolved.laserInBase = geometry_msgs.msg.Pose2D.Resolve(msg.laserInBase)
    }
    else {
      resolved.laserInBase = new geometry_msgs.msg.Pose2D()
    }

    if (msg.templateWidth !== undefined) {
      resolved.templateWidth = msg.templateWidth;
    }
    else {
      resolved.templateWidth = 0.0
    }

    if (msg.templateHeight !== undefined) {
      resolved.templateHeight = msg.templateHeight;
    }
    else {
      resolved.templateHeight = 0.0
    }

    if (msg.matchingValue !== undefined) {
      resolved.matchingValue = msg.matchingValue;
    }
    else {
      resolved.matchingValue = 0.0
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: TemplatedLaserLocalizationRequest,
  Response: TemplatedLaserLocalizationResponse,
  md5sum() { return '8a3620242aa83d6453cf691e097f6af4'; },
  datatype() { return 'visual_servo_msgs/TemplatedLaserLocalization'; }
};
