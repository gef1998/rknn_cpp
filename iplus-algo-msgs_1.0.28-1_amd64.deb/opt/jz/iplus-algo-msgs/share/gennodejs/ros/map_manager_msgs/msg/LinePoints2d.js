// Auto-generated. Do not edit!

// (in-package map_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Point2d = require('./Point2d.js');

//-----------------------------------------------------------

class LinePoints2d {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.startPoint = null;
      this.endPoint = null;
    }
    else {
      if (initObj.hasOwnProperty('startPoint')) {
        this.startPoint = initObj.startPoint
      }
      else {
        this.startPoint = new Point2d();
      }
      if (initObj.hasOwnProperty('endPoint')) {
        this.endPoint = initObj.endPoint
      }
      else {
        this.endPoint = new Point2d();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LinePoints2d
    // Serialize message field [startPoint]
    bufferOffset = Point2d.serialize(obj.startPoint, buffer, bufferOffset);
    // Serialize message field [endPoint]
    bufferOffset = Point2d.serialize(obj.endPoint, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LinePoints2d
    let len;
    let data = new LinePoints2d(null);
    // Deserialize message field [startPoint]
    data.startPoint = Point2d.deserialize(buffer, bufferOffset);
    // Deserialize message field [endPoint]
    data.endPoint = Point2d.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'map_manager_msgs/LinePoints2d';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3f03e2f601a9e2ecee05fb14a3c2d18d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    map_manager_msgs/Point2d startPoint
    map_manager_msgs/Point2d endPoint
    ================================================================================
    MSG: map_manager_msgs/Point2d
    float64 x
    float64 y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LinePoints2d(null);
    if (msg.startPoint !== undefined) {
      resolved.startPoint = Point2d.Resolve(msg.startPoint)
    }
    else {
      resolved.startPoint = new Point2d()
    }

    if (msg.endPoint !== undefined) {
      resolved.endPoint = Point2d.Resolve(msg.endPoint)
    }
    else {
      resolved.endPoint = new Point2d()
    }

    return resolved;
    }
};

module.exports = LinePoints2d;
