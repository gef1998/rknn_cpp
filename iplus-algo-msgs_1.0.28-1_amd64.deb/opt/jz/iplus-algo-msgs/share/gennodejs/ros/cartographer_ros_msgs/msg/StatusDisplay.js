// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class StatusDisplay {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.server_status = null;
      this.header = null;
      this.work_map = null;
      this.work_item_size = null;
      this.worldLoc = null;
      this.imageLoc = null;
      this.XLaserInWorld = null;
      this.YLaserInWorld = null;
      this.failure_count = null;
    }
    else {
      if (initObj.hasOwnProperty('server_status')) {
        this.server_status = initObj.server_status
      }
      else {
        this.server_status = 0;
      }
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('work_map')) {
        this.work_map = initObj.work_map
      }
      else {
        this.work_map = '';
      }
      if (initObj.hasOwnProperty('work_item_size')) {
        this.work_item_size = initObj.work_item_size
      }
      else {
        this.work_item_size = 0;
      }
      if (initObj.hasOwnProperty('worldLoc')) {
        this.worldLoc = initObj.worldLoc
      }
      else {
        this.worldLoc = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('imageLoc')) {
        this.imageLoc = initObj.imageLoc
      }
      else {
        this.imageLoc = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('XLaserInWorld')) {
        this.XLaserInWorld = initObj.XLaserInWorld
      }
      else {
        this.XLaserInWorld = [];
      }
      if (initObj.hasOwnProperty('YLaserInWorld')) {
        this.YLaserInWorld = initObj.YLaserInWorld
      }
      else {
        this.YLaserInWorld = [];
      }
      if (initObj.hasOwnProperty('failure_count')) {
        this.failure_count = initObj.failure_count
      }
      else {
        this.failure_count = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StatusDisplay
    // Serialize message field [server_status]
    bufferOffset = _serializer.uint8(obj.server_status, buffer, bufferOffset);
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [work_map]
    bufferOffset = _serializer.string(obj.work_map, buffer, bufferOffset);
    // Serialize message field [work_item_size]
    bufferOffset = _serializer.int32(obj.work_item_size, buffer, bufferOffset);
    // Serialize message field [worldLoc]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.worldLoc, buffer, bufferOffset);
    // Serialize message field [imageLoc]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.imageLoc, buffer, bufferOffset);
    // Serialize message field [XLaserInWorld]
    bufferOffset = _arraySerializer.float32(obj.XLaserInWorld, buffer, bufferOffset, null);
    // Serialize message field [YLaserInWorld]
    bufferOffset = _arraySerializer.float32(obj.YLaserInWorld, buffer, bufferOffset, null);
    // Serialize message field [failure_count]
    bufferOffset = _serializer.int32(obj.failure_count, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StatusDisplay
    let len;
    let data = new StatusDisplay(null);
    // Deserialize message field [server_status]
    data.server_status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [work_map]
    data.work_map = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [work_item_size]
    data.work_item_size = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [worldLoc]
    data.worldLoc = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [imageLoc]
    data.imageLoc = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [XLaserInWorld]
    data.XLaserInWorld = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [YLaserInWorld]
    data.YLaserInWorld = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [failure_count]
    data.failure_count = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.work_map.length;
    length += 4 * object.XLaserInWorld.length;
    length += 4 * object.YLaserInWorld.length;
    return length + 69;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/StatusDisplay';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b85dc6e34e30dffe5b2ebbd0c3e15be5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 server_status
    uint8 MAPPING=0
    uint8 LOCALIZING=1
    uint8 IDLE=2
    uint8 PATCH_MAPPING=3
    
    std_msgs/Header header
    string work_map
    int32 work_item_size
    geometry_msgs/Pose2D worldLoc
    
    # imageLoc should not be used while service is in MAPPING mode.
    geometry_msgs/Pose2D imageLoc
    
    float32[] XLaserInWorld
    float32[] YLaserInWorld
    
    int32 failure_count
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StatusDisplay(null);
    if (msg.server_status !== undefined) {
      resolved.server_status = msg.server_status;
    }
    else {
      resolved.server_status = 0
    }

    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.work_map !== undefined) {
      resolved.work_map = msg.work_map;
    }
    else {
      resolved.work_map = ''
    }

    if (msg.work_item_size !== undefined) {
      resolved.work_item_size = msg.work_item_size;
    }
    else {
      resolved.work_item_size = 0
    }

    if (msg.worldLoc !== undefined) {
      resolved.worldLoc = geometry_msgs.msg.Pose2D.Resolve(msg.worldLoc)
    }
    else {
      resolved.worldLoc = new geometry_msgs.msg.Pose2D()
    }

    if (msg.imageLoc !== undefined) {
      resolved.imageLoc = geometry_msgs.msg.Pose2D.Resolve(msg.imageLoc)
    }
    else {
      resolved.imageLoc = new geometry_msgs.msg.Pose2D()
    }

    if (msg.XLaserInWorld !== undefined) {
      resolved.XLaserInWorld = msg.XLaserInWorld;
    }
    else {
      resolved.XLaserInWorld = []
    }

    if (msg.YLaserInWorld !== undefined) {
      resolved.YLaserInWorld = msg.YLaserInWorld;
    }
    else {
      resolved.YLaserInWorld = []
    }

    if (msg.failure_count !== undefined) {
      resolved.failure_count = msg.failure_count;
    }
    else {
      resolved.failure_count = 0
    }

    return resolved;
    }
};

// Constants for message
StatusDisplay.Constants = {
  MAPPING: 0,
  LOCALIZING: 1,
  IDLE: 2,
  PATCH_MAPPING: 3,
}

module.exports = StatusDisplay;
