// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let NodePose = require('./NodePose.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class TrajectoryNodePoses {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.node_poses = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('node_poses')) {
        this.node_poses = initObj.node_poses
      }
      else {
        this.node_poses = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TrajectoryNodePoses
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [node_poses]
    // Serialize the length for message field [node_poses]
    bufferOffset = _serializer.uint32(obj.node_poses.length, buffer, bufferOffset);
    obj.node_poses.forEach((val) => {
      bufferOffset = NodePose.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TrajectoryNodePoses
    let len;
    let data = new TrajectoryNodePoses(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [node_poses]
    // Deserialize array length for message field [node_poses]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.node_poses = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.node_poses[i] = NodePose.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.node_poses.forEach((val) => {
      length += NodePose.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/TrajectoryNodePoses';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b82b490b7503212a5464d227a2e1c571';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    cartographer_ros_msgs/NodePose[] node_poses
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: cartographer_ros_msgs/NodePose
    std_msgs/Header header
    int32 trajectory_id
    int32 node_index
    geometry_msgs/Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TrajectoryNodePoses(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.node_poses !== undefined) {
      resolved.node_poses = new Array(msg.node_poses.length);
      for (let i = 0; i < resolved.node_poses.length; ++i) {
        resolved.node_poses[i] = NodePose.Resolve(msg.node_poses[i]);
      }
    }
    else {
      resolved.node_poses = []
    }

    return resolved;
    }
};

module.exports = TrajectoryNodePoses;
