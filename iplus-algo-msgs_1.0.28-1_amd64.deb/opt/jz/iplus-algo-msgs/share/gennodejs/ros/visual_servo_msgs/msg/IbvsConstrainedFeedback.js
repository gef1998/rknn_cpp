// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class IbvsConstrainedFeedback {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.action = null;
      this.vs_type = null;
      this.status = null;
      this.vx = null;
      this.vy = null;
      this.wz = null;
      this.error_x = null;
      this.error_y = null;
      this.error_theta = null;
      this.error_value = null;
      this.baseToTarget = null;
      this.baseToTarget_x = null;
      this.baseToTarget_y = null;
      this.baseToTarget_theta = null;
      this.info = null;
      this.vs_traffic_status = null;
      this.vs_action_status = null;
      this.uchar_reserved = null;
      this.int_reserved = null;
      this.float_reserved = null;
      this.double_reserved = null;
      this.str_reserved = null;
    }
    else {
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = 0;
      }
      if (initObj.hasOwnProperty('vs_type')) {
        this.vs_type = initObj.vs_type
      }
      else {
        this.vs_type = 0;
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
      if (initObj.hasOwnProperty('vx')) {
        this.vx = initObj.vx
      }
      else {
        this.vx = 0.0;
      }
      if (initObj.hasOwnProperty('vy')) {
        this.vy = initObj.vy
      }
      else {
        this.vy = 0.0;
      }
      if (initObj.hasOwnProperty('wz')) {
        this.wz = initObj.wz
      }
      else {
        this.wz = 0.0;
      }
      if (initObj.hasOwnProperty('error_x')) {
        this.error_x = initObj.error_x
      }
      else {
        this.error_x = 0.0;
      }
      if (initObj.hasOwnProperty('error_y')) {
        this.error_y = initObj.error_y
      }
      else {
        this.error_y = 0.0;
      }
      if (initObj.hasOwnProperty('error_theta')) {
        this.error_theta = initObj.error_theta
      }
      else {
        this.error_theta = 0.0;
      }
      if (initObj.hasOwnProperty('error_value')) {
        this.error_value = initObj.error_value
      }
      else {
        this.error_value = 0.0;
      }
      if (initObj.hasOwnProperty('baseToTarget')) {
        this.baseToTarget = initObj.baseToTarget
      }
      else {
        this.baseToTarget = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('baseToTarget_x')) {
        this.baseToTarget_x = initObj.baseToTarget_x
      }
      else {
        this.baseToTarget_x = 0.0;
      }
      if (initObj.hasOwnProperty('baseToTarget_y')) {
        this.baseToTarget_y = initObj.baseToTarget_y
      }
      else {
        this.baseToTarget_y = 0.0;
      }
      if (initObj.hasOwnProperty('baseToTarget_theta')) {
        this.baseToTarget_theta = initObj.baseToTarget_theta
      }
      else {
        this.baseToTarget_theta = 0.0;
      }
      if (initObj.hasOwnProperty('info')) {
        this.info = initObj.info
      }
      else {
        this.info = '';
      }
      if (initObj.hasOwnProperty('vs_traffic_status')) {
        this.vs_traffic_status = initObj.vs_traffic_status
      }
      else {
        this.vs_traffic_status = 0;
      }
      if (initObj.hasOwnProperty('vs_action_status')) {
        this.vs_action_status = initObj.vs_action_status
      }
      else {
        this.vs_action_status = 0;
      }
      if (initObj.hasOwnProperty('uchar_reserved')) {
        this.uchar_reserved = initObj.uchar_reserved
      }
      else {
        this.uchar_reserved = [];
      }
      if (initObj.hasOwnProperty('int_reserved')) {
        this.int_reserved = initObj.int_reserved
      }
      else {
        this.int_reserved = [];
      }
      if (initObj.hasOwnProperty('float_reserved')) {
        this.float_reserved = initObj.float_reserved
      }
      else {
        this.float_reserved = [];
      }
      if (initObj.hasOwnProperty('double_reserved')) {
        this.double_reserved = initObj.double_reserved
      }
      else {
        this.double_reserved = [];
      }
      if (initObj.hasOwnProperty('str_reserved')) {
        this.str_reserved = initObj.str_reserved
      }
      else {
        this.str_reserved = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IbvsConstrainedFeedback
    // Serialize message field [action]
    bufferOffset = _serializer.int32(obj.action, buffer, bufferOffset);
    // Serialize message field [vs_type]
    bufferOffset = _serializer.int32(obj.vs_type, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    // Serialize message field [vx]
    bufferOffset = _serializer.float64(obj.vx, buffer, bufferOffset);
    // Serialize message field [vy]
    bufferOffset = _serializer.float64(obj.vy, buffer, bufferOffset);
    // Serialize message field [wz]
    bufferOffset = _serializer.float64(obj.wz, buffer, bufferOffset);
    // Serialize message field [error_x]
    bufferOffset = _serializer.float64(obj.error_x, buffer, bufferOffset);
    // Serialize message field [error_y]
    bufferOffset = _serializer.float64(obj.error_y, buffer, bufferOffset);
    // Serialize message field [error_theta]
    bufferOffset = _serializer.float64(obj.error_theta, buffer, bufferOffset);
    // Serialize message field [error_value]
    bufferOffset = _serializer.float64(obj.error_value, buffer, bufferOffset);
    // Serialize message field [baseToTarget]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.baseToTarget, buffer, bufferOffset);
    // Serialize message field [baseToTarget_x]
    bufferOffset = _serializer.float64(obj.baseToTarget_x, buffer, bufferOffset);
    // Serialize message field [baseToTarget_y]
    bufferOffset = _serializer.float64(obj.baseToTarget_y, buffer, bufferOffset);
    // Serialize message field [baseToTarget_theta]
    bufferOffset = _serializer.float64(obj.baseToTarget_theta, buffer, bufferOffset);
    // Serialize message field [info]
    bufferOffset = _serializer.string(obj.info, buffer, bufferOffset);
    // Serialize message field [vs_traffic_status]
    bufferOffset = _serializer.uint8(obj.vs_traffic_status, buffer, bufferOffset);
    // Serialize message field [vs_action_status]
    bufferOffset = _serializer.uint8(obj.vs_action_status, buffer, bufferOffset);
    // Serialize message field [uchar_reserved]
    bufferOffset = _arraySerializer.uint8(obj.uchar_reserved, buffer, bufferOffset, null);
    // Serialize message field [int_reserved]
    bufferOffset = _arraySerializer.int32(obj.int_reserved, buffer, bufferOffset, null);
    // Serialize message field [float_reserved]
    bufferOffset = _arraySerializer.float32(obj.float_reserved, buffer, bufferOffset, null);
    // Serialize message field [double_reserved]
    bufferOffset = _arraySerializer.float64(obj.double_reserved, buffer, bufferOffset, null);
    // Serialize message field [str_reserved]
    bufferOffset = _arraySerializer.string(obj.str_reserved, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IbvsConstrainedFeedback
    let len;
    let data = new IbvsConstrainedFeedback(null);
    // Deserialize message field [action]
    data.action = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [vs_type]
    data.vs_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [vx]
    data.vx = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [vy]
    data.vy = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [wz]
    data.wz = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [error_x]
    data.error_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [error_y]
    data.error_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [error_theta]
    data.error_theta = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [error_value]
    data.error_value = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [baseToTarget]
    data.baseToTarget = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [baseToTarget_x]
    data.baseToTarget_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [baseToTarget_y]
    data.baseToTarget_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [baseToTarget_theta]
    data.baseToTarget_theta = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [info]
    data.info = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [vs_traffic_status]
    data.vs_traffic_status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [vs_action_status]
    data.vs_action_status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [uchar_reserved]
    data.uchar_reserved = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    // Deserialize message field [int_reserved]
    data.int_reserved = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [float_reserved]
    data.float_reserved = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [double_reserved]
    data.double_reserved = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [str_reserved]
    data.str_reserved = _arrayDeserializer.string(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.info.length;
    length += object.uchar_reserved.length;
    length += 4 * object.int_reserved.length;
    length += 4 * object.float_reserved.length;
    length += 8 * object.double_reserved.length;
    object.str_reserved.forEach((val) => {
      length += 4 + val.length;
    });
    return length + 171;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_servo_msgs/IbvsConstrainedFeedback';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f74f96b54d67b49e96117d6f0484afdb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    #feedback
    int32 action
    int32 vs_type
    uint8 status
    uint8 OK = 0
    uint8 DETECTION_FAILED = 1
    float64 vx
    float64 vy
    float64 wz
    float64 error_x
    float64 error_y
    float64 error_theta
    float64 error_value
    geometry_msgs/Pose baseToTarget
    float64 baseToTarget_x
    float64 baseToTarget_y
    float64 baseToTarget_theta	# yaw
    string info
    
    #traffic
    uint8 vs_traffic_status
    uint8 VS_TRAFFIC_OK = 0
    uint8 VS_TRAFFIC_FACE_OBSTACLE = 1
    uint8 VS_TRAFFIC_SLOW_DOWN = 2
    uint8 VS_TRAFFIC_STOP = 3
    
    
    uint8 vs_action_status
    uint8 VS_NOT_DEFINED = 0
    uint8 VS_BLIND_FORWARD = 1
    uint8 VS_BLIND_BACKWARD = 2
    uint8 VS_FOLLOW_LINE_BACKWARD = 3
    uint8 VS_BLIND_ROT_LEFT = 4
    uint8 VS_BLIND_ROT_RIGHT = 5
    
    
    uint8[] uchar_reserved
    int32[] int_reserved
    float32[] float_reserved
    float64[] double_reserved
    string[] str_reserved
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IbvsConstrainedFeedback(null);
    if (msg.action !== undefined) {
      resolved.action = msg.action;
    }
    else {
      resolved.action = 0
    }

    if (msg.vs_type !== undefined) {
      resolved.vs_type = msg.vs_type;
    }
    else {
      resolved.vs_type = 0
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    if (msg.vx !== undefined) {
      resolved.vx = msg.vx;
    }
    else {
      resolved.vx = 0.0
    }

    if (msg.vy !== undefined) {
      resolved.vy = msg.vy;
    }
    else {
      resolved.vy = 0.0
    }

    if (msg.wz !== undefined) {
      resolved.wz = msg.wz;
    }
    else {
      resolved.wz = 0.0
    }

    if (msg.error_x !== undefined) {
      resolved.error_x = msg.error_x;
    }
    else {
      resolved.error_x = 0.0
    }

    if (msg.error_y !== undefined) {
      resolved.error_y = msg.error_y;
    }
    else {
      resolved.error_y = 0.0
    }

    if (msg.error_theta !== undefined) {
      resolved.error_theta = msg.error_theta;
    }
    else {
      resolved.error_theta = 0.0
    }

    if (msg.error_value !== undefined) {
      resolved.error_value = msg.error_value;
    }
    else {
      resolved.error_value = 0.0
    }

    if (msg.baseToTarget !== undefined) {
      resolved.baseToTarget = geometry_msgs.msg.Pose.Resolve(msg.baseToTarget)
    }
    else {
      resolved.baseToTarget = new geometry_msgs.msg.Pose()
    }

    if (msg.baseToTarget_x !== undefined) {
      resolved.baseToTarget_x = msg.baseToTarget_x;
    }
    else {
      resolved.baseToTarget_x = 0.0
    }

    if (msg.baseToTarget_y !== undefined) {
      resolved.baseToTarget_y = msg.baseToTarget_y;
    }
    else {
      resolved.baseToTarget_y = 0.0
    }

    if (msg.baseToTarget_theta !== undefined) {
      resolved.baseToTarget_theta = msg.baseToTarget_theta;
    }
    else {
      resolved.baseToTarget_theta = 0.0
    }

    if (msg.info !== undefined) {
      resolved.info = msg.info;
    }
    else {
      resolved.info = ''
    }

    if (msg.vs_traffic_status !== undefined) {
      resolved.vs_traffic_status = msg.vs_traffic_status;
    }
    else {
      resolved.vs_traffic_status = 0
    }

    if (msg.vs_action_status !== undefined) {
      resolved.vs_action_status = msg.vs_action_status;
    }
    else {
      resolved.vs_action_status = 0
    }

    if (msg.uchar_reserved !== undefined) {
      resolved.uchar_reserved = msg.uchar_reserved;
    }
    else {
      resolved.uchar_reserved = []
    }

    if (msg.int_reserved !== undefined) {
      resolved.int_reserved = msg.int_reserved;
    }
    else {
      resolved.int_reserved = []
    }

    if (msg.float_reserved !== undefined) {
      resolved.float_reserved = msg.float_reserved;
    }
    else {
      resolved.float_reserved = []
    }

    if (msg.double_reserved !== undefined) {
      resolved.double_reserved = msg.double_reserved;
    }
    else {
      resolved.double_reserved = []
    }

    if (msg.str_reserved !== undefined) {
      resolved.str_reserved = msg.str_reserved;
    }
    else {
      resolved.str_reserved = []
    }

    return resolved;
    }
};

// Constants for message
IbvsConstrainedFeedback.Constants = {
  OK: 0,
  DETECTION_FAILED: 1,
  VS_TRAFFIC_OK: 0,
  VS_TRAFFIC_FACE_OBSTACLE: 1,
  VS_TRAFFIC_SLOW_DOWN: 2,
  VS_TRAFFIC_STOP: 3,
  VS_NOT_DEFINED: 0,
  VS_BLIND_FORWARD: 1,
  VS_BLIND_BACKWARD: 2,
  VS_FOLLOW_LINE_BACKWARD: 3,
  VS_BLIND_ROT_LEFT: 4,
  VS_BLIND_ROT_RIGHT: 5,
}

module.exports = IbvsConstrainedFeedback;
