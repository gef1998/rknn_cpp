// Auto-generated. Do not edit!

// (in-package pl_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Keypoint {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pl_x = null;
      this.pl_y = null;
    }
    else {
      if (initObj.hasOwnProperty('pl_x')) {
        this.pl_x = initObj.pl_x
      }
      else {
        this.pl_x = 0.0;
      }
      if (initObj.hasOwnProperty('pl_y')) {
        this.pl_y = initObj.pl_y
      }
      else {
        this.pl_y = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Keypoint
    // Serialize message field [pl_x]
    bufferOffset = _serializer.float64(obj.pl_x, buffer, bufferOffset);
    // Serialize message field [pl_y]
    bufferOffset = _serializer.float64(obj.pl_y, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Keypoint
    let len;
    let data = new Keypoint(null);
    // Deserialize message field [pl_x]
    data.pl_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pl_y]
    data.pl_y = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pl_msgs/Keypoint';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd015c665c283b722b90df1623b96e402';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Copyright 2016 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    float64 pl_x
    float64 pl_y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Keypoint(null);
    if (msg.pl_x !== undefined) {
      resolved.pl_x = msg.pl_x;
    }
    else {
      resolved.pl_x = 0.0
    }

    if (msg.pl_y !== undefined) {
      resolved.pl_y = msg.pl_y;
    }
    else {
      resolved.pl_y = 0.0
    }

    return resolved;
    }
};

module.exports = Keypoint;
