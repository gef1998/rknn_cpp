// Auto-generated. Do not edit!

// (in-package json_commute_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class GetFileRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.file_name = null;
    }
    else {
      if (initObj.hasOwnProperty('file_name')) {
        this.file_name = initObj.file_name
      }
      else {
        this.file_name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetFileRequest
    // Serialize message field [file_name]
    bufferOffset = _serializer.string(obj.file_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetFileRequest
    let len;
    let data = new GetFileRequest(null);
    // Deserialize message field [file_name]
    data.file_name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.file_name.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'json_commute_msgs/GetFileRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2415261c9605b9f38867ffbbe495fc04';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string file_name
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetFileRequest(null);
    if (msg.file_name !== undefined) {
      resolved.file_name = msg.file_name;
    }
    else {
      resolved.file_name = ''
    }

    return resolved;
    }
};

class GetFileResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.json_content = null;
    }
    else {
      if (initObj.hasOwnProperty('json_content')) {
        this.json_content = initObj.json_content
      }
      else {
        this.json_content = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetFileResponse
    // Serialize message field [json_content]
    bufferOffset = _serializer.string(obj.json_content, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetFileResponse
    let len;
    let data = new GetFileResponse(null);
    // Deserialize message field [json_content]
    data.json_content = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.json_content.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'json_commute_msgs/GetFileResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b45ea4d5fff3eb2759e32d0fb272aa72';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string json_content
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetFileResponse(null);
    if (msg.json_content !== undefined) {
      resolved.json_content = msg.json_content;
    }
    else {
      resolved.json_content = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GetFileRequest,
  Response: GetFileResponse,
  md5sum() { return '199c7597f339222e1276a2188b0118a1'; },
  datatype() { return 'json_commute_msgs/GetFile'; }
};
