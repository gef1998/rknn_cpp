// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class ObstacleStopInforRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stopDist = null;
    }
    else {
      if (initObj.hasOwnProperty('stopDist')) {
        this.stopDist = initObj.stopDist
      }
      else {
        this.stopDist = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ObstacleStopInforRequest
    // Serialize message field [stopDist]
    bufferOffset = _serializer.float32(obj.stopDist, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ObstacleStopInforRequest
    let len;
    let data = new ObstacleStopInforRequest(null);
    // Deserialize message field [stopDist]
    data.stopDist = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/ObstacleStopInforRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0d0c2f480777432ca5e6d827bc2c179f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 stopDist
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ObstacleStopInforRequest(null);
    if (msg.stopDist !== undefined) {
      resolved.stopDist = msg.stopDist;
    }
    else {
      resolved.stopDist = 0.0
    }

    return resolved;
    }
};

class ObstacleStopInforResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_succeed = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('is_succeed')) {
        this.is_succeed = initObj.is_succeed
      }
      else {
        this.is_succeed = false;
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ObstacleStopInforResponse
    // Serialize message field [is_succeed]
    bufferOffset = _serializer.bool(obj.is_succeed, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ObstacleStopInforResponse
    let len;
    let data = new ObstacleStopInforResponse(null);
    // Deserialize message field [is_succeed]
    data.is_succeed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_message.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/ObstacleStopInforResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '87b3ee6ab2f7c95aed4205460020897c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool is_succeed
    string error_message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ObstacleStopInforResponse(null);
    if (msg.is_succeed !== undefined) {
      resolved.is_succeed = msg.is_succeed;
    }
    else {
      resolved.is_succeed = false
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: ObstacleStopInforRequest,
  Response: ObstacleStopInforResponse,
  md5sum() { return '64f685cba003691845ac3ae7f2cf1a66'; },
  datatype() { return 'visual_servo_msgs/ObstacleStopInfor'; }
};
