// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let IdRemap = require('../msg/IdRemap.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class IdRemapSrvRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map_path = null;
      this.ids = null;
    }
    else {
      if (initObj.hasOwnProperty('map_path')) {
        this.map_path = initObj.map_path
      }
      else {
        this.map_path = '';
      }
      if (initObj.hasOwnProperty('ids')) {
        this.ids = initObj.ids
      }
      else {
        this.ids = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IdRemapSrvRequest
    // Serialize message field [map_path]
    bufferOffset = _serializer.string(obj.map_path, buffer, bufferOffset);
    // Serialize message field [ids]
    // Serialize the length for message field [ids]
    bufferOffset = _serializer.uint32(obj.ids.length, buffer, bufferOffset);
    obj.ids.forEach((val) => {
      bufferOffset = IdRemap.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IdRemapSrvRequest
    let len;
    let data = new IdRemapSrvRequest(null);
    // Deserialize message field [map_path]
    data.map_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [ids]
    // Deserialize array length for message field [ids]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.ids = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.ids[i] = IdRemap.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.map_path.length;
    object.ids.forEach((val) => {
      length += IdRemap.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/IdRemapSrvRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '06602ecf0677e49f87c84f55a0b5bcc1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string map_path
    map_manager_msgs/IdRemap[] ids
    
    ================================================================================
    MSG: map_manager_msgs/IdRemap
    string ns
    int32 origin_id
    int32 new_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IdRemapSrvRequest(null);
    if (msg.map_path !== undefined) {
      resolved.map_path = msg.map_path;
    }
    else {
      resolved.map_path = ''
    }

    if (msg.ids !== undefined) {
      resolved.ids = new Array(msg.ids.length);
      for (let i = 0; i < resolved.ids.length; ++i) {
        resolved.ids[i] = IdRemap.Resolve(msg.ids[i]);
      }
    }
    else {
      resolved.ids = []
    }

    return resolved;
    }
};

class IdRemapSrvResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_msgs = null;
      this.success = null;
    }
    else {
      if (initObj.hasOwnProperty('error_msgs')) {
        this.error_msgs = initObj.error_msgs
      }
      else {
        this.error_msgs = '';
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IdRemapSrvResponse
    // Serialize message field [error_msgs]
    bufferOffset = _serializer.string(obj.error_msgs, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IdRemapSrvResponse
    let len;
    let data = new IdRemapSrvResponse(null);
    // Deserialize message field [error_msgs]
    data.error_msgs = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_msgs.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/IdRemapSrvResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a83e3e4165fe8601b9d425e928bf0842';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_msgs
    bool success
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IdRemapSrvResponse(null);
    if (msg.error_msgs !== undefined) {
      resolved.error_msgs = msg.error_msgs;
    }
    else {
      resolved.error_msgs = ''
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    return resolved;
    }
};

module.exports = {
  Request: IdRemapSrvRequest,
  Response: IdRemapSrvResponse,
  md5sum() { return '1740814e029bdaec1c618d143d767bf1'; },
  datatype() { return 'map_manager_msgs/IdRemapSrv'; }
};
