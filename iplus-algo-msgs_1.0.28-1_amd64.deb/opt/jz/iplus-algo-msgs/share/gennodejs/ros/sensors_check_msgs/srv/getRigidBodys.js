// Auto-generated. Do not edit!

// (in-package sensors_check_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let RigidBodys = require('../msg/RigidBodys.js');

//-----------------------------------------------------------

class getRigidBodysRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type getRigidBodysRequest
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type getRigidBodysRequest
    let len;
    let data = new getRigidBodysRequest(null);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.json_string.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'sensors_check_msgs/getRigidBodysRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '99611b8ec56704fa6a4948fbcc54e25b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string json_string
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new getRigidBodysRequest(null);
    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

class getRigidBodysResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.succeed = null;
      this.message = null;
      this.rigidbodys = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('succeed')) {
        this.succeed = initObj.succeed
      }
      else {
        this.succeed = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('rigidbodys')) {
        this.rigidbodys = initObj.rigidbodys
      }
      else {
        this.rigidbodys = new RigidBodys();
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type getRigidBodysResponse
    // Serialize message field [succeed]
    bufferOffset = _serializer.bool(obj.succeed, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [rigidbodys]
    bufferOffset = RigidBodys.serialize(obj.rigidbodys, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type getRigidBodysResponse
    let len;
    let data = new getRigidBodysResponse(null);
    // Deserialize message field [succeed]
    data.succeed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [rigidbodys]
    data.rigidbodys = RigidBodys.deserialize(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    length += RigidBodys.getMessageSize(object.rigidbodys);
    length += object.json_string.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'sensors_check_msgs/getRigidBodysResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1ac5cc7cd070e71efe28e9db74666928';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool succeed
    string message
    sensors_check_msgs/RigidBodys rigidbodys
    string json_string
    
    
    ================================================================================
    MSG: sensors_check_msgs/RigidBodys
    std_msgs/Header header
    sensors_check_msgs/RigidBody[] rigid_bodys
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: sensors_check_msgs/RigidBody
    std_msgs/Header header
    int32 frame_id
    int32 body_id
    string body_name
    geometry_msgs/PoseStamped pose
    sensors_check_msgs/Marker[] markers
    
    float32 mean_marker_error
    bool tracking_valid
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensors_check_msgs/Marker
    std_msgs/Header header
    int32 id
    float32[3] pose
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new getRigidBodysResponse(null);
    if (msg.succeed !== undefined) {
      resolved.succeed = msg.succeed;
    }
    else {
      resolved.succeed = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.rigidbodys !== undefined) {
      resolved.rigidbodys = RigidBodys.Resolve(msg.rigidbodys)
    }
    else {
      resolved.rigidbodys = new RigidBodys()
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: getRigidBodysRequest,
  Response: getRigidBodysResponse,
  md5sum() { return '4f034aa00944a9800d32b80055360dc4'; },
  datatype() { return 'sensors_check_msgs/getRigidBodys'; }
};
