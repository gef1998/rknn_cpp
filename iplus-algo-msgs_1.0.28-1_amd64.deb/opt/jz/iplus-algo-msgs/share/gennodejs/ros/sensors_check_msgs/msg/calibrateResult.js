// Auto-generated. Do not edit!

// (in-package sensors_check_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class calibrateResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.calib_part = null;
      this.calib_type = null;
      this.error_x = null;
      this.error_radius = null;
    }
    else {
      if (initObj.hasOwnProperty('calib_part')) {
        this.calib_part = initObj.calib_part
      }
      else {
        this.calib_part = 0;
      }
      if (initObj.hasOwnProperty('calib_type')) {
        this.calib_type = initObj.calib_type
      }
      else {
        this.calib_type = 0;
      }
      if (initObj.hasOwnProperty('error_x')) {
        this.error_x = initObj.error_x
      }
      else {
        this.error_x = 0.0;
      }
      if (initObj.hasOwnProperty('error_radius')) {
        this.error_radius = initObj.error_radius
      }
      else {
        this.error_radius = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type calibrateResult
    // Serialize message field [calib_part]
    bufferOffset = _serializer.uint8(obj.calib_part, buffer, bufferOffset);
    // Serialize message field [calib_type]
    bufferOffset = _serializer.uint8(obj.calib_type, buffer, bufferOffset);
    // Serialize message field [error_x]
    bufferOffset = _serializer.float32(obj.error_x, buffer, bufferOffset);
    // Serialize message field [error_radius]
    bufferOffset = _serializer.float32(obj.error_radius, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type calibrateResult
    let len;
    let data = new calibrateResult(null);
    // Deserialize message field [calib_part]
    data.calib_part = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [calib_type]
    data.calib_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [error_x]
    data.error_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [error_radius]
    data.error_radius = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 10;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sensors_check_msgs/calibrateResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cdf5c4167b98ca1047ef1c6003dc065c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 calib_part
    uint8 CALIB_LASER = 0
    uint8 CALIB_ODOM = 1
    uint8 CALIB_VISUAL_SERVO = 2
    
    uint8 calib_type
    uint8 CALIB_LINE = 0
    uint8 CALIB_ROTATE = 1
    
    float32 error_x
    float32 error_radius
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new calibrateResult(null);
    if (msg.calib_part !== undefined) {
      resolved.calib_part = msg.calib_part;
    }
    else {
      resolved.calib_part = 0
    }

    if (msg.calib_type !== undefined) {
      resolved.calib_type = msg.calib_type;
    }
    else {
      resolved.calib_type = 0
    }

    if (msg.error_x !== undefined) {
      resolved.error_x = msg.error_x;
    }
    else {
      resolved.error_x = 0.0
    }

    if (msg.error_radius !== undefined) {
      resolved.error_radius = msg.error_radius;
    }
    else {
      resolved.error_radius = 0.0
    }

    return resolved;
    }
};

// Constants for message
calibrateResult.Constants = {
  CALIB_LASER: 0,
  CALIB_ODOM: 1,
  CALIB_VISUAL_SERVO: 2,
  CALIB_LINE: 0,
  CALIB_ROTATE: 1,
}

module.exports = calibrateResult;
