
"use strict";

let robotInfo = require('./robotInfo.js');
let ScanSafeDetectRegion = require('./ScanSafeDetectRegion.js');
let ModelDtectorResultArray = require('./ModelDtectorResultArray.js');
let ScanSaferRegionInfo = require('./ScanSaferRegionInfo.js');
let ScanSaferLaserRegion = require('./ScanSaferLaserRegion.js');
let ScanSaferRegionPolygonSetInterface = require('./ScanSaferRegionPolygonSetInterface.js');
let ModelDtectorResult = require('./ModelDtectorResult.js');
let ScanSafeLaserRegion = require('./ScanSafeLaserRegion.js');
let ScanSaferRegionResult = require('./ScanSaferRegionResult.js');
let robotsInfo = require('./robotsInfo.js');

module.exports = {
  robotInfo: robotInfo,
  ScanSafeDetectRegion: ScanSafeDetectRegion,
  ModelDtectorResultArray: ModelDtectorResultArray,
  ScanSaferRegionInfo: ScanSaferRegionInfo,
  ScanSaferLaserRegion: ScanSaferLaserRegion,
  ScanSaferRegionPolygonSetInterface: ScanSaferRegionPolygonSetInterface,
  ModelDtectorResult: ModelDtectorResult,
  ScanSafeLaserRegion: ScanSafeLaserRegion,
  ScanSaferRegionResult: ScanSaferRegionResult,
  robotsInfo: robotsInfo,
};
