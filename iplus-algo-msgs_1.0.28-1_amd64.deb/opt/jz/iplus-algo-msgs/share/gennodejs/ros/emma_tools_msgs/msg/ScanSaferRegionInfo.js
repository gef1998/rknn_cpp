// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class ScanSaferRegionInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.name_of_laser_specified = null;
      this.region = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('name_of_laser_specified')) {
        this.name_of_laser_specified = initObj.name_of_laser_specified
      }
      else {
        this.name_of_laser_specified = '';
      }
      if (initObj.hasOwnProperty('region')) {
        this.region = initObj.region
      }
      else {
        this.region = new geometry_msgs.msg.PolygonStamped();
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ScanSaferRegionInfo
    // Serialize message field [id]
    bufferOffset = _serializer.uint32(obj.id, buffer, bufferOffset);
    // Serialize message field [name_of_laser_specified]
    bufferOffset = _serializer.string(obj.name_of_laser_specified, buffer, bufferOffset);
    // Serialize message field [region]
    bufferOffset = geometry_msgs.msg.PolygonStamped.serialize(obj.region, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ScanSaferRegionInfo
    let len;
    let data = new ScanSaferRegionInfo(null);
    // Deserialize message field [id]
    data.id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [name_of_laser_specified]
    data.name_of_laser_specified = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [region]
    data.region = geometry_msgs.msg.PolygonStamped.deserialize(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name_of_laser_specified.length;
    length += geometry_msgs.msg.PolygonStamped.getMessageSize(object.region);
    length += object.json_string.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'emma_tools_msgs/ScanSaferRegionInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eba898ea9a8befbf90f9c42d75a71914';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint32 id
    string name_of_laser_specified
    geometry_msgs/PolygonStamped region
    string json_string
    
    ================================================================================
    MSG: geometry_msgs/PolygonStamped
    # This represents a Polygon with reference coordinate frame and timestamp
    Header header
    Polygon polygon
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Polygon
    #A specification of a polygon where the first and last points are assumed to be connected
    Point32[] points
    
    ================================================================================
    MSG: geometry_msgs/Point32
    # This contains the position of a point in free space(with 32 bits of precision).
    # It is recommeded to use Point wherever possible instead of Point32.  
    # 
    # This recommendation is to promote interoperability.  
    #
    # This message is designed to take up less space when sending
    # lots of points at once, as in the case of a PointCloud.  
    
    float32 x
    float32 y
    float32 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ScanSaferRegionInfo(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.name_of_laser_specified !== undefined) {
      resolved.name_of_laser_specified = msg.name_of_laser_specified;
    }
    else {
      resolved.name_of_laser_specified = ''
    }

    if (msg.region !== undefined) {
      resolved.region = geometry_msgs.msg.PolygonStamped.Resolve(msg.region)
    }
    else {
      resolved.region = new geometry_msgs.msg.PolygonStamped()
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = ScanSaferRegionInfo;
