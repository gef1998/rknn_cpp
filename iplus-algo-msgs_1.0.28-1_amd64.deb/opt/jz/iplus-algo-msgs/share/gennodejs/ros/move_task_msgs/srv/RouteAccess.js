// Auto-generated. Do not edit!

// (in-package move_task_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class RouteAccessRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.waypoints_to_go = null;
    }
    else {
      if (initObj.hasOwnProperty('waypoints_to_go')) {
        this.waypoints_to_go = initObj.waypoints_to_go
      }
      else {
        this.waypoints_to_go = new std_msgs.msg.UInt64MultiArray();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RouteAccessRequest
    // Serialize message field [waypoints_to_go]
    bufferOffset = std_msgs.msg.UInt64MultiArray.serialize(obj.waypoints_to_go, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RouteAccessRequest
    let len;
    let data = new RouteAccessRequest(null);
    // Deserialize message field [waypoints_to_go]
    data.waypoints_to_go = std_msgs.msg.UInt64MultiArray.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.UInt64MultiArray.getMessageSize(object.waypoints_to_go);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'move_task_msgs/RouteAccessRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '91116b1651dba0519490f29c76bd08ce';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/UInt64MultiArray waypoints_to_go
    
    ================================================================================
    MSG: std_msgs/UInt64MultiArray
    # Please look at the MultiArrayLayout message definition for
    # documentation on all multiarrays.
    
    MultiArrayLayout  layout        # specification of data layout
    uint64[]          data          # array of data
    
    
    ================================================================================
    MSG: std_msgs/MultiArrayLayout
    # The multiarray declares a generic multi-dimensional array of a
    # particular data type.  Dimensions are ordered from outer most
    # to inner most.
    
    MultiArrayDimension[] dim # Array of dimension properties
    uint32 data_offset        # padding elements at front of data
    
    # Accessors should ALWAYS be written in terms of dimension stride
    # and specified outer-most dimension first.
    # 
    # multiarray(i,j,k) = data[data_offset + dim_stride[1]*i + dim_stride[2]*j + k]
    #
    # A standard, 3-channel 640x480 image with interleaved color channels
    # would be specified as:
    #
    # dim[0].label  = "height"
    # dim[0].size   = 480
    # dim[0].stride = 3*640*480 = 921600  (note dim[0] stride is just size of image)
    # dim[1].label  = "width"
    # dim[1].size   = 640
    # dim[1].stride = 3*640 = 1920
    # dim[2].label  = "channel"
    # dim[2].size   = 3
    # dim[2].stride = 3
    #
    # multiarray(i,j,k) refers to the ith row, jth column, and kth channel.
    
    ================================================================================
    MSG: std_msgs/MultiArrayDimension
    string label   # label of given dimension
    uint32 size    # size of given dimension (in type units)
    uint32 stride  # stride of given dimension
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RouteAccessRequest(null);
    if (msg.waypoints_to_go !== undefined) {
      resolved.waypoints_to_go = std_msgs.msg.UInt64MultiArray.Resolve(msg.waypoints_to_go)
    }
    else {
      resolved.waypoints_to_go = new std_msgs.msg.UInt64MultiArray()
    }

    return resolved;
    }
};

class RouteAccessResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.waypoints_can_go = null;
    }
    else {
      if (initObj.hasOwnProperty('waypoints_can_go')) {
        this.waypoints_can_go = initObj.waypoints_can_go
      }
      else {
        this.waypoints_can_go = new std_msgs.msg.UInt64MultiArray();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RouteAccessResponse
    // Serialize message field [waypoints_can_go]
    bufferOffset = std_msgs.msg.UInt64MultiArray.serialize(obj.waypoints_can_go, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RouteAccessResponse
    let len;
    let data = new RouteAccessResponse(null);
    // Deserialize message field [waypoints_can_go]
    data.waypoints_can_go = std_msgs.msg.UInt64MultiArray.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.UInt64MultiArray.getMessageSize(object.waypoints_can_go);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'move_task_msgs/RouteAccessResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'aa8f965db375079cfd76d36d20a3ba44';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/UInt64MultiArray waypoints_can_go
    
    
    ================================================================================
    MSG: std_msgs/UInt64MultiArray
    # Please look at the MultiArrayLayout message definition for
    # documentation on all multiarrays.
    
    MultiArrayLayout  layout        # specification of data layout
    uint64[]          data          # array of data
    
    
    ================================================================================
    MSG: std_msgs/MultiArrayLayout
    # The multiarray declares a generic multi-dimensional array of a
    # particular data type.  Dimensions are ordered from outer most
    # to inner most.
    
    MultiArrayDimension[] dim # Array of dimension properties
    uint32 data_offset        # padding elements at front of data
    
    # Accessors should ALWAYS be written in terms of dimension stride
    # and specified outer-most dimension first.
    # 
    # multiarray(i,j,k) = data[data_offset + dim_stride[1]*i + dim_stride[2]*j + k]
    #
    # A standard, 3-channel 640x480 image with interleaved color channels
    # would be specified as:
    #
    # dim[0].label  = "height"
    # dim[0].size   = 480
    # dim[0].stride = 3*640*480 = 921600  (note dim[0] stride is just size of image)
    # dim[1].label  = "width"
    # dim[1].size   = 640
    # dim[1].stride = 3*640 = 1920
    # dim[2].label  = "channel"
    # dim[2].size   = 3
    # dim[2].stride = 3
    #
    # multiarray(i,j,k) refers to the ith row, jth column, and kth channel.
    
    ================================================================================
    MSG: std_msgs/MultiArrayDimension
    string label   # label of given dimension
    uint32 size    # size of given dimension (in type units)
    uint32 stride  # stride of given dimension
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RouteAccessResponse(null);
    if (msg.waypoints_can_go !== undefined) {
      resolved.waypoints_can_go = std_msgs.msg.UInt64MultiArray.Resolve(msg.waypoints_can_go)
    }
    else {
      resolved.waypoints_can_go = new std_msgs.msg.UInt64MultiArray()
    }

    return resolved;
    }
};

module.exports = {
  Request: RouteAccessRequest,
  Response: RouteAccessResponse,
  md5sum() { return 'd1d7611a0bbde37eafd23fb43ae93a3c'; },
  datatype() { return 'move_task_msgs/RouteAccess'; }
};
