// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Point2d = require('../msg/Point2d.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class CropPointServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.p1 = null;
      this.p2 = null;
      this.p3 = null;
      this.p4 = null;
      this.flag = null;
    }
    else {
      if (initObj.hasOwnProperty('p1')) {
        this.p1 = initObj.p1
      }
      else {
        this.p1 = new Point2d();
      }
      if (initObj.hasOwnProperty('p2')) {
        this.p2 = initObj.p2
      }
      else {
        this.p2 = new Point2d();
      }
      if (initObj.hasOwnProperty('p3')) {
        this.p3 = initObj.p3
      }
      else {
        this.p3 = new Point2d();
      }
      if (initObj.hasOwnProperty('p4')) {
        this.p4 = initObj.p4
      }
      else {
        this.p4 = new Point2d();
      }
      if (initObj.hasOwnProperty('flag')) {
        this.flag = initObj.flag
      }
      else {
        this.flag = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CropPointServiceRequest
    // Serialize message field [p1]
    bufferOffset = Point2d.serialize(obj.p1, buffer, bufferOffset);
    // Serialize message field [p2]
    bufferOffset = Point2d.serialize(obj.p2, buffer, bufferOffset);
    // Serialize message field [p3]
    bufferOffset = Point2d.serialize(obj.p3, buffer, bufferOffset);
    // Serialize message field [p4]
    bufferOffset = Point2d.serialize(obj.p4, buffer, bufferOffset);
    // Serialize message field [flag]
    bufferOffset = _serializer.bool(obj.flag, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CropPointServiceRequest
    let len;
    let data = new CropPointServiceRequest(null);
    // Deserialize message field [p1]
    data.p1 = Point2d.deserialize(buffer, bufferOffset);
    // Deserialize message field [p2]
    data.p2 = Point2d.deserialize(buffer, bufferOffset);
    // Deserialize message field [p3]
    data.p3 = Point2d.deserialize(buffer, bufferOffset);
    // Deserialize message field [p4]
    data.p4 = Point2d.deserialize(buffer, bufferOffset);
    // Deserialize message field [flag]
    data.flag = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 65;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/CropPointServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '167bb954efce608a31a64367d7ca4398';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    map_manager_msgs/Point2d p1
    map_manager_msgs/Point2d p2
    map_manager_msgs/Point2d p3
    map_manager_msgs/Point2d p4
    bool flag
    
    ================================================================================
    MSG: map_manager_msgs/Point2d
    float64 x
    float64 y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CropPointServiceRequest(null);
    if (msg.p1 !== undefined) {
      resolved.p1 = Point2d.Resolve(msg.p1)
    }
    else {
      resolved.p1 = new Point2d()
    }

    if (msg.p2 !== undefined) {
      resolved.p2 = Point2d.Resolve(msg.p2)
    }
    else {
      resolved.p2 = new Point2d()
    }

    if (msg.p3 !== undefined) {
      resolved.p3 = Point2d.Resolve(msg.p3)
    }
    else {
      resolved.p3 = new Point2d()
    }

    if (msg.p4 !== undefined) {
      resolved.p4 = Point2d.Resolve(msg.p4)
    }
    else {
      resolved.p4 = new Point2d()
    }

    if (msg.flag !== undefined) {
      resolved.flag = msg.flag;
    }
    else {
      resolved.flag = false
    }

    return resolved;
    }
};

class CropPointServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.finish = null;
    }
    else {
      if (initObj.hasOwnProperty('finish')) {
        this.finish = initObj.finish
      }
      else {
        this.finish = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CropPointServiceResponse
    // Serialize message field [finish]
    bufferOffset = _serializer.bool(obj.finish, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CropPointServiceResponse
    let len;
    let data = new CropPointServiceResponse(null);
    // Deserialize message field [finish]
    data.finish = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/CropPointServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '474a58dbb494a45bb1ca99544cd64e45';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool finish
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CropPointServiceResponse(null);
    if (msg.finish !== undefined) {
      resolved.finish = msg.finish;
    }
    else {
      resolved.finish = false
    }

    return resolved;
    }
};

module.exports = {
  Request: CropPointServiceRequest,
  Response: CropPointServiceResponse,
  md5sum() { return '1a0578c778ddc576a7e3af5ee8a5a574'; },
  datatype() { return 'map_manager_msgs/CropPointService'; }
};
