// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LasermarkEntry = require('./LasermarkEntry.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class LandmarkInDifferentCoordinates {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.marks_in_global = null;
      this.marks_in_odom = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('marks_in_global')) {
        this.marks_in_global = initObj.marks_in_global
      }
      else {
        this.marks_in_global = [];
      }
      if (initObj.hasOwnProperty('marks_in_odom')) {
        this.marks_in_odom = initObj.marks_in_odom
      }
      else {
        this.marks_in_odom = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LandmarkInDifferentCoordinates
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [marks_in_global]
    // Serialize the length for message field [marks_in_global]
    bufferOffset = _serializer.uint32(obj.marks_in_global.length, buffer, bufferOffset);
    obj.marks_in_global.forEach((val) => {
      bufferOffset = LasermarkEntry.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [marks_in_odom]
    // Serialize the length for message field [marks_in_odom]
    bufferOffset = _serializer.uint32(obj.marks_in_odom.length, buffer, bufferOffset);
    obj.marks_in_odom.forEach((val) => {
      bufferOffset = LasermarkEntry.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LandmarkInDifferentCoordinates
    let len;
    let data = new LandmarkInDifferentCoordinates(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [marks_in_global]
    // Deserialize array length for message field [marks_in_global]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.marks_in_global = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.marks_in_global[i] = LasermarkEntry.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [marks_in_odom]
    // Deserialize array length for message field [marks_in_odom]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.marks_in_odom = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.marks_in_odom[i] = LasermarkEntry.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.marks_in_global.forEach((val) => {
      length += LasermarkEntry.getMessageSize(val);
    });
    object.marks_in_odom.forEach((val) => {
      length += LasermarkEntry.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/LandmarkInDifferentCoordinates';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b3f2b6e476f632779f3d93bf956e9b30';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    cartographer_ros_msgs/LasermarkEntry[] marks_in_global
    cartographer_ros_msgs/LasermarkEntry[] marks_in_odom
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: cartographer_ros_msgs/LasermarkEntry
    string id
    float64 x
    float64 y
    float64 z
    float64 normal_x
    float64 normal_y
    float64 normal_z
    float32 pole_radius
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LandmarkInDifferentCoordinates(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.marks_in_global !== undefined) {
      resolved.marks_in_global = new Array(msg.marks_in_global.length);
      for (let i = 0; i < resolved.marks_in_global.length; ++i) {
        resolved.marks_in_global[i] = LasermarkEntry.Resolve(msg.marks_in_global[i]);
      }
    }
    else {
      resolved.marks_in_global = []
    }

    if (msg.marks_in_odom !== undefined) {
      resolved.marks_in_odom = new Array(msg.marks_in_odom.length);
      for (let i = 0; i < resolved.marks_in_odom.length; ++i) {
        resolved.marks_in_odom[i] = LasermarkEntry.Resolve(msg.marks_in_odom[i]);
      }
    }
    else {
      resolved.marks_in_odom = []
    }

    return resolved;
    }
};

module.exports = LandmarkInDifferentCoordinates;
