// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let jdrv_msgs = _finder('jdrv_msgs');

//-----------------------------------------------------------

class MotionSpeedExtend {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.extend_config = null;
      this.motion_speed = null;
    }
    else {
      if (initObj.hasOwnProperty('extend_config')) {
        this.extend_config = initObj.extend_config
      }
      else {
        this.extend_config = '';
      }
      if (initObj.hasOwnProperty('motion_speed')) {
        this.motion_speed = initObj.motion_speed
      }
      else {
        this.motion_speed = new jdrv_msgs.msg.MotionSpeed();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotionSpeedExtend
    // Serialize message field [extend_config]
    bufferOffset = _serializer.string(obj.extend_config, buffer, bufferOffset);
    // Serialize message field [motion_speed]
    bufferOffset = jdrv_msgs.msg.MotionSpeed.serialize(obj.motion_speed, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotionSpeedExtend
    let len;
    let data = new MotionSpeedExtend(null);
    // Deserialize message field [extend_config]
    data.extend_config = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [motion_speed]
    data.motion_speed = jdrv_msgs.msg.MotionSpeed.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.extend_config.length;
    length += jdrv_msgs.msg.MotionSpeed.getMessageSize(object.motion_speed);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_servo_msgs/MotionSpeedExtend';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '95058cc6b080c070427707bbe83db6fd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string extend_config
    jdrv_msgs/MotionSpeed motion_speed
    ================================================================================
    MSG: jdrv_msgs/MotionSpeed
    float64 stamp
    MotionActuator[] actuators
    float32 vx
    float32 vy
    float32 w
    
    ================================================================================
    MSG: jdrv_msgs/MotionActuator
    uint8 type
    MotionMotor[] motors
    
    ================================================================================
    MSG: jdrv_msgs/MotionMotor
    uint8 type
    float64[] data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotionSpeedExtend(null);
    if (msg.extend_config !== undefined) {
      resolved.extend_config = msg.extend_config;
    }
    else {
      resolved.extend_config = ''
    }

    if (msg.motion_speed !== undefined) {
      resolved.motion_speed = jdrv_msgs.msg.MotionSpeed.Resolve(msg.motion_speed)
    }
    else {
      resolved.motion_speed = new jdrv_msgs.msg.MotionSpeed()
    }

    return resolved;
    }
};

module.exports = MotionSpeedExtend;
