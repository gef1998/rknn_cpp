// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class MergeSubmapsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.origin_map_name = null;
      this.new_map_name = null;
      this.fix_nav_points = null;
      this.origin_nav_points = null;
    }
    else {
      if (initObj.hasOwnProperty('origin_map_name')) {
        this.origin_map_name = initObj.origin_map_name
      }
      else {
        this.origin_map_name = '';
      }
      if (initObj.hasOwnProperty('new_map_name')) {
        this.new_map_name = initObj.new_map_name
      }
      else {
        this.new_map_name = '';
      }
      if (initObj.hasOwnProperty('fix_nav_points')) {
        this.fix_nav_points = initObj.fix_nav_points
      }
      else {
        this.fix_nav_points = false;
      }
      if (initObj.hasOwnProperty('origin_nav_points')) {
        this.origin_nav_points = initObj.origin_nav_points
      }
      else {
        this.origin_nav_points = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MergeSubmapsRequest
    // Serialize message field [origin_map_name]
    bufferOffset = _serializer.string(obj.origin_map_name, buffer, bufferOffset);
    // Serialize message field [new_map_name]
    bufferOffset = _serializer.string(obj.new_map_name, buffer, bufferOffset);
    // Serialize message field [fix_nav_points]
    bufferOffset = _serializer.bool(obj.fix_nav_points, buffer, bufferOffset);
    // Serialize message field [origin_nav_points]
    // Serialize the length for message field [origin_nav_points]
    bufferOffset = _serializer.uint32(obj.origin_nav_points.length, buffer, bufferOffset);
    obj.origin_nav_points.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MergeSubmapsRequest
    let len;
    let data = new MergeSubmapsRequest(null);
    // Deserialize message field [origin_map_name]
    data.origin_map_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [new_map_name]
    data.new_map_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [fix_nav_points]
    data.fix_nav_points = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [origin_nav_points]
    // Deserialize array length for message field [origin_nav_points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.origin_nav_points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.origin_nav_points[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.origin_map_name.length;
    length += object.new_map_name.length;
    length += 56 * object.origin_nav_points.length;
    return length + 13;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/MergeSubmapsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd5d3122a9b31c957b816c77a059c9d22';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string origin_map_name
    string new_map_name
    bool fix_nav_points
    geometry_msgs/Pose[] origin_nav_points
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MergeSubmapsRequest(null);
    if (msg.origin_map_name !== undefined) {
      resolved.origin_map_name = msg.origin_map_name;
    }
    else {
      resolved.origin_map_name = ''
    }

    if (msg.new_map_name !== undefined) {
      resolved.new_map_name = msg.new_map_name;
    }
    else {
      resolved.new_map_name = ''
    }

    if (msg.fix_nav_points !== undefined) {
      resolved.fix_nav_points = msg.fix_nav_points;
    }
    else {
      resolved.fix_nav_points = false
    }

    if (msg.origin_nav_points !== undefined) {
      resolved.origin_nav_points = new Array(msg.origin_nav_points.length);
      for (let i = 0; i < resolved.origin_nav_points.length; ++i) {
        resolved.origin_nav_points[i] = geometry_msgs.msg.Pose.Resolve(msg.origin_nav_points[i]);
      }
    }
    else {
      resolved.origin_nav_points = []
    }

    return resolved;
    }
};

class MergeSubmapsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.update_nav_points = null;
      this.success = null;
      this.error_msgs = null;
    }
    else {
      if (initObj.hasOwnProperty('update_nav_points')) {
        this.update_nav_points = initObj.update_nav_points
      }
      else {
        this.update_nav_points = [];
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('error_msgs')) {
        this.error_msgs = initObj.error_msgs
      }
      else {
        this.error_msgs = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MergeSubmapsResponse
    // Serialize message field [update_nav_points]
    // Serialize the length for message field [update_nav_points]
    bufferOffset = _serializer.uint32(obj.update_nav_points.length, buffer, bufferOffset);
    obj.update_nav_points.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [error_msgs]
    bufferOffset = _serializer.string(obj.error_msgs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MergeSubmapsResponse
    let len;
    let data = new MergeSubmapsResponse(null);
    // Deserialize message field [update_nav_points]
    // Deserialize array length for message field [update_nav_points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.update_nav_points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.update_nav_points[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_msgs]
    data.error_msgs = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 56 * object.update_nav_points.length;
    length += object.error_msgs.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/MergeSubmapsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c12ca6acd99bb42e9b8530b712e087fe';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Pose[] update_nav_points
    bool success
    string error_msgs
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MergeSubmapsResponse(null);
    if (msg.update_nav_points !== undefined) {
      resolved.update_nav_points = new Array(msg.update_nav_points.length);
      for (let i = 0; i < resolved.update_nav_points.length; ++i) {
        resolved.update_nav_points[i] = geometry_msgs.msg.Pose.Resolve(msg.update_nav_points[i]);
      }
    }
    else {
      resolved.update_nav_points = []
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.error_msgs !== undefined) {
      resolved.error_msgs = msg.error_msgs;
    }
    else {
      resolved.error_msgs = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: MergeSubmapsRequest,
  Response: MergeSubmapsResponse,
  md5sum() { return 'fd882fb8eeec0a3c7f2f027988d6d71e'; },
  datatype() { return 'map_manager_msgs/MergeSubmaps'; }
};
