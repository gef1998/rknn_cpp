// Auto-generated. Do not edit!

// (in-package move_task_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class MotionTaskType {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.type = null;
    }
    else {
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotionTaskType
    // Serialize message field [type]
    bufferOffset = _serializer.int8(obj.type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotionTaskType
    let len;
    let data = new MotionTaskType(null);
    // Deserialize message field [type]
    data.type = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'move_task_msgs/MotionTaskType';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b5576d1cb1c529c9f5c9f35eab1ecc3e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #navigation type: localise_based odometry_based visual_servo line_followiing_vs
    int8 type
    int8 COMMON_TASK=0
    int8 MOTION_ROTATE=1   
    int8 MOTION_LINE_MOVE=2
    int8 MOTION_CURVE_MOVE=3
    int8 MOTION_BEZIER_MOVE=4
    int8 MOTION_RES=5
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotionTaskType(null);
    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    return resolved;
    }
};

// Constants for message
MotionTaskType.Constants = {
  COMMON_TASK: 0,
  MOTION_ROTATE: 1,
  MOTION_LINE_MOVE: 2,
  MOTION_CURVE_MOVE: 3,
  MOTION_BEZIER_MOVE: 4,
  MOTION_RES: 5,
}

module.exports = MotionTaskType;
