// Auto-generated. Do not edit!

// (in-package visual_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');
let std_msgs = _finder('std_msgs');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class FmKeyframe {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.project_image = null;
      this.src_image = null;
      this.pMe = null;
      this.eMp = null;
      this.intrinsic = null;
      this.distortion = null;
      this.ypr = null;
      this.extrinsicT = null;
      this.wh = null;
      this.sensor2odom = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('project_image')) {
        this.project_image = initObj.project_image
      }
      else {
        this.project_image = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('src_image')) {
        this.src_image = initObj.src_image
      }
      else {
        this.src_image = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('pMe')) {
        this.pMe = initObj.pMe
      }
      else {
        this.pMe = [];
      }
      if (initObj.hasOwnProperty('eMp')) {
        this.eMp = initObj.eMp
      }
      else {
        this.eMp = [];
      }
      if (initObj.hasOwnProperty('intrinsic')) {
        this.intrinsic = initObj.intrinsic
      }
      else {
        this.intrinsic = [];
      }
      if (initObj.hasOwnProperty('distortion')) {
        this.distortion = initObj.distortion
      }
      else {
        this.distortion = [];
      }
      if (initObj.hasOwnProperty('ypr')) {
        this.ypr = initObj.ypr
      }
      else {
        this.ypr = [];
      }
      if (initObj.hasOwnProperty('extrinsicT')) {
        this.extrinsicT = initObj.extrinsicT
      }
      else {
        this.extrinsicT = [];
      }
      if (initObj.hasOwnProperty('wh')) {
        this.wh = initObj.wh
      }
      else {
        this.wh = [];
      }
      if (initObj.hasOwnProperty('sensor2odom')) {
        this.sensor2odom = initObj.sensor2odom
      }
      else {
        this.sensor2odom = new geometry_msgs.msg.Transform();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FmKeyframe
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [project_image]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.project_image, buffer, bufferOffset);
    // Serialize message field [src_image]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.src_image, buffer, bufferOffset);
    // Serialize message field [pMe]
    bufferOffset = _arraySerializer.float64(obj.pMe, buffer, bufferOffset, null);
    // Serialize message field [eMp]
    bufferOffset = _arraySerializer.float64(obj.eMp, buffer, bufferOffset, null);
    // Serialize message field [intrinsic]
    bufferOffset = _arraySerializer.float64(obj.intrinsic, buffer, bufferOffset, null);
    // Serialize message field [distortion]
    bufferOffset = _arraySerializer.float64(obj.distortion, buffer, bufferOffset, null);
    // Serialize message field [ypr]
    bufferOffset = _arraySerializer.float64(obj.ypr, buffer, bufferOffset, null);
    // Serialize message field [extrinsicT]
    bufferOffset = _arraySerializer.float64(obj.extrinsicT, buffer, bufferOffset, null);
    // Serialize message field [wh]
    bufferOffset = _arraySerializer.float64(obj.wh, buffer, bufferOffset, null);
    // Serialize message field [sensor2odom]
    bufferOffset = geometry_msgs.msg.Transform.serialize(obj.sensor2odom, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FmKeyframe
    let len;
    let data = new FmKeyframe(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [project_image]
    data.project_image = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [src_image]
    data.src_image = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [pMe]
    data.pMe = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [eMp]
    data.eMp = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [intrinsic]
    data.intrinsic = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [distortion]
    data.distortion = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [ypr]
    data.ypr = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [extrinsicT]
    data.extrinsicT = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [wh]
    data.wh = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [sensor2odom]
    data.sensor2odom = geometry_msgs.msg.Transform.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += sensor_msgs.msg.Image.getMessageSize(object.project_image);
    length += sensor_msgs.msg.Image.getMessageSize(object.src_image);
    length += 8 * object.pMe.length;
    length += 8 * object.eMp.length;
    length += 8 * object.intrinsic.length;
    length += 8 * object.distortion.length;
    length += 8 * object.ypr.length;
    length += 8 * object.extrinsicT.length;
    length += 8 * object.wh.length;
    return length + 84;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_msgs/FmKeyframe';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9d1e14b6f164360faf7b303399f567da';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Copyright 2016 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    std_msgs/Header header
    sensor_msgs/Image project_image
    sensor_msgs/Image src_image
    float64[] pMe
    float64[] eMp
    float64[] intrinsic
    float64[] distortion
    float64[] ypr
    float64[] extrinsicT
    float64[] wh
    geometry_msgs/Transform sensor2odom
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of cameara
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    ================================================================================
    MSG: geometry_msgs/Transform
    # This represents the transform between two coordinate frames in free space.
    
    Vector3 translation
    Quaternion rotation
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FmKeyframe(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.project_image !== undefined) {
      resolved.project_image = sensor_msgs.msg.Image.Resolve(msg.project_image)
    }
    else {
      resolved.project_image = new sensor_msgs.msg.Image()
    }

    if (msg.src_image !== undefined) {
      resolved.src_image = sensor_msgs.msg.Image.Resolve(msg.src_image)
    }
    else {
      resolved.src_image = new sensor_msgs.msg.Image()
    }

    if (msg.pMe !== undefined) {
      resolved.pMe = msg.pMe;
    }
    else {
      resolved.pMe = []
    }

    if (msg.eMp !== undefined) {
      resolved.eMp = msg.eMp;
    }
    else {
      resolved.eMp = []
    }

    if (msg.intrinsic !== undefined) {
      resolved.intrinsic = msg.intrinsic;
    }
    else {
      resolved.intrinsic = []
    }

    if (msg.distortion !== undefined) {
      resolved.distortion = msg.distortion;
    }
    else {
      resolved.distortion = []
    }

    if (msg.ypr !== undefined) {
      resolved.ypr = msg.ypr;
    }
    else {
      resolved.ypr = []
    }

    if (msg.extrinsicT !== undefined) {
      resolved.extrinsicT = msg.extrinsicT;
    }
    else {
      resolved.extrinsicT = []
    }

    if (msg.wh !== undefined) {
      resolved.wh = msg.wh;
    }
    else {
      resolved.wh = []
    }

    if (msg.sensor2odom !== undefined) {
      resolved.sensor2odom = geometry_msgs.msg.Transform.Resolve(msg.sensor2odom)
    }
    else {
      resolved.sensor2odom = new geometry_msgs.msg.Transform()
    }

    return resolved;
    }
};

module.exports = FmKeyframe;
