// Auto-generated. Do not edit!

// (in-package visual_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class VioState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.T_M_I = null;
      this.v_M_I = null;
      this.Acb = null;
      this.Gyb = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('T_M_I')) {
        this.T_M_I = initObj.T_M_I
      }
      else {
        this.T_M_I = new geometry_msgs.msg.Transform();
      }
      if (initObj.hasOwnProperty('v_M_I')) {
        this.v_M_I = initObj.v_M_I
      }
      else {
        this.v_M_I = [];
      }
      if (initObj.hasOwnProperty('Acb')) {
        this.Acb = initObj.Acb
      }
      else {
        this.Acb = [];
      }
      if (initObj.hasOwnProperty('Gyb')) {
        this.Gyb = initObj.Gyb
      }
      else {
        this.Gyb = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VioState
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [T_M_I]
    bufferOffset = geometry_msgs.msg.Transform.serialize(obj.T_M_I, buffer, bufferOffset);
    // Serialize message field [v_M_I]
    bufferOffset = _arraySerializer.float64(obj.v_M_I, buffer, bufferOffset, null);
    // Serialize message field [Acb]
    bufferOffset = _arraySerializer.float64(obj.Acb, buffer, bufferOffset, null);
    // Serialize message field [Gyb]
    bufferOffset = _arraySerializer.float64(obj.Gyb, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VioState
    let len;
    let data = new VioState(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [T_M_I]
    data.T_M_I = geometry_msgs.msg.Transform.deserialize(buffer, bufferOffset);
    // Deserialize message field [v_M_I]
    data.v_M_I = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [Acb]
    data.Acb = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [Gyb]
    data.Gyb = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += 8 * object.v_M_I.length;
    length += 8 * object.Acb.length;
    length += 8 * object.Gyb.length;
    return length + 68;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_msgs/VioState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e558ed942569b8dbfa9ff3b6fcb2f492';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Copyright 2016 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    std_msgs/Header header
    geometry_msgs/Transform T_M_I
    float64[] v_M_I
    float64[] Acb
    float64[] Gyb
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Transform
    # This represents the transform between two coordinate frames in free space.
    
    Vector3 translation
    Quaternion rotation
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VioState(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.T_M_I !== undefined) {
      resolved.T_M_I = geometry_msgs.msg.Transform.Resolve(msg.T_M_I)
    }
    else {
      resolved.T_M_I = new geometry_msgs.msg.Transform()
    }

    if (msg.v_M_I !== undefined) {
      resolved.v_M_I = msg.v_M_I;
    }
    else {
      resolved.v_M_I = []
    }

    if (msg.Acb !== undefined) {
      resolved.Acb = msg.Acb;
    }
    else {
      resolved.Acb = []
    }

    if (msg.Gyb !== undefined) {
      resolved.Gyb = msg.Gyb;
    }
    else {
      resolved.Gyb = []
    }

    return resolved;
    }
};

module.exports = VioState;
