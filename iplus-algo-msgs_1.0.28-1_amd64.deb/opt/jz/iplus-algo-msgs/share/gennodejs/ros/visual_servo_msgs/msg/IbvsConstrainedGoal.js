// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');
let geometry_msgs = _finder('geometry_msgs');
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class IbvsConstrainedGoal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sensor_type = null;
      this.camera_type = null;
      this.tag_type = null;
      this.vs_type = null;
      this.is_lateral_base = null;
      this.useLessScan = null;
      this.templateScan = null;
      this.templateScan_baseInMap = null;
      this.ref_base2map = null;
      this.left_image = null;
      this.right_image = null;
      this.targetInWorld = null;
      this.targetInWorld_3d = null;
      this.reconfigure_json_string = null;
      this.minCorner = null;
      this.maxCorner = null;
    }
    else {
      if (initObj.hasOwnProperty('sensor_type')) {
        this.sensor_type = initObj.sensor_type
      }
      else {
        this.sensor_type = 0;
      }
      if (initObj.hasOwnProperty('camera_type')) {
        this.camera_type = initObj.camera_type
      }
      else {
        this.camera_type = 0;
      }
      if (initObj.hasOwnProperty('tag_type')) {
        this.tag_type = initObj.tag_type
      }
      else {
        this.tag_type = 0;
      }
      if (initObj.hasOwnProperty('vs_type')) {
        this.vs_type = initObj.vs_type
      }
      else {
        this.vs_type = 0;
      }
      if (initObj.hasOwnProperty('is_lateral_base')) {
        this.is_lateral_base = initObj.is_lateral_base
      }
      else {
        this.is_lateral_base = false;
      }
      if (initObj.hasOwnProperty('useLessScan')) {
        this.useLessScan = initObj.useLessScan
      }
      else {
        this.useLessScan = false;
      }
      if (initObj.hasOwnProperty('templateScan')) {
        this.templateScan = initObj.templateScan
      }
      else {
        this.templateScan = new sensor_msgs.msg.LaserScan();
      }
      if (initObj.hasOwnProperty('templateScan_baseInMap')) {
        this.templateScan_baseInMap = initObj.templateScan_baseInMap
      }
      else {
        this.templateScan_baseInMap = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('ref_base2map')) {
        this.ref_base2map = initObj.ref_base2map
      }
      else {
        this.ref_base2map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('left_image')) {
        this.left_image = initObj.left_image
      }
      else {
        this.left_image = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('right_image')) {
        this.right_image = initObj.right_image
      }
      else {
        this.right_image = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('targetInWorld')) {
        this.targetInWorld = initObj.targetInWorld
      }
      else {
        this.targetInWorld = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('targetInWorld_3d')) {
        this.targetInWorld_3d = initObj.targetInWorld_3d
      }
      else {
        this.targetInWorld_3d = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('reconfigure_json_string')) {
        this.reconfigure_json_string = initObj.reconfigure_json_string
      }
      else {
        this.reconfigure_json_string = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('minCorner')) {
        this.minCorner = initObj.minCorner
      }
      else {
        this.minCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('maxCorner')) {
        this.maxCorner = initObj.maxCorner
      }
      else {
        this.maxCorner = new Array(2).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IbvsConstrainedGoal
    // Serialize message field [sensor_type]
    bufferOffset = _serializer.uint8(obj.sensor_type, buffer, bufferOffset);
    // Serialize message field [camera_type]
    bufferOffset = _serializer.uint8(obj.camera_type, buffer, bufferOffset);
    // Serialize message field [tag_type]
    bufferOffset = _serializer.uint8(obj.tag_type, buffer, bufferOffset);
    // Serialize message field [vs_type]
    bufferOffset = _serializer.uint8(obj.vs_type, buffer, bufferOffset);
    // Serialize message field [is_lateral_base]
    bufferOffset = _serializer.bool(obj.is_lateral_base, buffer, bufferOffset);
    // Serialize message field [useLessScan]
    bufferOffset = _serializer.bool(obj.useLessScan, buffer, bufferOffset);
    // Serialize message field [templateScan]
    bufferOffset = sensor_msgs.msg.LaserScan.serialize(obj.templateScan, buffer, bufferOffset);
    // Serialize message field [templateScan_baseInMap]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.templateScan_baseInMap, buffer, bufferOffset);
    // Serialize message field [ref_base2map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.ref_base2map, buffer, bufferOffset);
    // Serialize message field [left_image]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.left_image, buffer, bufferOffset);
    // Serialize message field [right_image]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.right_image, buffer, bufferOffset);
    // Serialize message field [targetInWorld]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.targetInWorld, buffer, bufferOffset);
    // Serialize message field [targetInWorld_3d]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.targetInWorld_3d, buffer, bufferOffset);
    // Serialize message field [reconfigure_json_string]
    bufferOffset = std_msgs.msg.String.serialize(obj.reconfigure_json_string, buffer, bufferOffset);
    // Check that the constant length array field [minCorner] has the right length
    if (obj.minCorner.length !== 2) {
      throw new Error('Unable to serialize array field minCorner - length must be 2')
    }
    // Serialize message field [minCorner]
    bufferOffset = _arraySerializer.float32(obj.minCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [maxCorner] has the right length
    if (obj.maxCorner.length !== 2) {
      throw new Error('Unable to serialize array field maxCorner - length must be 2')
    }
    // Serialize message field [maxCorner]
    bufferOffset = _arraySerializer.float32(obj.maxCorner, buffer, bufferOffset, 2);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IbvsConstrainedGoal
    let len;
    let data = new IbvsConstrainedGoal(null);
    // Deserialize message field [sensor_type]
    data.sensor_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [camera_type]
    data.camera_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [tag_type]
    data.tag_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [vs_type]
    data.vs_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [is_lateral_base]
    data.is_lateral_base = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [useLessScan]
    data.useLessScan = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [templateScan]
    data.templateScan = sensor_msgs.msg.LaserScan.deserialize(buffer, bufferOffset);
    // Deserialize message field [templateScan_baseInMap]
    data.templateScan_baseInMap = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [ref_base2map]
    data.ref_base2map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [left_image]
    data.left_image = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [right_image]
    data.right_image = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [targetInWorld]
    data.targetInWorld = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [targetInWorld_3d]
    data.targetInWorld_3d = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [reconfigure_json_string]
    data.reconfigure_json_string = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [minCorner]
    data.minCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [maxCorner]
    data.maxCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += sensor_msgs.msg.LaserScan.getMessageSize(object.templateScan);
    length += sensor_msgs.msg.Image.getMessageSize(object.left_image);
    length += sensor_msgs.msg.Image.getMessageSize(object.right_image);
    length += std_msgs.msg.String.getMessageSize(object.reconfigure_json_string);
    return length + 182;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_servo_msgs/IbvsConstrainedGoal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '51f6c9bd3c1ef061cef6b9c6f9b72860';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    #goal definition
    uint8 sensor_type
    uint8 CAMERA_SENSOR = 0
    uint8 LASER_SENSOR = 1
    uint8 ODOM_SENSOR = 2
    uint8 DUAL_CAMERA_SENSOR = 3
    uint8 MAP_FROM_TF_SENSOR = 4
    uint8 ODOM_FROM_TF_SENSOR = 5
    
    uint8 camera_type
    uint8 UP_CAMERA = 0
    uint8 DOWN_CAMERA = 1
    uint8 FRONT_CAMERA = 2
    uint8 tag_type
    uint8 SHELF_TAG = 0
    uint8 NORMAL_TAG = 1 
    uint8 FRONT_VIEW_TAG = 3
    uint8 vs_type
    uint8 TO_POINT = 0
    uint8 FOLLOW_LINE = 1
    uint8 THREE_STAGE_MOVE = 2
    uint8 STRAIGHT_LINE = 3
    uint8 ORIGINAL_PLACE_ROTATE = 4
    
    bool is_lateral_base
    
    bool useLessScan
    sensor_msgs/LaserScan templateScan
    geometry_msgs/Pose2D templateScan_baseInMap
    
    geometry_msgs/Pose ref_base2map
    sensor_msgs/Image left_image
    sensor_msgs/Image right_image
    
    geometry_msgs/Pose2D targetInWorld
    geometry_msgs/Pose targetInWorld_3d
    
    std_msgs/String reconfigure_json_string
    
    # for ICP
    float32[2] minCorner
    float32[2] maxCorner
    
    ================================================================================
    MSG: sensor_msgs/LaserScan
    # Single scan from a planar laser range-finder
    #
    # If you have another ranging device with different behavior (e.g. a sonar
    # array), please find or create a different message, since applications
    # will make fairly laser-specific assumptions about this data
    
    Header header            # timestamp in the header is the acquisition time of 
                             # the first ray in the scan.
                             #
                             # in frame frame_id, angles are measured around 
                             # the positive Z axis (counterclockwise, if Z is up)
                             # with zero angle being forward along the x axis
                             
    float32 angle_min        # start angle of the scan [rad]
    float32 angle_max        # end angle of the scan [rad]
    float32 angle_increment  # angular distance between measurements [rad]
    
    float32 time_increment   # time between measurements [seconds] - if your scanner
                             # is moving, this will be used in interpolating position
                             # of 3d points
    float32 scan_time        # time between scans [seconds]
    
    float32 range_min        # minimum range value [m]
    float32 range_max        # maximum range value [m]
    
    float32[] ranges         # range data [m] (Note: values < range_min or > range_max should be discarded)
    float32[] intensities    # intensity data [device-specific units].  If your
                             # device does not provide intensities, please leave
                             # the array empty.
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of cameara
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IbvsConstrainedGoal(null);
    if (msg.sensor_type !== undefined) {
      resolved.sensor_type = msg.sensor_type;
    }
    else {
      resolved.sensor_type = 0
    }

    if (msg.camera_type !== undefined) {
      resolved.camera_type = msg.camera_type;
    }
    else {
      resolved.camera_type = 0
    }

    if (msg.tag_type !== undefined) {
      resolved.tag_type = msg.tag_type;
    }
    else {
      resolved.tag_type = 0
    }

    if (msg.vs_type !== undefined) {
      resolved.vs_type = msg.vs_type;
    }
    else {
      resolved.vs_type = 0
    }

    if (msg.is_lateral_base !== undefined) {
      resolved.is_lateral_base = msg.is_lateral_base;
    }
    else {
      resolved.is_lateral_base = false
    }

    if (msg.useLessScan !== undefined) {
      resolved.useLessScan = msg.useLessScan;
    }
    else {
      resolved.useLessScan = false
    }

    if (msg.templateScan !== undefined) {
      resolved.templateScan = sensor_msgs.msg.LaserScan.Resolve(msg.templateScan)
    }
    else {
      resolved.templateScan = new sensor_msgs.msg.LaserScan()
    }

    if (msg.templateScan_baseInMap !== undefined) {
      resolved.templateScan_baseInMap = geometry_msgs.msg.Pose2D.Resolve(msg.templateScan_baseInMap)
    }
    else {
      resolved.templateScan_baseInMap = new geometry_msgs.msg.Pose2D()
    }

    if (msg.ref_base2map !== undefined) {
      resolved.ref_base2map = geometry_msgs.msg.Pose.Resolve(msg.ref_base2map)
    }
    else {
      resolved.ref_base2map = new geometry_msgs.msg.Pose()
    }

    if (msg.left_image !== undefined) {
      resolved.left_image = sensor_msgs.msg.Image.Resolve(msg.left_image)
    }
    else {
      resolved.left_image = new sensor_msgs.msg.Image()
    }

    if (msg.right_image !== undefined) {
      resolved.right_image = sensor_msgs.msg.Image.Resolve(msg.right_image)
    }
    else {
      resolved.right_image = new sensor_msgs.msg.Image()
    }

    if (msg.targetInWorld !== undefined) {
      resolved.targetInWorld = geometry_msgs.msg.Pose2D.Resolve(msg.targetInWorld)
    }
    else {
      resolved.targetInWorld = new geometry_msgs.msg.Pose2D()
    }

    if (msg.targetInWorld_3d !== undefined) {
      resolved.targetInWorld_3d = geometry_msgs.msg.Pose.Resolve(msg.targetInWorld_3d)
    }
    else {
      resolved.targetInWorld_3d = new geometry_msgs.msg.Pose()
    }

    if (msg.reconfigure_json_string !== undefined) {
      resolved.reconfigure_json_string = std_msgs.msg.String.Resolve(msg.reconfigure_json_string)
    }
    else {
      resolved.reconfigure_json_string = new std_msgs.msg.String()
    }

    if (msg.minCorner !== undefined) {
      resolved.minCorner = msg.minCorner;
    }
    else {
      resolved.minCorner = new Array(2).fill(0)
    }

    if (msg.maxCorner !== undefined) {
      resolved.maxCorner = msg.maxCorner;
    }
    else {
      resolved.maxCorner = new Array(2).fill(0)
    }

    return resolved;
    }
};

// Constants for message
IbvsConstrainedGoal.Constants = {
  CAMERA_SENSOR: 0,
  LASER_SENSOR: 1,
  ODOM_SENSOR: 2,
  DUAL_CAMERA_SENSOR: 3,
  MAP_FROM_TF_SENSOR: 4,
  ODOM_FROM_TF_SENSOR: 5,
  UP_CAMERA: 0,
  DOWN_CAMERA: 1,
  FRONT_CAMERA: 2,
  SHELF_TAG: 0,
  NORMAL_TAG: 1,
  FRONT_VIEW_TAG: 3,
  TO_POINT: 0,
  FOLLOW_LINE: 1,
  THREE_STAGE_MOVE: 2,
  STRAIGHT_LINE: 3,
  ORIGINAL_PLACE_ROTATE: 4,
}

module.exports = IbvsConstrainedGoal;
