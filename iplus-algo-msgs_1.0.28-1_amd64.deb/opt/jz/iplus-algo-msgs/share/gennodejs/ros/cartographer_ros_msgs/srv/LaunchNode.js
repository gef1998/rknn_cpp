// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class LaunchNodeRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LaunchNodeRequest
    // Serialize message field [status]
    bufferOffset = _serializer.int32(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LaunchNodeRequest
    let len;
    let data = new LaunchNodeRequest(null);
    // Deserialize message field [status]
    data.status = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/LaunchNodeRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '580235a529200d5c450c7843136139d4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 STATUS_IDLE=-1
    int32 STATUS_MAPPING=0
    int32 STATUS_LOCALIZATION=1
    int32 STATUS_PATCH_MAPPING=2
    
    int32 status
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LaunchNodeRequest(null);
    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
LaunchNodeRequest.Constants = {
  STATUS_IDLE: -1,
  STATUS_MAPPING: 0,
  STATUS_LOCALIZATION: 1,
  STATUS_PATCH_MAPPING: 2,
}

class LaunchNodeResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_msgs = null;
    }
    else {
      if (initObj.hasOwnProperty('error_msgs')) {
        this.error_msgs = initObj.error_msgs
      }
      else {
        this.error_msgs = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LaunchNodeResponse
    // Serialize message field [error_msgs]
    bufferOffset = _serializer.string(obj.error_msgs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LaunchNodeResponse
    let len;
    let data = new LaunchNodeResponse(null);
    // Deserialize message field [error_msgs]
    data.error_msgs = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_msgs.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/LaunchNodeResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '31076761bb7a15c7d145b393c8a56624';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_msgs
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LaunchNodeResponse(null);
    if (msg.error_msgs !== undefined) {
      resolved.error_msgs = msg.error_msgs;
    }
    else {
      resolved.error_msgs = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: LaunchNodeRequest,
  Response: LaunchNodeResponse,
  md5sum() { return 'fdf6fcd63256cb13ffc59c96e5158178'; },
  datatype() { return 'cartographer_ros_msgs/LaunchNode'; }
};
