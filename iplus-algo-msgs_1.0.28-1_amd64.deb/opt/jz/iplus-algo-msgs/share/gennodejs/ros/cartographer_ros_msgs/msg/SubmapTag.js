// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class SubmapTag {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.tag_ns = null;
      this.tag_id = null;
      this.tag2base = null;
      this.base2odom = null;
      this.debug_flag = null;
      this.localization_type = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('tag_ns')) {
        this.tag_ns = initObj.tag_ns
      }
      else {
        this.tag_ns = '';
      }
      if (initObj.hasOwnProperty('tag_id')) {
        this.tag_id = initObj.tag_id
      }
      else {
        this.tag_id = 0;
      }
      if (initObj.hasOwnProperty('tag2base')) {
        this.tag2base = initObj.tag2base
      }
      else {
        this.tag2base = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('base2odom')) {
        this.base2odom = initObj.base2odom
      }
      else {
        this.base2odom = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('debug_flag')) {
        this.debug_flag = initObj.debug_flag
      }
      else {
        this.debug_flag = false;
      }
      if (initObj.hasOwnProperty('localization_type')) {
        this.localization_type = initObj.localization_type
      }
      else {
        this.localization_type = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SubmapTag
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [tag_ns]
    bufferOffset = _serializer.string(obj.tag_ns, buffer, bufferOffset);
    // Serialize message field [tag_id]
    bufferOffset = _serializer.int32(obj.tag_id, buffer, bufferOffset);
    // Serialize message field [tag2base]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.tag2base, buffer, bufferOffset);
    // Serialize message field [base2odom]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.base2odom, buffer, bufferOffset);
    // Serialize message field [debug_flag]
    bufferOffset = _serializer.bool(obj.debug_flag, buffer, bufferOffset);
    // Serialize message field [localization_type]
    bufferOffset = _serializer.string(obj.localization_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SubmapTag
    let len;
    let data = new SubmapTag(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [tag_ns]
    data.tag_ns = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [tag_id]
    data.tag_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [tag2base]
    data.tag2base = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [base2odom]
    data.base2odom = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [debug_flag]
    data.debug_flag = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [localization_type]
    data.localization_type = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.tag_ns.length;
    length += object.localization_type.length;
    return length + 125;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/SubmapTag';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '970186e1f7585e36e75a1fddb64372e9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    string tag_ns
    int32 tag_id
    geometry_msgs/Pose tag2base
    geometry_msgs/Pose base2odom
    bool debug_flag
    string localization_type
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SubmapTag(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.tag_ns !== undefined) {
      resolved.tag_ns = msg.tag_ns;
    }
    else {
      resolved.tag_ns = ''
    }

    if (msg.tag_id !== undefined) {
      resolved.tag_id = msg.tag_id;
    }
    else {
      resolved.tag_id = 0
    }

    if (msg.tag2base !== undefined) {
      resolved.tag2base = geometry_msgs.msg.Pose.Resolve(msg.tag2base)
    }
    else {
      resolved.tag2base = new geometry_msgs.msg.Pose()
    }

    if (msg.base2odom !== undefined) {
      resolved.base2odom = geometry_msgs.msg.Pose.Resolve(msg.base2odom)
    }
    else {
      resolved.base2odom = new geometry_msgs.msg.Pose()
    }

    if (msg.debug_flag !== undefined) {
      resolved.debug_flag = msg.debug_flag;
    }
    else {
      resolved.debug_flag = false
    }

    if (msg.localization_type !== undefined) {
      resolved.localization_type = msg.localization_type;
    }
    else {
      resolved.localization_type = ''
    }

    return resolved;
    }
};

module.exports = SubmapTag;
