// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class VisualServoTeachingRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.camera_type = null;
      this.tag_type = null;
      this.is_lateral_base = null;
      this.dock_type = null;
      this.configure_json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('camera_type')) {
        this.camera_type = initObj.camera_type
      }
      else {
        this.camera_type = 0;
      }
      if (initObj.hasOwnProperty('tag_type')) {
        this.tag_type = initObj.tag_type
      }
      else {
        this.tag_type = 0;
      }
      if (initObj.hasOwnProperty('is_lateral_base')) {
        this.is_lateral_base = initObj.is_lateral_base
      }
      else {
        this.is_lateral_base = false;
      }
      if (initObj.hasOwnProperty('dock_type')) {
        this.dock_type = initObj.dock_type
      }
      else {
        this.dock_type = 0;
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VisualServoTeachingRequest
    // Serialize message field [camera_type]
    bufferOffset = _serializer.uint8(obj.camera_type, buffer, bufferOffset);
    // Serialize message field [tag_type]
    bufferOffset = _serializer.uint8(obj.tag_type, buffer, bufferOffset);
    // Serialize message field [is_lateral_base]
    bufferOffset = _serializer.bool(obj.is_lateral_base, buffer, bufferOffset);
    // Serialize message field [dock_type]
    bufferOffset = _serializer.uint8(obj.dock_type, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VisualServoTeachingRequest
    let len;
    let data = new VisualServoTeachingRequest(null);
    // Deserialize message field [camera_type]
    data.camera_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [tag_type]
    data.tag_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [is_lateral_base]
    data.is_lateral_base = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [dock_type]
    data.dock_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.configure_json_string.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/VisualServoTeachingRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9bb503c483d65fe9d922e0e62818a138';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 camera_type
    uint8 UP_CAMERA = 0
    uint8 DOWN_CAMERA = 1
    uint8 FRONT_CAMERA = 2
    uint8 tag_type
    uint8 SHELF_TAG = 0
    uint8 NORMAL_TAG = 1
    uint8 LANDMARK_TAG = 2
    uint8 FRONT_VIEW_TAG = 3
    bool is_lateral_base
    uint8  dock_type
    string configure_json_string
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VisualServoTeachingRequest(null);
    if (msg.camera_type !== undefined) {
      resolved.camera_type = msg.camera_type;
    }
    else {
      resolved.camera_type = 0
    }

    if (msg.tag_type !== undefined) {
      resolved.tag_type = msg.tag_type;
    }
    else {
      resolved.tag_type = 0
    }

    if (msg.is_lateral_base !== undefined) {
      resolved.is_lateral_base = msg.is_lateral_base;
    }
    else {
      resolved.is_lateral_base = false
    }

    if (msg.dock_type !== undefined) {
      resolved.dock_type = msg.dock_type;
    }
    else {
      resolved.dock_type = 0
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    return resolved;
    }
};

// Constants for message
VisualServoTeachingRequest.Constants = {
  UP_CAMERA: 0,
  DOWN_CAMERA: 1,
  FRONT_CAMERA: 2,
  SHELF_TAG: 0,
  NORMAL_TAG: 1,
  LANDMARK_TAG: 2,
  FRONT_VIEW_TAG: 3,
}

class VisualServoTeachingResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.targetInWorld = null;
      this.targetInWorld_3d = null;
      this.tag_id = null;
      this.configure_json_string = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('targetInWorld')) {
        this.targetInWorld = initObj.targetInWorld
      }
      else {
        this.targetInWorld = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('targetInWorld_3d')) {
        this.targetInWorld_3d = initObj.targetInWorld_3d
      }
      else {
        this.targetInWorld_3d = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('tag_id')) {
        this.tag_id = initObj.tag_id
      }
      else {
        this.tag_id = 0;
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VisualServoTeachingResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [targetInWorld]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.targetInWorld, buffer, bufferOffset);
    // Serialize message field [targetInWorld_3d]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.targetInWorld_3d, buffer, bufferOffset);
    // Serialize message field [tag_id]
    bufferOffset = _serializer.int32(obj.tag_id, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VisualServoTeachingResponse
    let len;
    let data = new VisualServoTeachingResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [targetInWorld]
    data.targetInWorld = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [targetInWorld_3d]
    data.targetInWorld_3d = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [tag_id]
    data.tag_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.configure_json_string.length;
    length += object.error_message.length;
    return length + 92;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/VisualServoTeachingResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ba8c4319328f1c3a312858e361e0e8f5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    geometry_msgs/Pose2D targetInWorld
    geometry_msgs/Pose targetInWorld_3d
    int32 tag_id
    string configure_json_string
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VisualServoTeachingResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.targetInWorld !== undefined) {
      resolved.targetInWorld = geometry_msgs.msg.Pose2D.Resolve(msg.targetInWorld)
    }
    else {
      resolved.targetInWorld = new geometry_msgs.msg.Pose2D()
    }

    if (msg.targetInWorld_3d !== undefined) {
      resolved.targetInWorld_3d = geometry_msgs.msg.Pose.Resolve(msg.targetInWorld_3d)
    }
    else {
      resolved.targetInWorld_3d = new geometry_msgs.msg.Pose()
    }

    if (msg.tag_id !== undefined) {
      resolved.tag_id = msg.tag_id;
    }
    else {
      resolved.tag_id = 0
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: VisualServoTeachingRequest,
  Response: VisualServoTeachingResponse,
  md5sum() { return 'a03fb4de0ccb795c081de72f7866ab9d'; },
  datatype() { return 'visual_servo_msgs/VisualServoTeaching'; }
};
