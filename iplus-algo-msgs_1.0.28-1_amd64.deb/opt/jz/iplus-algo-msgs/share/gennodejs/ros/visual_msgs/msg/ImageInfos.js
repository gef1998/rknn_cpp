// Auto-generated. Do not edit!

// (in-package visual_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TagInfos = require('./TagInfos.js');

//-----------------------------------------------------------

class ImageInfos {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.camera_id = null;
      this.tag_infos = null;
    }
    else {
      if (initObj.hasOwnProperty('camera_id')) {
        this.camera_id = initObj.camera_id
      }
      else {
        this.camera_id = 0;
      }
      if (initObj.hasOwnProperty('tag_infos')) {
        this.tag_infos = initObj.tag_infos
      }
      else {
        this.tag_infos = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ImageInfos
    // Serialize message field [camera_id]
    bufferOffset = _serializer.int32(obj.camera_id, buffer, bufferOffset);
    // Serialize message field [tag_infos]
    // Serialize the length for message field [tag_infos]
    bufferOffset = _serializer.uint32(obj.tag_infos.length, buffer, bufferOffset);
    obj.tag_infos.forEach((val) => {
      bufferOffset = TagInfos.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ImageInfos
    let len;
    let data = new ImageInfos(null);
    // Deserialize message field [camera_id]
    data.camera_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [tag_infos]
    // Deserialize array length for message field [tag_infos]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tag_infos = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tag_infos[i] = TagInfos.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.tag_infos.forEach((val) => {
      length += TagInfos.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_msgs/ImageInfos';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0fdb7c6a51ea8ff9313a5be0cf2287a0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 camera_id
    TagInfos[] tag_infos
    
    ================================================================================
    MSG: visual_msgs/TagInfos
    int32 tag_id
    Point[] points
    
    ================================================================================
    MSG: visual_msgs/Point
    float64 u
    float64 v
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ImageInfos(null);
    if (msg.camera_id !== undefined) {
      resolved.camera_id = msg.camera_id;
    }
    else {
      resolved.camera_id = 0
    }

    if (msg.tag_infos !== undefined) {
      resolved.tag_infos = new Array(msg.tag_infos.length);
      for (let i = 0; i < resolved.tag_infos.length; ++i) {
        resolved.tag_infos[i] = TagInfos.Resolve(msg.tag_infos[i]);
      }
    }
    else {
      resolved.tag_infos = []
    }

    return resolved;
    }
};

module.exports = ImageInfos;
