// Auto-generated. Do not edit!

// (in-package caliber_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class RelativePoseOfTwoTagsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tag1_id = null;
      this.tag2_id = null;
    }
    else {
      if (initObj.hasOwnProperty('tag1_id')) {
        this.tag1_id = initObj.tag1_id
      }
      else {
        this.tag1_id = 0;
      }
      if (initObj.hasOwnProperty('tag2_id')) {
        this.tag2_id = initObj.tag2_id
      }
      else {
        this.tag2_id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RelativePoseOfTwoTagsRequest
    // Serialize message field [tag1_id]
    bufferOffset = _serializer.int32(obj.tag1_id, buffer, bufferOffset);
    // Serialize message field [tag2_id]
    bufferOffset = _serializer.int32(obj.tag2_id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RelativePoseOfTwoTagsRequest
    let len;
    let data = new RelativePoseOfTwoTagsRequest(null);
    // Deserialize message field [tag1_id]
    data.tag1_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [tag2_id]
    data.tag2_id = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'caliber_msgs/RelativePoseOfTwoTagsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fec483cf18ca4c44d027f847559f54f5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 tag1_id
    int32 tag2_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RelativePoseOfTwoTagsRequest(null);
    if (msg.tag1_id !== undefined) {
      resolved.tag1_id = msg.tag1_id;
    }
    else {
      resolved.tag1_id = 0
    }

    if (msg.tag2_id !== undefined) {
      resolved.tag2_id = msg.tag2_id;
    }
    else {
      resolved.tag2_id = 0
    }

    return resolved;
    }
};

class RelativePoseOfTwoTagsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RelativePoseOfTwoTagsResponse
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RelativePoseOfTwoTagsResponse
    let len;
    let data = new RelativePoseOfTwoTagsResponse(null);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_message.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'caliber_msgs/RelativePoseOfTwoTagsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a13979422fc129b30b15994450a302b5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_message
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RelativePoseOfTwoTagsResponse(null);
    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: RelativePoseOfTwoTagsRequest,
  Response: RelativePoseOfTwoTagsResponse,
  md5sum() { return '045e7bb8a50e9b4d25a90fe196a89dd8'; },
  datatype() { return 'caliber_msgs/RelativePoseOfTwoTags'; }
};
