// Auto-generated. Do not edit!

// (in-package emma_safe_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PersonState = require('./PersonState.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class PersonStateArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.people_state = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('people_state')) {
        this.people_state = initObj.people_state
      }
      else {
        this.people_state = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PersonStateArray
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [people_state]
    // Serialize the length for message field [people_state]
    bufferOffset = _serializer.uint32(obj.people_state.length, buffer, bufferOffset);
    obj.people_state.forEach((val) => {
      bufferOffset = PersonState.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PersonStateArray
    let len;
    let data = new PersonStateArray(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [people_state]
    // Deserialize array length for message field [people_state]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.people_state = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.people_state[i] = PersonState.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.people_state.forEach((val) => {
      length += PersonState.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'emma_safe_msgs/PersonStateArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3b8def0500f11fd2c90f23ac9cacb716';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Array of person positions
    std_msgs/Header header
    PersonState[] people_state
    
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: emma_safe_msgs/PersonState
    # state of a person
    uint32 id
    float32 x
    float32 y
    float32 vx
    float32 vy
    float32 height
    float32 width
    float32[] covariances
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PersonStateArray(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.people_state !== undefined) {
      resolved.people_state = new Array(msg.people_state.length);
      for (let i = 0; i < resolved.people_state.length; ++i) {
        resolved.people_state[i] = PersonState.Resolve(msg.people_state[i]);
      }
    }
    else {
      resolved.people_state = []
    }

    return resolved;
    }
};

module.exports = PersonStateArray;
