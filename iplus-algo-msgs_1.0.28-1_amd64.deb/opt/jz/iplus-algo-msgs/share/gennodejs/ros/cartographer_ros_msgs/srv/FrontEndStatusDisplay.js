// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let StatusDisplay = require('../msg/StatusDisplay.js');

//-----------------------------------------------------------

class FrontEndStatusDisplayRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndStatusDisplayRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndStatusDisplayRequest
    let len;
    let data = new FrontEndStatusDisplayRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/FrontEndStatusDisplayRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndStatusDisplayRequest(null);
    return resolved;
    }
};

class FrontEndStatusDisplayResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.status = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = new StatusDisplay();
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndStatusDisplayResponse
    // Serialize message field [status]
    bufferOffset = StatusDisplay.serialize(obj.status, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndStatusDisplayResponse
    let len;
    let data = new FrontEndStatusDisplayResponse(null);
    // Deserialize message field [status]
    data.status = StatusDisplay.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += StatusDisplay.getMessageSize(object.status);
    length += object.error_message.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/FrontEndStatusDisplayResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b708fc3650ad32c16c84f52f6432e1b0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    cartographer_ros_msgs/StatusDisplay status
    string error_message
    
    
    ================================================================================
    MSG: cartographer_ros_msgs/StatusDisplay
    uint8 server_status
    uint8 MAPPING=0
    uint8 LOCALIZING=1
    uint8 IDLE=2
    uint8 PATCH_MAPPING=3
    
    std_msgs/Header header
    string work_map
    int32 work_item_size
    geometry_msgs/Pose2D worldLoc
    
    # imageLoc should not be used while service is in MAPPING mode.
    geometry_msgs/Pose2D imageLoc
    
    float32[] XLaserInWorld
    float32[] YLaserInWorld
    
    int32 failure_count
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndStatusDisplayResponse(null);
    if (msg.status !== undefined) {
      resolved.status = StatusDisplay.Resolve(msg.status)
    }
    else {
      resolved.status = new StatusDisplay()
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: FrontEndStatusDisplayRequest,
  Response: FrontEndStatusDisplayResponse,
  md5sum() { return 'b708fc3650ad32c16c84f52f6432e1b0'; },
  datatype() { return 'cartographer_ros_msgs/FrontEndStatusDisplay'; }
};
