// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class perception_data {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.velocity = null;
      this.velocity_array = null;
      this.wMe = null;
      this.oMe = null;
      this.wMo = null;
      this.pose_names = null;
      this.poses = null;
      this.filt_flash_flag = null;
      this.use_center_tag = null;
      this.detect_tags = null;
      this.detect_corners = null;
      this.flag_name = null;
      this.flag_values = null;
      this.int_reserved = null;
      this.int_reserved2 = null;
      this.int_reserved3 = null;
      this.int_reserved4 = null;
      this.int_reserved5 = null;
      this.int_reserved6 = null;
      this.double_reserved = null;
      this.double_reserved2 = null;
      this.double_reserved3 = null;
      this.double_reserved4 = null;
      this.double_reserved5 = null;
      this.double_reserved6 = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = new geometry_msgs.msg.Twist();
      }
      if (initObj.hasOwnProperty('velocity_array')) {
        this.velocity_array = initObj.velocity_array
      }
      else {
        this.velocity_array = new std_msgs.msg.Float64MultiArray();
      }
      if (initObj.hasOwnProperty('wMe')) {
        this.wMe = initObj.wMe
      }
      else {
        this.wMe = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('oMe')) {
        this.oMe = initObj.oMe
      }
      else {
        this.oMe = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('wMo')) {
        this.wMo = initObj.wMo
      }
      else {
        this.wMo = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('pose_names')) {
        this.pose_names = initObj.pose_names
      }
      else {
        this.pose_names = [];
      }
      if (initObj.hasOwnProperty('poses')) {
        this.poses = initObj.poses
      }
      else {
        this.poses = [];
      }
      if (initObj.hasOwnProperty('filt_flash_flag')) {
        this.filt_flash_flag = initObj.filt_flash_flag
      }
      else {
        this.filt_flash_flag = 0;
      }
      if (initObj.hasOwnProperty('use_center_tag')) {
        this.use_center_tag = initObj.use_center_tag
      }
      else {
        this.use_center_tag = 0;
      }
      if (initObj.hasOwnProperty('detect_tags')) {
        this.detect_tags = initObj.detect_tags
      }
      else {
        this.detect_tags = 0.0;
      }
      if (initObj.hasOwnProperty('detect_corners')) {
        this.detect_corners = initObj.detect_corners
      }
      else {
        this.detect_corners = 0.0;
      }
      if (initObj.hasOwnProperty('flag_name')) {
        this.flag_name = initObj.flag_name
      }
      else {
        this.flag_name = [];
      }
      if (initObj.hasOwnProperty('flag_values')) {
        this.flag_values = initObj.flag_values
      }
      else {
        this.flag_values = 0;
      }
      if (initObj.hasOwnProperty('int_reserved')) {
        this.int_reserved = initObj.int_reserved
      }
      else {
        this.int_reserved = [];
      }
      if (initObj.hasOwnProperty('int_reserved2')) {
        this.int_reserved2 = initObj.int_reserved2
      }
      else {
        this.int_reserved2 = [];
      }
      if (initObj.hasOwnProperty('int_reserved3')) {
        this.int_reserved3 = initObj.int_reserved3
      }
      else {
        this.int_reserved3 = [];
      }
      if (initObj.hasOwnProperty('int_reserved4')) {
        this.int_reserved4 = initObj.int_reserved4
      }
      else {
        this.int_reserved4 = [];
      }
      if (initObj.hasOwnProperty('int_reserved5')) {
        this.int_reserved5 = initObj.int_reserved5
      }
      else {
        this.int_reserved5 = [];
      }
      if (initObj.hasOwnProperty('int_reserved6')) {
        this.int_reserved6 = initObj.int_reserved6
      }
      else {
        this.int_reserved6 = [];
      }
      if (initObj.hasOwnProperty('double_reserved')) {
        this.double_reserved = initObj.double_reserved
      }
      else {
        this.double_reserved = [];
      }
      if (initObj.hasOwnProperty('double_reserved2')) {
        this.double_reserved2 = initObj.double_reserved2
      }
      else {
        this.double_reserved2 = [];
      }
      if (initObj.hasOwnProperty('double_reserved3')) {
        this.double_reserved3 = initObj.double_reserved3
      }
      else {
        this.double_reserved3 = [];
      }
      if (initObj.hasOwnProperty('double_reserved4')) {
        this.double_reserved4 = initObj.double_reserved4
      }
      else {
        this.double_reserved4 = [];
      }
      if (initObj.hasOwnProperty('double_reserved5')) {
        this.double_reserved5 = initObj.double_reserved5
      }
      else {
        this.double_reserved5 = [];
      }
      if (initObj.hasOwnProperty('double_reserved6')) {
        this.double_reserved6 = initObj.double_reserved6
      }
      else {
        this.double_reserved6 = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type perception_data
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [velocity]
    bufferOffset = geometry_msgs.msg.Twist.serialize(obj.velocity, buffer, bufferOffset);
    // Serialize message field [velocity_array]
    bufferOffset = std_msgs.msg.Float64MultiArray.serialize(obj.velocity_array, buffer, bufferOffset);
    // Serialize message field [wMe]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.wMe, buffer, bufferOffset);
    // Serialize message field [oMe]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.oMe, buffer, bufferOffset);
    // Serialize message field [wMo]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.wMo, buffer, bufferOffset);
    // Serialize message field [pose_names]
    bufferOffset = _arraySerializer.string(obj.pose_names, buffer, bufferOffset, null);
    // Serialize message field [poses]
    // Serialize the length for message field [poses]
    bufferOffset = _serializer.uint32(obj.poses.length, buffer, bufferOffset);
    obj.poses.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [filt_flash_flag]
    bufferOffset = _serializer.int32(obj.filt_flash_flag, buffer, bufferOffset);
    // Serialize message field [use_center_tag]
    bufferOffset = _serializer.int32(obj.use_center_tag, buffer, bufferOffset);
    // Serialize message field [detect_tags]
    bufferOffset = _serializer.float64(obj.detect_tags, buffer, bufferOffset);
    // Serialize message field [detect_corners]
    bufferOffset = _serializer.float64(obj.detect_corners, buffer, bufferOffset);
    // Serialize message field [flag_name]
    bufferOffset = _arraySerializer.string(obj.flag_name, buffer, bufferOffset, null);
    // Serialize message field [flag_values]
    bufferOffset = _serializer.uint32(obj.flag_values, buffer, bufferOffset);
    // Serialize message field [int_reserved]
    bufferOffset = _arraySerializer.int32(obj.int_reserved, buffer, bufferOffset, null);
    // Serialize message field [int_reserved2]
    bufferOffset = _arraySerializer.int32(obj.int_reserved2, buffer, bufferOffset, null);
    // Serialize message field [int_reserved3]
    bufferOffset = _arraySerializer.int32(obj.int_reserved3, buffer, bufferOffset, null);
    // Serialize message field [int_reserved4]
    bufferOffset = _arraySerializer.int32(obj.int_reserved4, buffer, bufferOffset, null);
    // Serialize message field [int_reserved5]
    bufferOffset = _arraySerializer.int32(obj.int_reserved5, buffer, bufferOffset, null);
    // Serialize message field [int_reserved6]
    bufferOffset = _arraySerializer.int32(obj.int_reserved6, buffer, bufferOffset, null);
    // Serialize message field [double_reserved]
    bufferOffset = _arraySerializer.float64(obj.double_reserved, buffer, bufferOffset, null);
    // Serialize message field [double_reserved2]
    bufferOffset = _arraySerializer.float64(obj.double_reserved2, buffer, bufferOffset, null);
    // Serialize message field [double_reserved3]
    bufferOffset = _arraySerializer.float64(obj.double_reserved3, buffer, bufferOffset, null);
    // Serialize message field [double_reserved4]
    bufferOffset = _arraySerializer.float64(obj.double_reserved4, buffer, bufferOffset, null);
    // Serialize message field [double_reserved5]
    bufferOffset = _arraySerializer.float64(obj.double_reserved5, buffer, bufferOffset, null);
    // Serialize message field [double_reserved6]
    bufferOffset = _arraySerializer.float64(obj.double_reserved6, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type perception_data
    let len;
    let data = new perception_data(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [velocity]
    data.velocity = geometry_msgs.msg.Twist.deserialize(buffer, bufferOffset);
    // Deserialize message field [velocity_array]
    data.velocity_array = std_msgs.msg.Float64MultiArray.deserialize(buffer, bufferOffset);
    // Deserialize message field [wMe]
    data.wMe = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [oMe]
    data.oMe = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [wMo]
    data.wMo = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose_names]
    data.pose_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [poses]
    // Deserialize array length for message field [poses]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.poses = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.poses[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [filt_flash_flag]
    data.filt_flash_flag = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [use_center_tag]
    data.use_center_tag = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [detect_tags]
    data.detect_tags = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [detect_corners]
    data.detect_corners = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [flag_name]
    data.flag_name = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [flag_values]
    data.flag_values = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [int_reserved]
    data.int_reserved = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [int_reserved2]
    data.int_reserved2 = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [int_reserved3]
    data.int_reserved3 = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [int_reserved4]
    data.int_reserved4 = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [int_reserved5]
    data.int_reserved5 = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [int_reserved6]
    data.int_reserved6 = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [double_reserved]
    data.double_reserved = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [double_reserved2]
    data.double_reserved2 = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [double_reserved3]
    data.double_reserved3 = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [double_reserved4]
    data.double_reserved4 = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [double_reserved5]
    data.double_reserved5 = _arrayDeserializer.float64(buffer, bufferOffset, null)
    // Deserialize message field [double_reserved6]
    data.double_reserved6 = _arrayDeserializer.float64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += std_msgs.msg.Float64MultiArray.getMessageSize(object.velocity_array);
    object.pose_names.forEach((val) => {
      length += 4 + val.length;
    });
    length += 56 * object.poses.length;
    object.flag_name.forEach((val) => {
      length += 4 + val.length;
    });
    length += 4 * object.int_reserved.length;
    length += 4 * object.int_reserved2.length;
    length += 4 * object.int_reserved3.length;
    length += 4 * object.int_reserved4.length;
    length += 4 * object.int_reserved5.length;
    length += 4 * object.int_reserved6.length;
    length += 8 * object.double_reserved.length;
    length += 8 * object.double_reserved2.length;
    length += 8 * object.double_reserved3.length;
    length += 8 * object.double_reserved4.length;
    length += 8 * object.double_reserved5.length;
    length += 8 * object.double_reserved6.length;
    return length + 304;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_servo_msgs/perception_data';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd458e74bbec15cef00170ce16d2ea2d6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    geometry_msgs/Twist velocity
    std_msgs/Float64MultiArray velocity_array
    geometry_msgs/Pose wMe
    geometry_msgs/Pose oMe
    geometry_msgs/Pose wMo
    string[] pose_names
    geometry_msgs/Pose[] poses
    int32 filt_flash_flag
    int32 use_center_tag
    float64 detect_tags
    float64 detect_corners
    string[] flag_name
    uint32 flag_values
    int32[] int_reserved
    int32[] int_reserved2
    int32[] int_reserved3
    int32[] int_reserved4
    int32[] int_reserved5
    int32[] int_reserved6
    float64[] double_reserved
    float64[] double_reserved2
    float64[] double_reserved3
    float64[] double_reserved4
    float64[] double_reserved5
    float64[] double_reserved6
    
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Twist
    # This expresses velocity in free space broken into its linear and angular parts.
    Vector3  linear
    Vector3  angular
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    ================================================================================
    MSG: std_msgs/Float64MultiArray
    # Please look at the MultiArrayLayout message definition for
    # documentation on all multiarrays.
    
    MultiArrayLayout  layout        # specification of data layout
    float64[]         data          # array of data
    
    
    ================================================================================
    MSG: std_msgs/MultiArrayLayout
    # The multiarray declares a generic multi-dimensional array of a
    # particular data type.  Dimensions are ordered from outer most
    # to inner most.
    
    MultiArrayDimension[] dim # Array of dimension properties
    uint32 data_offset        # padding elements at front of data
    
    # Accessors should ALWAYS be written in terms of dimension stride
    # and specified outer-most dimension first.
    # 
    # multiarray(i,j,k) = data[data_offset + dim_stride[1]*i + dim_stride[2]*j + k]
    #
    # A standard, 3-channel 640x480 image with interleaved color channels
    # would be specified as:
    #
    # dim[0].label  = "height"
    # dim[0].size   = 480
    # dim[0].stride = 3*640*480 = 921600  (note dim[0] stride is just size of image)
    # dim[1].label  = "width"
    # dim[1].size   = 640
    # dim[1].stride = 3*640 = 1920
    # dim[2].label  = "channel"
    # dim[2].size   = 3
    # dim[2].stride = 3
    #
    # multiarray(i,j,k) refers to the ith row, jth column, and kth channel.
    
    ================================================================================
    MSG: std_msgs/MultiArrayDimension
    string label   # label of given dimension
    uint32 size    # size of given dimension (in type units)
    uint32 stride  # stride of given dimension
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new perception_data(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = geometry_msgs.msg.Twist.Resolve(msg.velocity)
    }
    else {
      resolved.velocity = new geometry_msgs.msg.Twist()
    }

    if (msg.velocity_array !== undefined) {
      resolved.velocity_array = std_msgs.msg.Float64MultiArray.Resolve(msg.velocity_array)
    }
    else {
      resolved.velocity_array = new std_msgs.msg.Float64MultiArray()
    }

    if (msg.wMe !== undefined) {
      resolved.wMe = geometry_msgs.msg.Pose.Resolve(msg.wMe)
    }
    else {
      resolved.wMe = new geometry_msgs.msg.Pose()
    }

    if (msg.oMe !== undefined) {
      resolved.oMe = geometry_msgs.msg.Pose.Resolve(msg.oMe)
    }
    else {
      resolved.oMe = new geometry_msgs.msg.Pose()
    }

    if (msg.wMo !== undefined) {
      resolved.wMo = geometry_msgs.msg.Pose.Resolve(msg.wMo)
    }
    else {
      resolved.wMo = new geometry_msgs.msg.Pose()
    }

    if (msg.pose_names !== undefined) {
      resolved.pose_names = msg.pose_names;
    }
    else {
      resolved.pose_names = []
    }

    if (msg.poses !== undefined) {
      resolved.poses = new Array(msg.poses.length);
      for (let i = 0; i < resolved.poses.length; ++i) {
        resolved.poses[i] = geometry_msgs.msg.Pose.Resolve(msg.poses[i]);
      }
    }
    else {
      resolved.poses = []
    }

    if (msg.filt_flash_flag !== undefined) {
      resolved.filt_flash_flag = msg.filt_flash_flag;
    }
    else {
      resolved.filt_flash_flag = 0
    }

    if (msg.use_center_tag !== undefined) {
      resolved.use_center_tag = msg.use_center_tag;
    }
    else {
      resolved.use_center_tag = 0
    }

    if (msg.detect_tags !== undefined) {
      resolved.detect_tags = msg.detect_tags;
    }
    else {
      resolved.detect_tags = 0.0
    }

    if (msg.detect_corners !== undefined) {
      resolved.detect_corners = msg.detect_corners;
    }
    else {
      resolved.detect_corners = 0.0
    }

    if (msg.flag_name !== undefined) {
      resolved.flag_name = msg.flag_name;
    }
    else {
      resolved.flag_name = []
    }

    if (msg.flag_values !== undefined) {
      resolved.flag_values = msg.flag_values;
    }
    else {
      resolved.flag_values = 0
    }

    if (msg.int_reserved !== undefined) {
      resolved.int_reserved = msg.int_reserved;
    }
    else {
      resolved.int_reserved = []
    }

    if (msg.int_reserved2 !== undefined) {
      resolved.int_reserved2 = msg.int_reserved2;
    }
    else {
      resolved.int_reserved2 = []
    }

    if (msg.int_reserved3 !== undefined) {
      resolved.int_reserved3 = msg.int_reserved3;
    }
    else {
      resolved.int_reserved3 = []
    }

    if (msg.int_reserved4 !== undefined) {
      resolved.int_reserved4 = msg.int_reserved4;
    }
    else {
      resolved.int_reserved4 = []
    }

    if (msg.int_reserved5 !== undefined) {
      resolved.int_reserved5 = msg.int_reserved5;
    }
    else {
      resolved.int_reserved5 = []
    }

    if (msg.int_reserved6 !== undefined) {
      resolved.int_reserved6 = msg.int_reserved6;
    }
    else {
      resolved.int_reserved6 = []
    }

    if (msg.double_reserved !== undefined) {
      resolved.double_reserved = msg.double_reserved;
    }
    else {
      resolved.double_reserved = []
    }

    if (msg.double_reserved2 !== undefined) {
      resolved.double_reserved2 = msg.double_reserved2;
    }
    else {
      resolved.double_reserved2 = []
    }

    if (msg.double_reserved3 !== undefined) {
      resolved.double_reserved3 = msg.double_reserved3;
    }
    else {
      resolved.double_reserved3 = []
    }

    if (msg.double_reserved4 !== undefined) {
      resolved.double_reserved4 = msg.double_reserved4;
    }
    else {
      resolved.double_reserved4 = []
    }

    if (msg.double_reserved5 !== undefined) {
      resolved.double_reserved5 = msg.double_reserved5;
    }
    else {
      resolved.double_reserved5 = []
    }

    if (msg.double_reserved6 !== undefined) {
      resolved.double_reserved6 = msg.double_reserved6;
    }
    else {
      resolved.double_reserved6 = []
    }

    return resolved;
    }
};

module.exports = perception_data;
