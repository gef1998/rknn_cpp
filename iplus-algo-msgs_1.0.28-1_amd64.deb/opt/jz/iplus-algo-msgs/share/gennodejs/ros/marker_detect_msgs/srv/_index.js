
"use strict";

let MarkerDetectServer = require('./MarkerDetectServer.js')

module.exports = {
  MarkerDetectServer: MarkerDetectServer,
};
