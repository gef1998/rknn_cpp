// Auto-generated. Do not edit!

// (in-package poslvx.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Status = require('./Status.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class INSRMS {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.status = null;
      this.north_position_rms = null;
      this.east_position_rms = null;
      this.down_position_rms = null;
      this.north_velocity_rms = null;
      this.east_velocity_rms = null;
      this.down_velocity_rms = null;
      this.roll_rms = null;
      this.pitch_rms = null;
      this.heading_rms = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = new Status();
      }
      if (initObj.hasOwnProperty('north_position_rms')) {
        this.north_position_rms = initObj.north_position_rms
      }
      else {
        this.north_position_rms = 0.0;
      }
      if (initObj.hasOwnProperty('east_position_rms')) {
        this.east_position_rms = initObj.east_position_rms
      }
      else {
        this.east_position_rms = 0.0;
      }
      if (initObj.hasOwnProperty('down_position_rms')) {
        this.down_position_rms = initObj.down_position_rms
      }
      else {
        this.down_position_rms = 0.0;
      }
      if (initObj.hasOwnProperty('north_velocity_rms')) {
        this.north_velocity_rms = initObj.north_velocity_rms
      }
      else {
        this.north_velocity_rms = 0.0;
      }
      if (initObj.hasOwnProperty('east_velocity_rms')) {
        this.east_velocity_rms = initObj.east_velocity_rms
      }
      else {
        this.east_velocity_rms = 0.0;
      }
      if (initObj.hasOwnProperty('down_velocity_rms')) {
        this.down_velocity_rms = initObj.down_velocity_rms
      }
      else {
        this.down_velocity_rms = 0.0;
      }
      if (initObj.hasOwnProperty('roll_rms')) {
        this.roll_rms = initObj.roll_rms
      }
      else {
        this.roll_rms = 0.0;
      }
      if (initObj.hasOwnProperty('pitch_rms')) {
        this.pitch_rms = initObj.pitch_rms
      }
      else {
        this.pitch_rms = 0.0;
      }
      if (initObj.hasOwnProperty('heading_rms')) {
        this.heading_rms = initObj.heading_rms
      }
      else {
        this.heading_rms = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type INSRMS
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = Status.serialize(obj.status, buffer, bufferOffset);
    // Serialize message field [north_position_rms]
    bufferOffset = _serializer.float32(obj.north_position_rms, buffer, bufferOffset);
    // Serialize message field [east_position_rms]
    bufferOffset = _serializer.float32(obj.east_position_rms, buffer, bufferOffset);
    // Serialize message field [down_position_rms]
    bufferOffset = _serializer.float32(obj.down_position_rms, buffer, bufferOffset);
    // Serialize message field [north_velocity_rms]
    bufferOffset = _serializer.float32(obj.north_velocity_rms, buffer, bufferOffset);
    // Serialize message field [east_velocity_rms]
    bufferOffset = _serializer.float32(obj.east_velocity_rms, buffer, bufferOffset);
    // Serialize message field [down_velocity_rms]
    bufferOffset = _serializer.float32(obj.down_velocity_rms, buffer, bufferOffset);
    // Serialize message field [roll_rms]
    bufferOffset = _serializer.float32(obj.roll_rms, buffer, bufferOffset);
    // Serialize message field [pitch_rms]
    bufferOffset = _serializer.float32(obj.pitch_rms, buffer, bufferOffset);
    // Serialize message field [heading_rms]
    bufferOffset = _serializer.float32(obj.heading_rms, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type INSRMS
    let len;
    let data = new INSRMS(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = Status.deserialize(buffer, bufferOffset);
    // Deserialize message field [north_position_rms]
    data.north_position_rms = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [east_position_rms]
    data.east_position_rms = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [down_position_rms]
    data.down_position_rms = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [north_velocity_rms]
    data.north_velocity_rms = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [east_velocity_rms]
    data.east_velocity_rms = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [down_velocity_rms]
    data.down_velocity_rms = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [roll_rms]
    data.roll_rms = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [pitch_rms]
    data.pitch_rms = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [heading_rms]
    data.heading_rms = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 44;
  }

  static datatype() {
    // Returns string type for a message object
    return 'poslvx/INSRMS';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '57fdcd6e42435abf578464d0ba478967';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    Status status
    
    float32 north_position_rms
    float32 east_position_rms
    float32 down_position_rms
    float32 north_velocity_rms
    float32 east_velocity_rms
    float32 down_velocity_rms
    float32 roll_rms
    float32 pitch_rms
    float32 heading_rms
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: poslvx/Status
    
    int16 gps_week
    uint32 gps_time
    uint8 imu_alignment_status
    uint8 gnss_status
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new INSRMS(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.status !== undefined) {
      resolved.status = Status.Resolve(msg.status)
    }
    else {
      resolved.status = new Status()
    }

    if (msg.north_position_rms !== undefined) {
      resolved.north_position_rms = msg.north_position_rms;
    }
    else {
      resolved.north_position_rms = 0.0
    }

    if (msg.east_position_rms !== undefined) {
      resolved.east_position_rms = msg.east_position_rms;
    }
    else {
      resolved.east_position_rms = 0.0
    }

    if (msg.down_position_rms !== undefined) {
      resolved.down_position_rms = msg.down_position_rms;
    }
    else {
      resolved.down_position_rms = 0.0
    }

    if (msg.north_velocity_rms !== undefined) {
      resolved.north_velocity_rms = msg.north_velocity_rms;
    }
    else {
      resolved.north_velocity_rms = 0.0
    }

    if (msg.east_velocity_rms !== undefined) {
      resolved.east_velocity_rms = msg.east_velocity_rms;
    }
    else {
      resolved.east_velocity_rms = 0.0
    }

    if (msg.down_velocity_rms !== undefined) {
      resolved.down_velocity_rms = msg.down_velocity_rms;
    }
    else {
      resolved.down_velocity_rms = 0.0
    }

    if (msg.roll_rms !== undefined) {
      resolved.roll_rms = msg.roll_rms;
    }
    else {
      resolved.roll_rms = 0.0
    }

    if (msg.pitch_rms !== undefined) {
      resolved.pitch_rms = msg.pitch_rms;
    }
    else {
      resolved.pitch_rms = 0.0
    }

    if (msg.heading_rms !== undefined) {
      resolved.heading_rms = msg.heading_rms;
    }
    else {
      resolved.heading_rms = 0.0
    }

    return resolved;
    }
};

module.exports = INSRMS;
