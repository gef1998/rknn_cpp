
"use strict";

let GetWorkMap = require('./GetWorkMap.js')
let GetFile = require('./GetFile.js')
let SetWorkMap = require('./SetWorkMap.js')
let SaveFile = require('./SaveFile.js')
let GetMapList = require('./GetMapList.js')

module.exports = {
  GetWorkMap: GetWorkMap,
  GetFile: GetFile,
  SetWorkMap: SetWorkMap,
  SaveFile: SaveFile,
  GetMapList: GetMapList,
};
