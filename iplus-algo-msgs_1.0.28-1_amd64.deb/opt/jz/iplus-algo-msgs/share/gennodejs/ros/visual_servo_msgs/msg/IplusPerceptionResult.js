// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class IplusPerceptionResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.perception_type = null;
      this.valid = null;
      this.stamp = null;
      this.perception_actual_rate = null;
      this.detect_tags = null;
      this.tag_id = null;
      this.reproject_error = null;
      this.wMe = null;
      this.wMc = null;
      this.tag_ids_for_solvePnP = null;
      this.wMe_map_keys = null;
      this.wMe_map_values = null;
      this.wMc_map_keys = null;
      this.wMc_map_values = null;
      this.json_string = null;
      this.scan_map_keys = null;
      this.scan_map_values = null;
      this.pointcloud2_map_keys = null;
      this.pointcloud2_map_values = null;
      this.polygon_map_keys = null;
      this.polygon_map_values = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('perception_type')) {
        this.perception_type = initObj.perception_type
      }
      else {
        this.perception_type = 0;
      }
      if (initObj.hasOwnProperty('valid')) {
        this.valid = initObj.valid
      }
      else {
        this.valid = false;
      }
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('perception_actual_rate')) {
        this.perception_actual_rate = initObj.perception_actual_rate
      }
      else {
        this.perception_actual_rate = 0.0;
      }
      if (initObj.hasOwnProperty('detect_tags')) {
        this.detect_tags = initObj.detect_tags
      }
      else {
        this.detect_tags = 0.0;
      }
      if (initObj.hasOwnProperty('tag_id')) {
        this.tag_id = initObj.tag_id
      }
      else {
        this.tag_id = 0;
      }
      if (initObj.hasOwnProperty('reproject_error')) {
        this.reproject_error = initObj.reproject_error
      }
      else {
        this.reproject_error = 0.0;
      }
      if (initObj.hasOwnProperty('wMe')) {
        this.wMe = initObj.wMe
      }
      else {
        this.wMe = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('wMc')) {
        this.wMc = initObj.wMc
      }
      else {
        this.wMc = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('tag_ids_for_solvePnP')) {
        this.tag_ids_for_solvePnP = initObj.tag_ids_for_solvePnP
      }
      else {
        this.tag_ids_for_solvePnP = [];
      }
      if (initObj.hasOwnProperty('wMe_map_keys')) {
        this.wMe_map_keys = initObj.wMe_map_keys
      }
      else {
        this.wMe_map_keys = [];
      }
      if (initObj.hasOwnProperty('wMe_map_values')) {
        this.wMe_map_values = initObj.wMe_map_values
      }
      else {
        this.wMe_map_values = [];
      }
      if (initObj.hasOwnProperty('wMc_map_keys')) {
        this.wMc_map_keys = initObj.wMc_map_keys
      }
      else {
        this.wMc_map_keys = [];
      }
      if (initObj.hasOwnProperty('wMc_map_values')) {
        this.wMc_map_values = initObj.wMc_map_values
      }
      else {
        this.wMc_map_values = [];
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
      if (initObj.hasOwnProperty('scan_map_keys')) {
        this.scan_map_keys = initObj.scan_map_keys
      }
      else {
        this.scan_map_keys = [];
      }
      if (initObj.hasOwnProperty('scan_map_values')) {
        this.scan_map_values = initObj.scan_map_values
      }
      else {
        this.scan_map_values = [];
      }
      if (initObj.hasOwnProperty('pointcloud2_map_keys')) {
        this.pointcloud2_map_keys = initObj.pointcloud2_map_keys
      }
      else {
        this.pointcloud2_map_keys = [];
      }
      if (initObj.hasOwnProperty('pointcloud2_map_values')) {
        this.pointcloud2_map_values = initObj.pointcloud2_map_values
      }
      else {
        this.pointcloud2_map_values = [];
      }
      if (initObj.hasOwnProperty('polygon_map_keys')) {
        this.polygon_map_keys = initObj.polygon_map_keys
      }
      else {
        this.polygon_map_keys = [];
      }
      if (initObj.hasOwnProperty('polygon_map_values')) {
        this.polygon_map_values = initObj.polygon_map_values
      }
      else {
        this.polygon_map_values = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type IplusPerceptionResult
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [perception_type]
    bufferOffset = _serializer.uint8(obj.perception_type, buffer, bufferOffset);
    // Serialize message field [valid]
    bufferOffset = _serializer.bool(obj.valid, buffer, bufferOffset);
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [perception_actual_rate]
    bufferOffset = _serializer.float32(obj.perception_actual_rate, buffer, bufferOffset);
    // Serialize message field [detect_tags]
    bufferOffset = _serializer.float32(obj.detect_tags, buffer, bufferOffset);
    // Serialize message field [tag_id]
    bufferOffset = _serializer.int32(obj.tag_id, buffer, bufferOffset);
    // Serialize message field [reproject_error]
    bufferOffset = _serializer.float64(obj.reproject_error, buffer, bufferOffset);
    // Serialize message field [wMe]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.wMe, buffer, bufferOffset);
    // Serialize message field [wMc]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.wMc, buffer, bufferOffset);
    // Serialize message field [tag_ids_for_solvePnP]
    bufferOffset = _arraySerializer.int32(obj.tag_ids_for_solvePnP, buffer, bufferOffset, null);
    // Serialize message field [wMe_map_keys]
    bufferOffset = _arraySerializer.string(obj.wMe_map_keys, buffer, bufferOffset, null);
    // Serialize message field [wMe_map_values]
    // Serialize the length for message field [wMe_map_values]
    bufferOffset = _serializer.uint32(obj.wMe_map_values.length, buffer, bufferOffset);
    obj.wMe_map_values.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [wMc_map_keys]
    bufferOffset = _arraySerializer.string(obj.wMc_map_keys, buffer, bufferOffset, null);
    // Serialize message field [wMc_map_values]
    // Serialize the length for message field [wMc_map_values]
    bufferOffset = _serializer.uint32(obj.wMc_map_values.length, buffer, bufferOffset);
    obj.wMc_map_values.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    // Serialize message field [scan_map_keys]
    bufferOffset = _arraySerializer.string(obj.scan_map_keys, buffer, bufferOffset, null);
    // Serialize message field [scan_map_values]
    // Serialize the length for message field [scan_map_values]
    bufferOffset = _serializer.uint32(obj.scan_map_values.length, buffer, bufferOffset);
    obj.scan_map_values.forEach((val) => {
      bufferOffset = sensor_msgs.msg.LaserScan.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [pointcloud2_map_keys]
    bufferOffset = _arraySerializer.string(obj.pointcloud2_map_keys, buffer, bufferOffset, null);
    // Serialize message field [pointcloud2_map_values]
    // Serialize the length for message field [pointcloud2_map_values]
    bufferOffset = _serializer.uint32(obj.pointcloud2_map_values.length, buffer, bufferOffset);
    obj.pointcloud2_map_values.forEach((val) => {
      bufferOffset = sensor_msgs.msg.PointCloud2.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [polygon_map_keys]
    bufferOffset = _arraySerializer.string(obj.polygon_map_keys, buffer, bufferOffset, null);
    // Serialize message field [polygon_map_values]
    // Serialize the length for message field [polygon_map_values]
    bufferOffset = _serializer.uint32(obj.polygon_map_values.length, buffer, bufferOffset);
    obj.polygon_map_values.forEach((val) => {
      bufferOffset = geometry_msgs.msg.PolygonStamped.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type IplusPerceptionResult
    let len;
    let data = new IplusPerceptionResult(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [perception_type]
    data.perception_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [valid]
    data.valid = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [perception_actual_rate]
    data.perception_actual_rate = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [detect_tags]
    data.detect_tags = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [tag_id]
    data.tag_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [reproject_error]
    data.reproject_error = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [wMe]
    data.wMe = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [wMc]
    data.wMc = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [tag_ids_for_solvePnP]
    data.tag_ids_for_solvePnP = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [wMe_map_keys]
    data.wMe_map_keys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [wMe_map_values]
    // Deserialize array length for message field [wMe_map_values]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.wMe_map_values = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.wMe_map_values[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [wMc_map_keys]
    data.wMc_map_keys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [wMc_map_values]
    // Deserialize array length for message field [wMc_map_values]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.wMc_map_values = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.wMc_map_values[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [scan_map_keys]
    data.scan_map_keys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [scan_map_values]
    // Deserialize array length for message field [scan_map_values]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.scan_map_values = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.scan_map_values[i] = sensor_msgs.msg.LaserScan.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [pointcloud2_map_keys]
    data.pointcloud2_map_keys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [pointcloud2_map_values]
    // Deserialize array length for message field [pointcloud2_map_values]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.pointcloud2_map_values = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.pointcloud2_map_values[i] = sensor_msgs.msg.PointCloud2.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [polygon_map_keys]
    data.polygon_map_keys = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [polygon_map_values]
    // Deserialize array length for message field [polygon_map_values]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.polygon_map_values = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.polygon_map_values[i] = geometry_msgs.msg.PolygonStamped.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += 4 * object.tag_ids_for_solvePnP.length;
    object.wMe_map_keys.forEach((val) => {
      length += 4 + val.length;
    });
    length += 56 * object.wMe_map_values.length;
    object.wMc_map_keys.forEach((val) => {
      length += 4 + val.length;
    });
    length += 56 * object.wMc_map_values.length;
    length += object.json_string.length;
    object.scan_map_keys.forEach((val) => {
      length += 4 + val.length;
    });
    object.scan_map_values.forEach((val) => {
      length += sensor_msgs.msg.LaserScan.getMessageSize(val);
    });
    object.pointcloud2_map_keys.forEach((val) => {
      length += 4 + val.length;
    });
    object.pointcloud2_map_values.forEach((val) => {
      length += sensor_msgs.msg.PointCloud2.getMessageSize(val);
    });
    object.polygon_map_keys.forEach((val) => {
      length += 4 + val.length;
    });
    object.polygon_map_values.forEach((val) => {
      length += geometry_msgs.msg.PolygonStamped.getMessageSize(val);
    });
    return length + 190;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_servo_msgs/IplusPerceptionResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '197360e5f17ca06f1e12a6f3fd885b1e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    uint8 NO_DEFINED_PERCEPTION=0
    uint8 CAMERA_PERCEPTION=1
    uint8 PALLET_PERCEPTION=2
    uint8 ODOM_PERCEPTION=3
    uint8 FUSION_PERCEPTION=4
    uint8 GROUNDTAG_PERCEPTION=5
    uint8 ICP3D_PERCEPTION=6
    uint8 LASER_PERCEPTION=7
    uint8 LASER2IMAGE_PERCEPTION=8
    uint8 LASER3D_LINE_PERCEPTION=9
    uint8 LASER3D_PERCEPTION=10
    uint8 LASERMARK_PERCEPTION=11
    uint8 ALERT_PERCEPTION=12
    uint8 REACVITISION_PERCEPTION=13
    uint8 REFLECTIVE_PLATE_PERCEPTION=14
    uint8 SHELF_PERCEPTION=15
    uint8 TF_ODOM_PERCEPTION=16
    uint8 TF_MAP_PERCEPTION=17
    uint8 TF_PERCEPTION=18
    uint8 VMODEL_PERCEPTION=19
    uint8 ZBAR_PERCEPTION=20
    uint8 PSD_PERCEPTION=21
    uint8 FM_PERCEPTION=22
    uint8 LINE_LASER_PERCEPTION=23
    uint8 DUAL_CAMERA_PERCEPTION=24
    uint8 DOT_MARKER_PERCEPTION=25
    
    uint8 perception_type
    
    bool valid
    time stamp
    float32 perception_actual_rate
    float32 detect_tags
    int32 tag_id
    float64 reproject_error
    geometry_msgs/Pose wMe
    geometry_msgs/Pose wMc
    
    int32[] tag_ids_for_solvePnP
    
    string[] wMe_map_keys
    geometry_msgs/Pose[] wMe_map_values
    
    string[] wMc_map_keys
    geometry_msgs/Pose[] wMc_map_values
    
    string json_string
    
    string[] scan_map_keys
    sensor_msgs/LaserScan[] scan_map_values
    
    string[] pointcloud2_map_keys
    sensor_msgs/PointCloud2[] pointcloud2_map_values
    
    string[] polygon_map_keys
    geometry_msgs/PolygonStamped[] polygon_map_values
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensor_msgs/LaserScan
    # Single scan from a planar laser range-finder
    #
    # If you have another ranging device with different behavior (e.g. a sonar
    # array), please find or create a different message, since applications
    # will make fairly laser-specific assumptions about this data
    
    Header header            # timestamp in the header is the acquisition time of 
                             # the first ray in the scan.
                             #
                             # in frame frame_id, angles are measured around 
                             # the positive Z axis (counterclockwise, if Z is up)
                             # with zero angle being forward along the x axis
                             
    float32 angle_min        # start angle of the scan [rad]
    float32 angle_max        # end angle of the scan [rad]
    float32 angle_increment  # angular distance between measurements [rad]
    
    float32 time_increment   # time between measurements [seconds] - if your scanner
                             # is moving, this will be used in interpolating position
                             # of 3d points
    float32 scan_time        # time between scans [seconds]
    
    float32 range_min        # minimum range value [m]
    float32 range_max        # maximum range value [m]
    
    float32[] ranges         # range data [m] (Note: values < range_min or > range_max should be discarded)
    float32[] intensities    # intensity data [device-specific units].  If your
                             # device does not provide intensities, please leave
                             # the array empty.
    
    ================================================================================
    MSG: sensor_msgs/PointCloud2
    # This message holds a collection of N-dimensional points, which may
    # contain additional information such as normals, intensity, etc. The
    # point data is stored as a binary blob, its layout described by the
    # contents of the "fields" array.
    
    # The point cloud data may be organized 2d (image-like) or 1d
    # (unordered). Point clouds organized as 2d images may be produced by
    # camera depth sensors such as stereo or time-of-flight.
    
    # Time of sensor data acquisition, and the coordinate frame ID (for 3d
    # points).
    Header header
    
    # 2D structure of the point cloud. If the cloud is unordered, height is
    # 1 and width is the length of the point cloud.
    uint32 height
    uint32 width
    
    # Describes the channels and their layout in the binary data blob.
    PointField[] fields
    
    bool    is_bigendian # Is this data bigendian?
    uint32  point_step   # Length of a point in bytes
    uint32  row_step     # Length of a row in bytes
    uint8[] data         # Actual point data, size is (row_step*height)
    
    bool is_dense        # True if there are no invalid points
    
    ================================================================================
    MSG: sensor_msgs/PointField
    # This message holds the description of one point entry in the
    # PointCloud2 message format.
    uint8 INT8    = 1
    uint8 UINT8   = 2
    uint8 INT16   = 3
    uint8 UINT16  = 4
    uint8 INT32   = 5
    uint8 UINT32  = 6
    uint8 FLOAT32 = 7
    uint8 FLOAT64 = 8
    
    string name      # Name of field
    uint32 offset    # Offset from start of point struct
    uint8  datatype  # Datatype enumeration, see above
    uint32 count     # How many elements in the field
    
    ================================================================================
    MSG: geometry_msgs/PolygonStamped
    # This represents a Polygon with reference coordinate frame and timestamp
    Header header
    Polygon polygon
    
    ================================================================================
    MSG: geometry_msgs/Polygon
    #A specification of a polygon where the first and last points are assumed to be connected
    Point32[] points
    
    ================================================================================
    MSG: geometry_msgs/Point32
    # This contains the position of a point in free space(with 32 bits of precision).
    # It is recommeded to use Point wherever possible instead of Point32.  
    # 
    # This recommendation is to promote interoperability.  
    #
    # This message is designed to take up less space when sending
    # lots of points at once, as in the case of a PointCloud.  
    
    float32 x
    float32 y
    float32 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new IplusPerceptionResult(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.perception_type !== undefined) {
      resolved.perception_type = msg.perception_type;
    }
    else {
      resolved.perception_type = 0
    }

    if (msg.valid !== undefined) {
      resolved.valid = msg.valid;
    }
    else {
      resolved.valid = false
    }

    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.perception_actual_rate !== undefined) {
      resolved.perception_actual_rate = msg.perception_actual_rate;
    }
    else {
      resolved.perception_actual_rate = 0.0
    }

    if (msg.detect_tags !== undefined) {
      resolved.detect_tags = msg.detect_tags;
    }
    else {
      resolved.detect_tags = 0.0
    }

    if (msg.tag_id !== undefined) {
      resolved.tag_id = msg.tag_id;
    }
    else {
      resolved.tag_id = 0
    }

    if (msg.reproject_error !== undefined) {
      resolved.reproject_error = msg.reproject_error;
    }
    else {
      resolved.reproject_error = 0.0
    }

    if (msg.wMe !== undefined) {
      resolved.wMe = geometry_msgs.msg.Pose.Resolve(msg.wMe)
    }
    else {
      resolved.wMe = new geometry_msgs.msg.Pose()
    }

    if (msg.wMc !== undefined) {
      resolved.wMc = geometry_msgs.msg.Pose.Resolve(msg.wMc)
    }
    else {
      resolved.wMc = new geometry_msgs.msg.Pose()
    }

    if (msg.tag_ids_for_solvePnP !== undefined) {
      resolved.tag_ids_for_solvePnP = msg.tag_ids_for_solvePnP;
    }
    else {
      resolved.tag_ids_for_solvePnP = []
    }

    if (msg.wMe_map_keys !== undefined) {
      resolved.wMe_map_keys = msg.wMe_map_keys;
    }
    else {
      resolved.wMe_map_keys = []
    }

    if (msg.wMe_map_values !== undefined) {
      resolved.wMe_map_values = new Array(msg.wMe_map_values.length);
      for (let i = 0; i < resolved.wMe_map_values.length; ++i) {
        resolved.wMe_map_values[i] = geometry_msgs.msg.Pose.Resolve(msg.wMe_map_values[i]);
      }
    }
    else {
      resolved.wMe_map_values = []
    }

    if (msg.wMc_map_keys !== undefined) {
      resolved.wMc_map_keys = msg.wMc_map_keys;
    }
    else {
      resolved.wMc_map_keys = []
    }

    if (msg.wMc_map_values !== undefined) {
      resolved.wMc_map_values = new Array(msg.wMc_map_values.length);
      for (let i = 0; i < resolved.wMc_map_values.length; ++i) {
        resolved.wMc_map_values[i] = geometry_msgs.msg.Pose.Resolve(msg.wMc_map_values[i]);
      }
    }
    else {
      resolved.wMc_map_values = []
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    if (msg.scan_map_keys !== undefined) {
      resolved.scan_map_keys = msg.scan_map_keys;
    }
    else {
      resolved.scan_map_keys = []
    }

    if (msg.scan_map_values !== undefined) {
      resolved.scan_map_values = new Array(msg.scan_map_values.length);
      for (let i = 0; i < resolved.scan_map_values.length; ++i) {
        resolved.scan_map_values[i] = sensor_msgs.msg.LaserScan.Resolve(msg.scan_map_values[i]);
      }
    }
    else {
      resolved.scan_map_values = []
    }

    if (msg.pointcloud2_map_keys !== undefined) {
      resolved.pointcloud2_map_keys = msg.pointcloud2_map_keys;
    }
    else {
      resolved.pointcloud2_map_keys = []
    }

    if (msg.pointcloud2_map_values !== undefined) {
      resolved.pointcloud2_map_values = new Array(msg.pointcloud2_map_values.length);
      for (let i = 0; i < resolved.pointcloud2_map_values.length; ++i) {
        resolved.pointcloud2_map_values[i] = sensor_msgs.msg.PointCloud2.Resolve(msg.pointcloud2_map_values[i]);
      }
    }
    else {
      resolved.pointcloud2_map_values = []
    }

    if (msg.polygon_map_keys !== undefined) {
      resolved.polygon_map_keys = msg.polygon_map_keys;
    }
    else {
      resolved.polygon_map_keys = []
    }

    if (msg.polygon_map_values !== undefined) {
      resolved.polygon_map_values = new Array(msg.polygon_map_values.length);
      for (let i = 0; i < resolved.polygon_map_values.length; ++i) {
        resolved.polygon_map_values[i] = geometry_msgs.msg.PolygonStamped.Resolve(msg.polygon_map_values[i]);
      }
    }
    else {
      resolved.polygon_map_values = []
    }

    return resolved;
    }
};

// Constants for message
IplusPerceptionResult.Constants = {
  NO_DEFINED_PERCEPTION: 0,
  CAMERA_PERCEPTION: 1,
  PALLET_PERCEPTION: 2,
  ODOM_PERCEPTION: 3,
  FUSION_PERCEPTION: 4,
  GROUNDTAG_PERCEPTION: 5,
  ICP3D_PERCEPTION: 6,
  LASER_PERCEPTION: 7,
  LASER2IMAGE_PERCEPTION: 8,
  LASER3D_LINE_PERCEPTION: 9,
  LASER3D_PERCEPTION: 10,
  LASERMARK_PERCEPTION: 11,
  ALERT_PERCEPTION: 12,
  REACVITISION_PERCEPTION: 13,
  REFLECTIVE_PLATE_PERCEPTION: 14,
  SHELF_PERCEPTION: 15,
  TF_ODOM_PERCEPTION: 16,
  TF_MAP_PERCEPTION: 17,
  TF_PERCEPTION: 18,
  VMODEL_PERCEPTION: 19,
  ZBAR_PERCEPTION: 20,
  PSD_PERCEPTION: 21,
  FM_PERCEPTION: 22,
  LINE_LASER_PERCEPTION: 23,
  DUAL_CAMERA_PERCEPTION: 24,
  DOT_MARKER_PERCEPTION: 25,
}

module.exports = IplusPerceptionResult;
