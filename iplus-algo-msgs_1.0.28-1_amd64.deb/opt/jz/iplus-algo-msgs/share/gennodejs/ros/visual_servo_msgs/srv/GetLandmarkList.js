// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let cartographer_ros_msgs = _finder('cartographer_ros_msgs');

//-----------------------------------------------------------

class GetLandmarkListRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetLandmarkListRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetLandmarkListRequest
    let len;
    let data = new GetLandmarkListRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/GetLandmarkListRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetLandmarkListRequest(null);
    return resolved;
    }
};

class GetLandmarkListResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_succeed = null;
      this.landmark_list = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('is_succeed')) {
        this.is_succeed = initObj.is_succeed
      }
      else {
        this.is_succeed = false;
      }
      if (initObj.hasOwnProperty('landmark_list')) {
        this.landmark_list = initObj.landmark_list
      }
      else {
        this.landmark_list = new cartographer_ros_msgs.msg.LandmarkList();
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetLandmarkListResponse
    // Serialize message field [is_succeed]
    bufferOffset = _serializer.bool(obj.is_succeed, buffer, bufferOffset);
    // Serialize message field [landmark_list]
    bufferOffset = cartographer_ros_msgs.msg.LandmarkList.serialize(obj.landmark_list, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetLandmarkListResponse
    let len;
    let data = new GetLandmarkListResponse(null);
    // Deserialize message field [is_succeed]
    data.is_succeed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [landmark_list]
    data.landmark_list = cartographer_ros_msgs.msg.LandmarkList.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += cartographer_ros_msgs.msg.LandmarkList.getMessageSize(object.landmark_list);
    length += object.error_message.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/GetLandmarkListResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '445b42d12f864720bd8e9efef5318384';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool is_succeed
    cartographer_ros_msgs/LandmarkList  landmark_list
    string error_message
    
    
    ================================================================================
    MSG: cartographer_ros_msgs/LandmarkList
    # Copyright 2018 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    std_msgs/Header header
    cartographer_ros_msgs/LandmarkEntry[] landmarks
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: cartographer_ros_msgs/LandmarkEntry
    # 2018 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    string id
    geometry_msgs/Pose tracking_from_landmark_transform
    geometry_msgs/Point32[] observation_points_in_base
    float64 translation_weight
    float64 rotation_weight
    float64 pole_radius
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: geometry_msgs/Point32
    # This contains the position of a point in free space(with 32 bits of precision).
    # It is recommeded to use Point wherever possible instead of Point32.  
    # 
    # This recommendation is to promote interoperability.  
    #
    # This message is designed to take up less space when sending
    # lots of points at once, as in the case of a PointCloud.  
    
    float32 x
    float32 y
    float32 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetLandmarkListResponse(null);
    if (msg.is_succeed !== undefined) {
      resolved.is_succeed = msg.is_succeed;
    }
    else {
      resolved.is_succeed = false
    }

    if (msg.landmark_list !== undefined) {
      resolved.landmark_list = cartographer_ros_msgs.msg.LandmarkList.Resolve(msg.landmark_list)
    }
    else {
      resolved.landmark_list = new cartographer_ros_msgs.msg.LandmarkList()
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GetLandmarkListRequest,
  Response: GetLandmarkListResponse,
  md5sum() { return '445b42d12f864720bd8e9efef5318384'; },
  datatype() { return 'visual_servo_msgs/GetLandmarkList'; }
};
