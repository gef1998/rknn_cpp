// Auto-generated. Do not edit!

// (in-package vtr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class TagCorrectionInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.map_name = null;
      this.last_tag_id = null;
      this.current_tag_id = null;
      this.t_tag_map_to_ref_1 = null;
      this.t_ref_0_to_tag_map = null;
      this.t_odom_to_ref_0 = null;
      this.t_ref_1_plus_to_odom = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('map_name')) {
        this.map_name = initObj.map_name
      }
      else {
        this.map_name = '';
      }
      if (initObj.hasOwnProperty('last_tag_id')) {
        this.last_tag_id = initObj.last_tag_id
      }
      else {
        this.last_tag_id = 0;
      }
      if (initObj.hasOwnProperty('current_tag_id')) {
        this.current_tag_id = initObj.current_tag_id
      }
      else {
        this.current_tag_id = 0;
      }
      if (initObj.hasOwnProperty('t_tag_map_to_ref_1')) {
        this.t_tag_map_to_ref_1 = initObj.t_tag_map_to_ref_1
      }
      else {
        this.t_tag_map_to_ref_1 = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('t_ref_0_to_tag_map')) {
        this.t_ref_0_to_tag_map = initObj.t_ref_0_to_tag_map
      }
      else {
        this.t_ref_0_to_tag_map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('t_odom_to_ref_0')) {
        this.t_odom_to_ref_0 = initObj.t_odom_to_ref_0
      }
      else {
        this.t_odom_to_ref_0 = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('t_ref_1_plus_to_odom')) {
        this.t_ref_1_plus_to_odom = initObj.t_ref_1_plus_to_odom
      }
      else {
        this.t_ref_1_plus_to_odom = new geometry_msgs.msg.Pose();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TagCorrectionInfo
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [map_name]
    bufferOffset = _serializer.string(obj.map_name, buffer, bufferOffset);
    // Serialize message field [last_tag_id]
    bufferOffset = _serializer.int64(obj.last_tag_id, buffer, bufferOffset);
    // Serialize message field [current_tag_id]
    bufferOffset = _serializer.int64(obj.current_tag_id, buffer, bufferOffset);
    // Serialize message field [t_tag_map_to_ref_1]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.t_tag_map_to_ref_1, buffer, bufferOffset);
    // Serialize message field [t_ref_0_to_tag_map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.t_ref_0_to_tag_map, buffer, bufferOffset);
    // Serialize message field [t_odom_to_ref_0]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.t_odom_to_ref_0, buffer, bufferOffset);
    // Serialize message field [t_ref_1_plus_to_odom]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.t_ref_1_plus_to_odom, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TagCorrectionInfo
    let len;
    let data = new TagCorrectionInfo(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [map_name]
    data.map_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [last_tag_id]
    data.last_tag_id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [current_tag_id]
    data.current_tag_id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [t_tag_map_to_ref_1]
    data.t_tag_map_to_ref_1 = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [t_ref_0_to_tag_map]
    data.t_ref_0_to_tag_map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [t_odom_to_ref_0]
    data.t_odom_to_ref_0 = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [t_ref_1_plus_to_odom]
    data.t_ref_1_plus_to_odom = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.map_name.length;
    return length + 244;
  }

  static datatype() {
    // Returns string type for a message object
    return 'vtr_msgs/TagCorrectionInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '01a8bdbb3b34aa1baf4d6c5f9fdd788d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    string map_name
    int64 last_tag_id
    int64 current_tag_id
    geometry_msgs/Pose t_tag_map_to_ref_1
    geometry_msgs/Pose t_ref_0_to_tag_map
    geometry_msgs/Pose t_odom_to_ref_0
    geometry_msgs/Pose t_ref_1_plus_to_odom
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TagCorrectionInfo(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.map_name !== undefined) {
      resolved.map_name = msg.map_name;
    }
    else {
      resolved.map_name = ''
    }

    if (msg.last_tag_id !== undefined) {
      resolved.last_tag_id = msg.last_tag_id;
    }
    else {
      resolved.last_tag_id = 0
    }

    if (msg.current_tag_id !== undefined) {
      resolved.current_tag_id = msg.current_tag_id;
    }
    else {
      resolved.current_tag_id = 0
    }

    if (msg.t_tag_map_to_ref_1 !== undefined) {
      resolved.t_tag_map_to_ref_1 = geometry_msgs.msg.Pose.Resolve(msg.t_tag_map_to_ref_1)
    }
    else {
      resolved.t_tag_map_to_ref_1 = new geometry_msgs.msg.Pose()
    }

    if (msg.t_ref_0_to_tag_map !== undefined) {
      resolved.t_ref_0_to_tag_map = geometry_msgs.msg.Pose.Resolve(msg.t_ref_0_to_tag_map)
    }
    else {
      resolved.t_ref_0_to_tag_map = new geometry_msgs.msg.Pose()
    }

    if (msg.t_odom_to_ref_0 !== undefined) {
      resolved.t_odom_to_ref_0 = geometry_msgs.msg.Pose.Resolve(msg.t_odom_to_ref_0)
    }
    else {
      resolved.t_odom_to_ref_0 = new geometry_msgs.msg.Pose()
    }

    if (msg.t_ref_1_plus_to_odom !== undefined) {
      resolved.t_ref_1_plus_to_odom = geometry_msgs.msg.Pose.Resolve(msg.t_ref_1_plus_to_odom)
    }
    else {
      resolved.t_ref_1_plus_to_odom = new geometry_msgs.msg.Pose()
    }

    return resolved;
    }
};

module.exports = TagCorrectionInfo;
