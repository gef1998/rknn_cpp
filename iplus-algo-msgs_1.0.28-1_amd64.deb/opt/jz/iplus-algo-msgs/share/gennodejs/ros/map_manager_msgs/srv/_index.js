
"use strict";

let GetImage = require('./GetImage.js')
let GetTagMap = require('./GetTagMap.js')
let GetPose = require('./GetPose.js')
let Set2dPoints = require('./Set2dPoints.js')
let DetectVisualmarksService = require('./DetectVisualmarksService.js')
let MapsAlign = require('./MapsAlign.js')
let CropPointService = require('./CropPointService.js')
let CreateBlankMapService = require('./CreateBlankMapService.js')
let TagMapInfos = require('./TagMapInfos.js')
let IdRemapSrv = require('./IdRemapSrv.js')
let GhostingDetectionService = require('./GhostingDetectionService.js')
let Get2dPoints = require('./Get2dPoints.js')
let TagInfos = require('./TagInfos.js')
let ReflectorDetectionService = require('./ReflectorDetectionService.js')
let MergeMapService = require('./MergeMapService.js')
let LMRelocationService = require('./LMRelocationService.js')
let MergeSubmaps = require('./MergeSubmaps.js')

module.exports = {
  GetImage: GetImage,
  GetTagMap: GetTagMap,
  GetPose: GetPose,
  Set2dPoints: Set2dPoints,
  DetectVisualmarksService: DetectVisualmarksService,
  MapsAlign: MapsAlign,
  CropPointService: CropPointService,
  CreateBlankMapService: CreateBlankMapService,
  TagMapInfos: TagMapInfos,
  IdRemapSrv: IdRemapSrv,
  GhostingDetectionService: GhostingDetectionService,
  Get2dPoints: Get2dPoints,
  TagInfos: TagInfos,
  ReflectorDetectionService: ReflectorDetectionService,
  MergeMapService: MergeMapService,
  LMRelocationService: LMRelocationService,
  MergeSubmaps: MergeSubmaps,
};
