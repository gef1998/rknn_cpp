// Auto-generated. Do not edit!

// (in-package vtr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Pose = require('../msg/Pose.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetInitialPoseRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.type = null;
      this.base2map = null;
    }
    else {
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = '';
      }
      if (initObj.hasOwnProperty('base2map')) {
        this.base2map = initObj.base2map
      }
      else {
        this.base2map = new Pose();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetInitialPoseRequest
    // Serialize message field [type]
    bufferOffset = _serializer.string(obj.type, buffer, bufferOffset);
    // Serialize message field [base2map]
    bufferOffset = Pose.serialize(obj.base2map, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetInitialPoseRequest
    let len;
    let data = new SetInitialPoseRequest(null);
    // Deserialize message field [type]
    data.type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [base2map]
    data.base2map = Pose.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.type.length;
    length += Pose.getMessageSize(object.base2map);
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/SetInitialPoseRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f823543a59c473d3194832fb4336436d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string TYPE_LASER_LOCALIZATION = "Laser"
    string TYPE_TEXTURE_LOCALIZATION = "Texture"
    
    string type
    vtr_msgs/Pose base2map
    
    ================================================================================
    MSG: vtr_msgs/Pose
    #
    std_msgs/Header header
    string localization_type
    int64 reference_id
    geometry_msgs/PoseWithCovariance pose
    bool pose_valid
    
    int64 color 
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseWithCovariance
    # This represents a pose in free space with uncertainty.
    
    Pose pose
    
    # Row-major representation of the 6x6 covariance matrix
    # The orientation parameters use a fixed-axis representation.
    # In order, the parameters are:
    # (x, y, z, rotation about X axis, rotation about Y axis, rotation about Z axis)
    float64[36] covariance
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetInitialPoseRequest(null);
    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = ''
    }

    if (msg.base2map !== undefined) {
      resolved.base2map = Pose.Resolve(msg.base2map)
    }
    else {
      resolved.base2map = new Pose()
    }

    return resolved;
    }
};

// Constants for message
SetInitialPoseRequest.Constants = {
  TYPE_LASER_LOCALIZATION: '"Laser"',
  TYPE_TEXTURE_LOCALIZATION: '"Texture"',
}

class SetInitialPoseResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_succeed = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('is_succeed')) {
        this.is_succeed = initObj.is_succeed
      }
      else {
        this.is_succeed = false;
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetInitialPoseResponse
    // Serialize message field [is_succeed]
    bufferOffset = _serializer.bool(obj.is_succeed, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetInitialPoseResponse
    let len;
    let data = new SetInitialPoseResponse(null);
    // Deserialize message field [is_succeed]
    data.is_succeed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_message.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/SetInitialPoseResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '87b3ee6ab2f7c95aed4205460020897c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool is_succeed
    string error_message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetInitialPoseResponse(null);
    if (msg.is_succeed !== undefined) {
      resolved.is_succeed = msg.is_succeed;
    }
    else {
      resolved.is_succeed = false
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SetInitialPoseRequest,
  Response: SetInitialPoseResponse,
  md5sum() { return 'bdfbd02810d662d855483c3661f613d3'; },
  datatype() { return 'vtr_msgs/SetInitialPose'; }
};
