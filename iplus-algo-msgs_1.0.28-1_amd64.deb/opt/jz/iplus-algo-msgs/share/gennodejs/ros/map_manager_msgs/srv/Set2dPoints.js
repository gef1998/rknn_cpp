// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Points2d = require('../msg/Points2d.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class Set2dPointsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map_name = null;
      this.topo_corner_points = null;
    }
    else {
      if (initObj.hasOwnProperty('map_name')) {
        this.map_name = initObj.map_name
      }
      else {
        this.map_name = '';
      }
      if (initObj.hasOwnProperty('topo_corner_points')) {
        this.topo_corner_points = initObj.topo_corner_points
      }
      else {
        this.topo_corner_points = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Set2dPointsRequest
    // Serialize message field [map_name]
    bufferOffset = _serializer.string(obj.map_name, buffer, bufferOffset);
    // Serialize message field [topo_corner_points]
    // Serialize the length for message field [topo_corner_points]
    bufferOffset = _serializer.uint32(obj.topo_corner_points.length, buffer, bufferOffset);
    obj.topo_corner_points.forEach((val) => {
      bufferOffset = Points2d.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Set2dPointsRequest
    let len;
    let data = new Set2dPointsRequest(null);
    // Deserialize message field [map_name]
    data.map_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [topo_corner_points]
    // Deserialize array length for message field [topo_corner_points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.topo_corner_points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.topo_corner_points[i] = Points2d.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.map_name.length;
    object.topo_corner_points.forEach((val) => {
      length += Points2d.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/Set2dPointsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b6d7e75716d112ccee9ad5aded1cc93a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string map_name
    map_manager_msgs/Points2d[] topo_corner_points
    
    ================================================================================
    MSG: map_manager_msgs/Points2d
    map_manager_msgs/Point2d[] points
    
    ================================================================================
    MSG: map_manager_msgs/Point2d
    float64 x
    float64 y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Set2dPointsRequest(null);
    if (msg.map_name !== undefined) {
      resolved.map_name = msg.map_name;
    }
    else {
      resolved.map_name = ''
    }

    if (msg.topo_corner_points !== undefined) {
      resolved.topo_corner_points = new Array(msg.topo_corner_points.length);
      for (let i = 0; i < resolved.topo_corner_points.length; ++i) {
        resolved.topo_corner_points[i] = Points2d.Resolve(msg.topo_corner_points[i]);
      }
    }
    else {
      resolved.topo_corner_points = []
    }

    return resolved;
    }
};

class Set2dPointsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_msgs = null;
    }
    else {
      if (initObj.hasOwnProperty('error_msgs')) {
        this.error_msgs = initObj.error_msgs
      }
      else {
        this.error_msgs = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Set2dPointsResponse
    // Serialize message field [error_msgs]
    bufferOffset = _serializer.string(obj.error_msgs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Set2dPointsResponse
    let len;
    let data = new Set2dPointsResponse(null);
    // Deserialize message field [error_msgs]
    data.error_msgs = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_msgs.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/Set2dPointsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '31076761bb7a15c7d145b393c8a56624';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_msgs
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Set2dPointsResponse(null);
    if (msg.error_msgs !== undefined) {
      resolved.error_msgs = msg.error_msgs;
    }
    else {
      resolved.error_msgs = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: Set2dPointsRequest,
  Response: Set2dPointsResponse,
  md5sum() { return '98e83abbda8a6b3bb4cf6a4c35db0a72'; },
  datatype() { return 'map_manager_msgs/Set2dPoints'; }
};
