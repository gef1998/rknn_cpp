// Auto-generated. Do not edit!

// (in-package move_task_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TargetGoal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.id_lists = null;
      this.move_types = null;
      this.state_times = null;
      this.spare_json_str = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('id_lists')) {
        this.id_lists = initObj.id_lists
      }
      else {
        this.id_lists = [];
      }
      if (initObj.hasOwnProperty('move_types')) {
        this.move_types = initObj.move_types
      }
      else {
        this.move_types = [];
      }
      if (initObj.hasOwnProperty('state_times')) {
        this.state_times = initObj.state_times
      }
      else {
        this.state_times = [];
      }
      if (initObj.hasOwnProperty('spare_json_str')) {
        this.spare_json_str = initObj.spare_json_str
      }
      else {
        this.spare_json_str = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TargetGoal
    // Serialize message field [id]
    bufferOffset = _serializer.uint64(obj.id, buffer, bufferOffset);
    // Serialize message field [id_lists]
    bufferOffset = _arraySerializer.uint64(obj.id_lists, buffer, bufferOffset, null);
    // Serialize message field [move_types]
    bufferOffset = _arraySerializer.uint64(obj.move_types, buffer, bufferOffset, null);
    // Serialize message field [state_times]
    bufferOffset = _arraySerializer.uint64(obj.state_times, buffer, bufferOffset, null);
    // Serialize message field [spare_json_str]
    bufferOffset = _serializer.string(obj.spare_json_str, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TargetGoal
    let len;
    let data = new TargetGoal(null);
    // Deserialize message field [id]
    data.id = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [id_lists]
    data.id_lists = _arrayDeserializer.uint64(buffer, bufferOffset, null)
    // Deserialize message field [move_types]
    data.move_types = _arrayDeserializer.uint64(buffer, bufferOffset, null)
    // Deserialize message field [state_times]
    data.state_times = _arrayDeserializer.uint64(buffer, bufferOffset, null)
    // Deserialize message field [spare_json_str]
    data.spare_json_str = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.id_lists.length;
    length += 8 * object.move_types.length;
    length += 8 * object.state_times.length;
    length += object.spare_json_str.length;
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'move_task_msgs/TargetGoal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '130da7eb5686d58116461ec0fe06ffde';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint64 id
    uint64[] id_lists
    uint64[] move_types
    uint64[] state_times
    string spare_json_str
    
    # move_type 
    uint64 ForwardMove      = 0
    uint64 BackwardMove     = 1
    uint64 LateralLeftMove  = 2
    uint64 LeteralRigthMove = 3
    uint64 WaitInPlace      = 10
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TargetGoal(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.id_lists !== undefined) {
      resolved.id_lists = msg.id_lists;
    }
    else {
      resolved.id_lists = []
    }

    if (msg.move_types !== undefined) {
      resolved.move_types = msg.move_types;
    }
    else {
      resolved.move_types = []
    }

    if (msg.state_times !== undefined) {
      resolved.state_times = msg.state_times;
    }
    else {
      resolved.state_times = []
    }

    if (msg.spare_json_str !== undefined) {
      resolved.spare_json_str = msg.spare_json_str;
    }
    else {
      resolved.spare_json_str = ''
    }

    return resolved;
    }
};

// Constants for message
TargetGoal.Constants = {
  FORWARDMOVE: 0,
  BACKWARDMOVE: 1,
  LATERALLEFTMOVE: 2,
  LETERALRIGTHMOVE: 3,
  WAITINPLACE: 10,
}

module.exports = TargetGoal;
