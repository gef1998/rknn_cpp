// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class PrecisonSingleGetRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.type = null;
      this.camera_type = null;
      this.tag_type = null;
      this.template_id = null;
      this.minCorner = null;
      this.maxCorner = null;
      this.angleThreashOnDegree = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('camera_type')) {
        this.camera_type = initObj.camera_type
      }
      else {
        this.camera_type = 0;
      }
      if (initObj.hasOwnProperty('tag_type')) {
        this.tag_type = initObj.tag_type
      }
      else {
        this.tag_type = 0;
      }
      if (initObj.hasOwnProperty('template_id')) {
        this.template_id = initObj.template_id
      }
      else {
        this.template_id = 0;
      }
      if (initObj.hasOwnProperty('minCorner')) {
        this.minCorner = initObj.minCorner
      }
      else {
        this.minCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('maxCorner')) {
        this.maxCorner = initObj.maxCorner
      }
      else {
        this.maxCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('angleThreashOnDegree')) {
        this.angleThreashOnDegree = initObj.angleThreashOnDegree
      }
      else {
        this.angleThreashOnDegree = new Array(2).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PrecisonSingleGetRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [camera_type]
    bufferOffset = _serializer.uint8(obj.camera_type, buffer, bufferOffset);
    // Serialize message field [tag_type]
    bufferOffset = _serializer.uint8(obj.tag_type, buffer, bufferOffset);
    // Serialize message field [template_id]
    bufferOffset = _serializer.int32(obj.template_id, buffer, bufferOffset);
    // Check that the constant length array field [minCorner] has the right length
    if (obj.minCorner.length !== 2) {
      throw new Error('Unable to serialize array field minCorner - length must be 2')
    }
    // Serialize message field [minCorner]
    bufferOffset = _arraySerializer.float32(obj.minCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [maxCorner] has the right length
    if (obj.maxCorner.length !== 2) {
      throw new Error('Unable to serialize array field maxCorner - length must be 2')
    }
    // Serialize message field [maxCorner]
    bufferOffset = _arraySerializer.float32(obj.maxCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [angleThreashOnDegree] has the right length
    if (obj.angleThreashOnDegree.length !== 2) {
      throw new Error('Unable to serialize array field angleThreashOnDegree - length must be 2')
    }
    // Serialize message field [angleThreashOnDegree]
    bufferOffset = _arraySerializer.float32(obj.angleThreashOnDegree, buffer, bufferOffset, 2);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PrecisonSingleGetRequest
    let len;
    let data = new PrecisonSingleGetRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [camera_type]
    data.camera_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [tag_type]
    data.tag_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [template_id]
    data.template_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [minCorner]
    data.minCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [maxCorner]
    data.maxCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [angleThreashOnDegree]
    data.angleThreashOnDegree = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 31;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/PrecisonSingleGetRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a207fbfd0f36010684edda9981dd9b82';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    uint8 type
    uint8 BASE2MAP = 0
    uint8 BASE2TEMPLATE = 1
    uint8 BASE2WORLD = 2
    
    
    uint8 camera_type
    uint8 UP_CAMERA = 0
    uint8 DOWN_CAMERA = 1
    uint8 tag_type
    uint8 SHELF_TAG = 0
    uint8 NORMAL_TAG = 1
    uint8 LANDMARK_TAG = 2
    
    
    
    
    
    int32 template_id
    float32[2] minCorner
    float32[2] maxCorner
    float32[2] angleThreashOnDegree
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PrecisonSingleGetRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.camera_type !== undefined) {
      resolved.camera_type = msg.camera_type;
    }
    else {
      resolved.camera_type = 0
    }

    if (msg.tag_type !== undefined) {
      resolved.tag_type = msg.tag_type;
    }
    else {
      resolved.tag_type = 0
    }

    if (msg.template_id !== undefined) {
      resolved.template_id = msg.template_id;
    }
    else {
      resolved.template_id = 0
    }

    if (msg.minCorner !== undefined) {
      resolved.minCorner = msg.minCorner;
    }
    else {
      resolved.minCorner = new Array(2).fill(0)
    }

    if (msg.maxCorner !== undefined) {
      resolved.maxCorner = msg.maxCorner;
    }
    else {
      resolved.maxCorner = new Array(2).fill(0)
    }

    if (msg.angleThreashOnDegree !== undefined) {
      resolved.angleThreashOnDegree = msg.angleThreashOnDegree;
    }
    else {
      resolved.angleThreashOnDegree = new Array(2).fill(0)
    }

    return resolved;
    }
};

// Constants for message
PrecisonSingleGetRequest.Constants = {
  BASE2MAP: 0,
  BASE2TEMPLATE: 1,
  BASE2WORLD: 2,
  UP_CAMERA: 0,
  DOWN_CAMERA: 1,
  SHELF_TAG: 0,
  NORMAL_TAG: 1,
  LANDMARK_TAG: 2,
}

class PrecisonSingleGetResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.baseInTest = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('baseInTest')) {
        this.baseInTest = initObj.baseInTest
      }
      else {
        this.baseInTest = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PrecisonSingleGetResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [baseInTest]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.baseInTest, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PrecisonSingleGetResponse
    let len;
    let data = new PrecisonSingleGetResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [baseInTest]
    data.baseInTest = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.error_message.length;
    return length + 28;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/PrecisonSingleGetResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e02020171608e16db0649c00992e2ddf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    geometry_msgs/Pose2D baseInTest
    string error_message
    
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PrecisonSingleGetResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.baseInTest !== undefined) {
      resolved.baseInTest = geometry_msgs.msg.Pose2D.Resolve(msg.baseInTest)
    }
    else {
      resolved.baseInTest = new geometry_msgs.msg.Pose2D()
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: PrecisonSingleGetRequest,
  Response: PrecisonSingleGetResponse,
  md5sum() { return '4098703fe035f15a4837abdb56472158'; },
  datatype() { return 'visual_servo_msgs/PrecisonSingleGet'; }
};
