// Auto-generated. Do not edit!

// (in-package move_task_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let TaskErrorType = require('./TaskErrorType.js');
let move_base_msgs = _finder('move_base_msgs');
let std_msgs = _finder('std_msgs');
let visual_servo_msgs = _finder('visual_servo_msgs');

//-----------------------------------------------------------

class MoveTaskResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.error_type = null;
      this.goal_id = null;
      this.mt_tmap_result = null;
      this.mt_map_result = null;
      this.mb_result = null;
      this.mt_result_json = null;
      this.vs_result = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('error_type')) {
        this.error_type = initObj.error_type
      }
      else {
        this.error_type = new TaskErrorType();
      }
      if (initObj.hasOwnProperty('goal_id')) {
        this.goal_id = initObj.goal_id
      }
      else {
        this.goal_id = 0;
      }
      if (initObj.hasOwnProperty('mt_tmap_result')) {
        this.mt_tmap_result = initObj.mt_tmap_result
      }
      else {
        this.mt_tmap_result = new move_base_msgs.msg.MoveBaseResult();
      }
      if (initObj.hasOwnProperty('mt_map_result')) {
        this.mt_map_result = initObj.mt_map_result
      }
      else {
        this.mt_map_result = new move_base_msgs.msg.MoveBaseResult();
      }
      if (initObj.hasOwnProperty('mb_result')) {
        this.mb_result = initObj.mb_result
      }
      else {
        this.mb_result = new move_base_msgs.msg.MoveBaseResult();
      }
      if (initObj.hasOwnProperty('mt_result_json')) {
        this.mt_result_json = initObj.mt_result_json
      }
      else {
        this.mt_result_json = '';
      }
      if (initObj.hasOwnProperty('vs_result')) {
        this.vs_result = initObj.vs_result
      }
      else {
        this.vs_result = new visual_servo_msgs.msg.IbvsConstrainedResult();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MoveTaskResult
    // Serialize message field [success]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.success, buffer, bufferOffset);
    // Serialize message field [error_type]
    bufferOffset = TaskErrorType.serialize(obj.error_type, buffer, bufferOffset);
    // Serialize message field [goal_id]
    bufferOffset = _serializer.uint64(obj.goal_id, buffer, bufferOffset);
    // Serialize message field [mt_tmap_result]
    bufferOffset = move_base_msgs.msg.MoveBaseResult.serialize(obj.mt_tmap_result, buffer, bufferOffset);
    // Serialize message field [mt_map_result]
    bufferOffset = move_base_msgs.msg.MoveBaseResult.serialize(obj.mt_map_result, buffer, bufferOffset);
    // Serialize message field [mb_result]
    bufferOffset = move_base_msgs.msg.MoveBaseResult.serialize(obj.mb_result, buffer, bufferOffset);
    // Serialize message field [mt_result_json]
    bufferOffset = _serializer.string(obj.mt_result_json, buffer, bufferOffset);
    // Serialize message field [vs_result]
    bufferOffset = visual_servo_msgs.msg.IbvsConstrainedResult.serialize(obj.vs_result, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MoveTaskResult
    let len;
    let data = new MoveTaskResult(null);
    // Deserialize message field [success]
    data.success = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_type]
    data.error_type = TaskErrorType.deserialize(buffer, bufferOffset);
    // Deserialize message field [goal_id]
    data.goal_id = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [mt_tmap_result]
    data.mt_tmap_result = move_base_msgs.msg.MoveBaseResult.deserialize(buffer, bufferOffset);
    // Deserialize message field [mt_map_result]
    data.mt_map_result = move_base_msgs.msg.MoveBaseResult.deserialize(buffer, bufferOffset);
    // Deserialize message field [mb_result]
    data.mb_result = move_base_msgs.msg.MoveBaseResult.deserialize(buffer, bufferOffset);
    // Deserialize message field [mt_result_json]
    data.mt_result_json = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [vs_result]
    data.vs_result = visual_servo_msgs.msg.IbvsConstrainedResult.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += TaskErrorType.getMessageSize(object.error_type);
    length += move_base_msgs.msg.MoveBaseResult.getMessageSize(object.mt_tmap_result);
    length += move_base_msgs.msg.MoveBaseResult.getMessageSize(object.mt_map_result);
    length += move_base_msgs.msg.MoveBaseResult.getMessageSize(object.mb_result);
    length += object.mt_result_json.length;
    length += visual_servo_msgs.msg.IbvsConstrainedResult.getMessageSize(object.vs_result);
    return length + 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'move_task_msgs/MoveTaskResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cda795770aa41262b7e666587d830b6e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    std_msgs/Bool success
    move_task_msgs/TaskErrorType error_type
    
    uint64 goal_id                               # navigation goal id
    move_base_msgs/MoveBaseResult mt_tmap_result # navigation tmap frame precision
    move_base_msgs/MoveBaseResult mt_map_result  # navigation map frame precision
    move_base_msgs/MoveBaseResult mb_result      # navigation motion(odom, map, tmap) precision
    string mt_result_json                        # navigation extend result log for future use
    visual_servo_msgs/IbvsConstrainedResult vs_result  # visual servo result
    
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    ================================================================================
    MSG: move_task_msgs/TaskErrorType
    # move task error type
    
    uint8 error
    
    uint8 INVALID_FRAME_ID = 0
    uint8 INVALID_GOAL_ID  = 1
    uint8 NO_TOPO_ROUTE    = 2
    uint8 MB_DISCONNECTED  = 3
    uint8 VS_DISCONNECTED  = 4
    uint8 INVALID_LOCAL_MOVE_FRAME = 5
    uint8 CANCEL_SIGNAL = 6
    uint8 LOCALIZATION_FAILED = 7
    uint8 VS_ERROR_DIST =8
    uint8 VS_ABORTED = 9
    uint8 LFVS_ERROR_Y = 10
    uint8 LFVS_ERROR_THETA = 11
    uint8 LFVS_ABORTED = 12
    uint8 ABORTED_IN_NEAREST_WP = 13
    uint8 ABORTED_IN_LAST_WP = 14
    uint8 MB_GOAL_BEYOND_SCOPE = 15
    uint8 LOCAL_MOVE_ABORTED = 16
    uint8 TASK_SERVER_KILLED = 17
    
    string error_des
    
    
    
    
    
    
    ================================================================================
    MSG: move_base_msgs/MoveBaseResult
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    bool success
    float64 err_x
    float64 err_y
    float64 err_theta
    string info
    
    ================================================================================
    MSG: visual_servo_msgs/IbvsConstrainedResult
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    #result definition
    int32 tag_id
    int32 vs_type
    float64 time_comsume
    geometry_msgs/Pose baseToTarget
    string json_string
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MoveTaskResult(null);
    if (msg.success !== undefined) {
      resolved.success = std_msgs.msg.Bool.Resolve(msg.success)
    }
    else {
      resolved.success = new std_msgs.msg.Bool()
    }

    if (msg.error_type !== undefined) {
      resolved.error_type = TaskErrorType.Resolve(msg.error_type)
    }
    else {
      resolved.error_type = new TaskErrorType()
    }

    if (msg.goal_id !== undefined) {
      resolved.goal_id = msg.goal_id;
    }
    else {
      resolved.goal_id = 0
    }

    if (msg.mt_tmap_result !== undefined) {
      resolved.mt_tmap_result = move_base_msgs.msg.MoveBaseResult.Resolve(msg.mt_tmap_result)
    }
    else {
      resolved.mt_tmap_result = new move_base_msgs.msg.MoveBaseResult()
    }

    if (msg.mt_map_result !== undefined) {
      resolved.mt_map_result = move_base_msgs.msg.MoveBaseResult.Resolve(msg.mt_map_result)
    }
    else {
      resolved.mt_map_result = new move_base_msgs.msg.MoveBaseResult()
    }

    if (msg.mb_result !== undefined) {
      resolved.mb_result = move_base_msgs.msg.MoveBaseResult.Resolve(msg.mb_result)
    }
    else {
      resolved.mb_result = new move_base_msgs.msg.MoveBaseResult()
    }

    if (msg.mt_result_json !== undefined) {
      resolved.mt_result_json = msg.mt_result_json;
    }
    else {
      resolved.mt_result_json = ''
    }

    if (msg.vs_result !== undefined) {
      resolved.vs_result = visual_servo_msgs.msg.IbvsConstrainedResult.Resolve(msg.vs_result)
    }
    else {
      resolved.vs_result = new visual_servo_msgs.msg.IbvsConstrainedResult()
    }

    return resolved;
    }
};

module.exports = MoveTaskResult;
