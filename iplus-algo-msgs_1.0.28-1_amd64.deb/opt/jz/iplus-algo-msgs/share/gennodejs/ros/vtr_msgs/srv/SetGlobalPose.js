// Auto-generated. Do not edit!

// (in-package vtr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let GlobalLocalizationPose = require('../msg/GlobalLocalizationPose.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetGlobalPoseRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pose = null;
    }
    else {
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new GlobalLocalizationPose();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetGlobalPoseRequest
    // Serialize message field [pose]
    bufferOffset = GlobalLocalizationPose.serialize(obj.pose, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetGlobalPoseRequest
    let len;
    let data = new SetGlobalPoseRequest(null);
    // Deserialize message field [pose]
    data.pose = GlobalLocalizationPose.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += GlobalLocalizationPose.getMessageSize(object.pose);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/SetGlobalPoseRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '20476fb93f61b7bfe58681df8250eba1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    vtr_msgs/GlobalLocalizationPose pose
    
    ================================================================================
    MSG: vtr_msgs/GlobalLocalizationPose
    std_msgs/Header header
    int64 reference_id
    geometry_msgs/PoseWithCovariance sensor2reference
    geometry_msgs/Pose sensor2odom
    bool pose_valid
    string localization_type
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseWithCovariance
    # This represents a pose in free space with uncertainty.
    
    Pose pose
    
    # Row-major representation of the 6x6 covariance matrix
    # The orientation parameters use a fixed-axis representation.
    # In order, the parameters are:
    # (x, y, z, rotation about X axis, rotation about Y axis, rotation about Z axis)
    float64[36] covariance
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetGlobalPoseRequest(null);
    if (msg.pose !== undefined) {
      resolved.pose = GlobalLocalizationPose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new GlobalLocalizationPose()
    }

    return resolved;
    }
};

class SetGlobalPoseResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetGlobalPoseResponse
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetGlobalPoseResponse
    let len;
    let data = new SetGlobalPoseResponse(null);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_message.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/SetGlobalPoseResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a13979422fc129b30b15994450a302b5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetGlobalPoseResponse(null);
    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SetGlobalPoseRequest,
  Response: SetGlobalPoseResponse,
  md5sum() { return '4e9d90e00d41ee95367f35a6b3b043df'; },
  datatype() { return 'vtr_msgs/SetGlobalPose'; }
};
