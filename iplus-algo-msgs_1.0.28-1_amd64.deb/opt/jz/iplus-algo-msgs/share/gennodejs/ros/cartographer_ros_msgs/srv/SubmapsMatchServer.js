// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SubmapsMatchServerRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.trajectory_id_ref = null;
      this.submap_index_ref = null;
      this.trajectory_id_src = null;
      this.submap_index_src = null;
    }
    else {
      if (initObj.hasOwnProperty('trajectory_id_ref')) {
        this.trajectory_id_ref = initObj.trajectory_id_ref
      }
      else {
        this.trajectory_id_ref = 0;
      }
      if (initObj.hasOwnProperty('submap_index_ref')) {
        this.submap_index_ref = initObj.submap_index_ref
      }
      else {
        this.submap_index_ref = 0;
      }
      if (initObj.hasOwnProperty('trajectory_id_src')) {
        this.trajectory_id_src = initObj.trajectory_id_src
      }
      else {
        this.trajectory_id_src = 0;
      }
      if (initObj.hasOwnProperty('submap_index_src')) {
        this.submap_index_src = initObj.submap_index_src
      }
      else {
        this.submap_index_src = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SubmapsMatchServerRequest
    // Serialize message field [trajectory_id_ref]
    bufferOffset = _serializer.int32(obj.trajectory_id_ref, buffer, bufferOffset);
    // Serialize message field [submap_index_ref]
    bufferOffset = _serializer.int32(obj.submap_index_ref, buffer, bufferOffset);
    // Serialize message field [trajectory_id_src]
    bufferOffset = _serializer.int32(obj.trajectory_id_src, buffer, bufferOffset);
    // Serialize message field [submap_index_src]
    bufferOffset = _serializer.int32(obj.submap_index_src, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SubmapsMatchServerRequest
    let len;
    let data = new SubmapsMatchServerRequest(null);
    // Deserialize message field [trajectory_id_ref]
    data.trajectory_id_ref = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [submap_index_ref]
    data.submap_index_ref = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [trajectory_id_src]
    data.trajectory_id_src = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [submap_index_src]
    data.submap_index_src = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/SubmapsMatchServerRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f84764cd47c5ada315055bb2be782149';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    int32 trajectory_id_ref
    int32 submap_index_ref
    int32 trajectory_id_src
    int32 submap_index_src
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SubmapsMatchServerRequest(null);
    if (msg.trajectory_id_ref !== undefined) {
      resolved.trajectory_id_ref = msg.trajectory_id_ref;
    }
    else {
      resolved.trajectory_id_ref = 0
    }

    if (msg.submap_index_ref !== undefined) {
      resolved.submap_index_ref = msg.submap_index_ref;
    }
    else {
      resolved.submap_index_ref = 0
    }

    if (msg.trajectory_id_src !== undefined) {
      resolved.trajectory_id_src = msg.trajectory_id_src;
    }
    else {
      resolved.trajectory_id_src = 0
    }

    if (msg.submap_index_src !== undefined) {
      resolved.submap_index_src = msg.submap_index_src;
    }
    else {
      resolved.submap_index_src = 0
    }

    return resolved;
    }
};

class SubmapsMatchServerResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.matched_nodes_id = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('matched_nodes_id')) {
        this.matched_nodes_id = initObj.matched_nodes_id
      }
      else {
        this.matched_nodes_id = [];
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SubmapsMatchServerResponse
    // Serialize message field [matched_nodes_id]
    bufferOffset = _arraySerializer.int32(obj.matched_nodes_id, buffer, bufferOffset, null);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SubmapsMatchServerResponse
    let len;
    let data = new SubmapsMatchServerResponse(null);
    // Deserialize message field [matched_nodes_id]
    data.matched_nodes_id = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.matched_nodes_id.length;
    length += object.error_message.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/SubmapsMatchServerResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5b2e6fe5987be0631db898b7fd97744c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32[] matched_nodes_id
    string error_message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SubmapsMatchServerResponse(null);
    if (msg.matched_nodes_id !== undefined) {
      resolved.matched_nodes_id = msg.matched_nodes_id;
    }
    else {
      resolved.matched_nodes_id = []
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SubmapsMatchServerRequest,
  Response: SubmapsMatchServerResponse,
  md5sum() { return '928be98ee3bf5c18ed7d1a2a45d17a9a'; },
  datatype() { return 'cartographer_ros_msgs/SubmapsMatchServer'; }
};
