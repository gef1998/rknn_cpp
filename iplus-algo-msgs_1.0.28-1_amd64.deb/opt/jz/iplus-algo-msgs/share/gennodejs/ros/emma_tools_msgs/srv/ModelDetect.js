// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

let ModelDtectorResult = require('../msg/ModelDtectorResult.js');

//-----------------------------------------------------------

class ModelDetectRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map_name = null;
      this.model_id = null;
      this.region = null;
      this.config_json_sting = null;
    }
    else {
      if (initObj.hasOwnProperty('map_name')) {
        this.map_name = initObj.map_name
      }
      else {
        this.map_name = '';
      }
      if (initObj.hasOwnProperty('model_id')) {
        this.model_id = initObj.model_id
      }
      else {
        this.model_id = 0;
      }
      if (initObj.hasOwnProperty('region')) {
        this.region = initObj.region
      }
      else {
        this.region = new geometry_msgs.msg.Polygon();
      }
      if (initObj.hasOwnProperty('config_json_sting')) {
        this.config_json_sting = initObj.config_json_sting
      }
      else {
        this.config_json_sting = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ModelDetectRequest
    // Serialize message field [map_name]
    bufferOffset = _serializer.string(obj.map_name, buffer, bufferOffset);
    // Serialize message field [model_id]
    bufferOffset = _serializer.int32(obj.model_id, buffer, bufferOffset);
    // Serialize message field [region]
    bufferOffset = geometry_msgs.msg.Polygon.serialize(obj.region, buffer, bufferOffset);
    // Serialize message field [config_json_sting]
    bufferOffset = _serializer.string(obj.config_json_sting, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ModelDetectRequest
    let len;
    let data = new ModelDetectRequest(null);
    // Deserialize message field [map_name]
    data.map_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [model_id]
    data.model_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [region]
    data.region = geometry_msgs.msg.Polygon.deserialize(buffer, bufferOffset);
    // Deserialize message field [config_json_sting]
    data.config_json_sting = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.map_name.length;
    length += geometry_msgs.msg.Polygon.getMessageSize(object.region);
    length += object.config_json_sting.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/ModelDetectRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6df35febc63c3de04c83a2431fd79559';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string map_name
    int32 model_id
    geometry_msgs/Polygon region
    string config_json_sting
    
    ================================================================================
    MSG: geometry_msgs/Polygon
    #A specification of a polygon where the first and last points are assumed to be connected
    Point32[] points
    
    ================================================================================
    MSG: geometry_msgs/Point32
    # This contains the position of a point in free space(with 32 bits of precision).
    # It is recommeded to use Point wherever possible instead of Point32.  
    # 
    # This recommendation is to promote interoperability.  
    #
    # This message is designed to take up less space when sending
    # lots of points at once, as in the case of a PointCloud.  
    
    float32 x
    float32 y
    float32 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ModelDetectRequest(null);
    if (msg.map_name !== undefined) {
      resolved.map_name = msg.map_name;
    }
    else {
      resolved.map_name = ''
    }

    if (msg.model_id !== undefined) {
      resolved.model_id = msg.model_id;
    }
    else {
      resolved.model_id = 0
    }

    if (msg.region !== undefined) {
      resolved.region = geometry_msgs.msg.Polygon.Resolve(msg.region)
    }
    else {
      resolved.region = new geometry_msgs.msg.Polygon()
    }

    if (msg.config_json_sting !== undefined) {
      resolved.config_json_sting = msg.config_json_sting;
    }
    else {
      resolved.config_json_sting = ''
    }

    return resolved;
    }
};

class ModelDetectResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.model_width = null;
      this.model_height = null;
      this.results = null;
      this.config_json_string = null;
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('model_width')) {
        this.model_width = initObj.model_width
      }
      else {
        this.model_width = 0.0;
      }
      if (initObj.hasOwnProperty('model_height')) {
        this.model_height = initObj.model_height
      }
      else {
        this.model_height = 0.0;
      }
      if (initObj.hasOwnProperty('results')) {
        this.results = initObj.results
      }
      else {
        this.results = [];
      }
      if (initObj.hasOwnProperty('config_json_string')) {
        this.config_json_string = initObj.config_json_string
      }
      else {
        this.config_json_string = '';
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ModelDetectResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [model_width]
    bufferOffset = _serializer.float32(obj.model_width, buffer, bufferOffset);
    // Serialize message field [model_height]
    bufferOffset = _serializer.float32(obj.model_height, buffer, bufferOffset);
    // Serialize message field [results]
    // Serialize the length for message field [results]
    bufferOffset = _serializer.uint32(obj.results.length, buffer, bufferOffset);
    obj.results.forEach((val) => {
      bufferOffset = ModelDtectorResult.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [config_json_string]
    bufferOffset = _serializer.string(obj.config_json_string, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ModelDetectResponse
    let len;
    let data = new ModelDetectResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [model_width]
    data.model_width = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [model_height]
    data.model_height = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [results]
    // Deserialize array length for message field [results]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.results = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.results[i] = ModelDtectorResult.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [config_json_string]
    data.config_json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 60 * object.results.length;
    length += object.config_json_string.length;
    length += object.message.length;
    return length + 21;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/ModelDetectResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f8733e5262c699da4950870c43050b27';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    float32 model_width
    float32 model_height
    ModelDtectorResult[] results
    string config_json_string
    string message
    
    
    
    ================================================================================
    MSG: emma_tools_msgs/ModelDtectorResult
    float32 best_value
    geometry_msgs/Pose model2map
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ModelDetectResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.model_width !== undefined) {
      resolved.model_width = msg.model_width;
    }
    else {
      resolved.model_width = 0.0
    }

    if (msg.model_height !== undefined) {
      resolved.model_height = msg.model_height;
    }
    else {
      resolved.model_height = 0.0
    }

    if (msg.results !== undefined) {
      resolved.results = new Array(msg.results.length);
      for (let i = 0; i < resolved.results.length; ++i) {
        resolved.results[i] = ModelDtectorResult.Resolve(msg.results[i]);
      }
    }
    else {
      resolved.results = []
    }

    if (msg.config_json_string !== undefined) {
      resolved.config_json_string = msg.config_json_string;
    }
    else {
      resolved.config_json_string = ''
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: ModelDetectRequest,
  Response: ModelDetectResponse,
  md5sum() { return 'e4ed67eae0bd312a47c05759145725e1'; },
  datatype() { return 'emma_tools_msgs/ModelDetect'; }
};
