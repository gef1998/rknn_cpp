// Auto-generated. Do not edit!

// (in-package poslvx.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Status {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.gps_week = null;
      this.gps_time = null;
      this.imu_alignment_status = null;
      this.gnss_status = null;
    }
    else {
      if (initObj.hasOwnProperty('gps_week')) {
        this.gps_week = initObj.gps_week
      }
      else {
        this.gps_week = 0;
      }
      if (initObj.hasOwnProperty('gps_time')) {
        this.gps_time = initObj.gps_time
      }
      else {
        this.gps_time = 0;
      }
      if (initObj.hasOwnProperty('imu_alignment_status')) {
        this.imu_alignment_status = initObj.imu_alignment_status
      }
      else {
        this.imu_alignment_status = 0;
      }
      if (initObj.hasOwnProperty('gnss_status')) {
        this.gnss_status = initObj.gnss_status
      }
      else {
        this.gnss_status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Status
    // Serialize message field [gps_week]
    bufferOffset = _serializer.int16(obj.gps_week, buffer, bufferOffset);
    // Serialize message field [gps_time]
    bufferOffset = _serializer.uint32(obj.gps_time, buffer, bufferOffset);
    // Serialize message field [imu_alignment_status]
    bufferOffset = _serializer.uint8(obj.imu_alignment_status, buffer, bufferOffset);
    // Serialize message field [gnss_status]
    bufferOffset = _serializer.uint8(obj.gnss_status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Status
    let len;
    let data = new Status(null);
    // Deserialize message field [gps_week]
    data.gps_week = _deserializer.int16(buffer, bufferOffset);
    // Deserialize message field [gps_time]
    data.gps_time = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [imu_alignment_status]
    data.imu_alignment_status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [gnss_status]
    data.gnss_status = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'poslvx/Status';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7c7d925ea7115def6ec9bd3b7ababa4e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    int16 gps_week
    uint32 gps_time
    uint8 imu_alignment_status
    uint8 gnss_status
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Status(null);
    if (msg.gps_week !== undefined) {
      resolved.gps_week = msg.gps_week;
    }
    else {
      resolved.gps_week = 0
    }

    if (msg.gps_time !== undefined) {
      resolved.gps_time = msg.gps_time;
    }
    else {
      resolved.gps_time = 0
    }

    if (msg.imu_alignment_status !== undefined) {
      resolved.imu_alignment_status = msg.imu_alignment_status;
    }
    else {
      resolved.imu_alignment_status = 0
    }

    if (msg.gnss_status !== undefined) {
      resolved.gnss_status = msg.gnss_status;
    }
    else {
      resolved.gnss_status = 0
    }

    return resolved;
    }
};

module.exports = Status;
