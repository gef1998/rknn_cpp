
"use strict";

let Apriltag = require('./Apriltag.js');
let Apriltags = require('./Apriltags.js');

module.exports = {
  Apriltag: Apriltag,
  Apriltags: Apriltags,
};
