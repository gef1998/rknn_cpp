// Auto-generated. Do not edit!

// (in-package vtr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SearchNeighbourRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.depth = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('depth')) {
        this.depth = initObj.depth
      }
      else {
        this.depth = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SearchNeighbourRequest
    // Serialize message field [id]
    bufferOffset = _serializer.int64(obj.id, buffer, bufferOffset);
    // Serialize message field [depth]
    bufferOffset = _serializer.int32(obj.depth, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SearchNeighbourRequest
    let len;
    let data = new SearchNeighbourRequest(null);
    // Deserialize message field [id]
    data.id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [depth]
    data.depth = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/SearchNeighbourRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f2c678d8111fe34a52cccb8589192195';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 id
    int32 depth
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SearchNeighbourRequest(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.depth !== undefined) {
      resolved.depth = msg.depth;
    }
    else {
      resolved.depth = 0
    }

    return resolved;
    }
};

class SearchNeighbourResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.neighbour_id = null;
    }
    else {
      if (initObj.hasOwnProperty('neighbour_id')) {
        this.neighbour_id = initObj.neighbour_id
      }
      else {
        this.neighbour_id = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SearchNeighbourResponse
    // Serialize message field [neighbour_id]
    bufferOffset = _arraySerializer.int64(obj.neighbour_id, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SearchNeighbourResponse
    let len;
    let data = new SearchNeighbourResponse(null);
    // Deserialize message field [neighbour_id]
    data.neighbour_id = _arrayDeserializer.int64(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 8 * object.neighbour_id.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/SearchNeighbourResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0cfd12d29dc6ad3ac257c146c7f38ac1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64[] neighbour_id
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SearchNeighbourResponse(null);
    if (msg.neighbour_id !== undefined) {
      resolved.neighbour_id = msg.neighbour_id;
    }
    else {
      resolved.neighbour_id = []
    }

    return resolved;
    }
};

module.exports = {
  Request: SearchNeighbourRequest,
  Response: SearchNeighbourResponse,
  md5sum() { return 'ea0180764ebf38bee0e9fa3aca8877e4'; },
  datatype() { return 'vtr_msgs/SearchNeighbour'; }
};
