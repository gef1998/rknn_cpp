// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetIDRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetIDRequest
    // Serialize message field [id]
    bufferOffset = _serializer.int32(obj.id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetIDRequest
    let len;
    let data = new SetIDRequest(null);
    // Deserialize message field [id]
    data.id = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/SetIDRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c5e4a7d59c68f74eabcec876a00216aa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetIDRequest(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    return resolved;
    }
};

class SetIDResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_msgs = null;
    }
    else {
      if (initObj.hasOwnProperty('error_msgs')) {
        this.error_msgs = initObj.error_msgs
      }
      else {
        this.error_msgs = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetIDResponse
    // Serialize message field [error_msgs]
    bufferOffset = _serializer.string(obj.error_msgs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetIDResponse
    let len;
    let data = new SetIDResponse(null);
    // Deserialize message field [error_msgs]
    data.error_msgs = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_msgs.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/SetIDResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '31076761bb7a15c7d145b393c8a56624';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_msgs
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetIDResponse(null);
    if (msg.error_msgs !== undefined) {
      resolved.error_msgs = msg.error_msgs;
    }
    else {
      resolved.error_msgs = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SetIDRequest,
  Response: SetIDResponse,
  md5sum() { return 'c259a5be22544fa757226673ccdb5242'; },
  datatype() { return 'emma_tools_msgs/SetID'; }
};
