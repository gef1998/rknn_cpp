// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class ModelDtectorResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.best_value = null;
      this.model2map = null;
    }
    else {
      if (initObj.hasOwnProperty('best_value')) {
        this.best_value = initObj.best_value
      }
      else {
        this.best_value = 0.0;
      }
      if (initObj.hasOwnProperty('model2map')) {
        this.model2map = initObj.model2map
      }
      else {
        this.model2map = new geometry_msgs.msg.Pose();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ModelDtectorResult
    // Serialize message field [best_value]
    bufferOffset = _serializer.float32(obj.best_value, buffer, bufferOffset);
    // Serialize message field [model2map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.model2map, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ModelDtectorResult
    let len;
    let data = new ModelDtectorResult(null);
    // Deserialize message field [best_value]
    data.best_value = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [model2map]
    data.model2map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 60;
  }

  static datatype() {
    // Returns string type for a message object
    return 'emma_tools_msgs/ModelDtectorResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6c6d45af1b9b76ce89b9769afbd00558';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 best_value
    geometry_msgs/Pose model2map
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ModelDtectorResult(null);
    if (msg.best_value !== undefined) {
      resolved.best_value = msg.best_value;
    }
    else {
      resolved.best_value = 0.0
    }

    if (msg.model2map !== undefined) {
      resolved.model2map = geometry_msgs.msg.Pose.Resolve(msg.model2map)
    }
    else {
      resolved.model2map = new geometry_msgs.msg.Pose()
    }

    return resolved;
    }
};

module.exports = ModelDtectorResult;
