// Auto-generated. Do not edit!

// (in-package visual_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Keypoint {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.xl = null;
      this.xr = null;
      this.yl = null;
      this.size = null;
      this.angle = null;
      this.response = null;
      this.octave = null;
      this.class_id = null;
    }
    else {
      if (initObj.hasOwnProperty('xl')) {
        this.xl = initObj.xl
      }
      else {
        this.xl = 0.0;
      }
      if (initObj.hasOwnProperty('xr')) {
        this.xr = initObj.xr
      }
      else {
        this.xr = 0.0;
      }
      if (initObj.hasOwnProperty('yl')) {
        this.yl = initObj.yl
      }
      else {
        this.yl = 0.0;
      }
      if (initObj.hasOwnProperty('size')) {
        this.size = initObj.size
      }
      else {
        this.size = 0.0;
      }
      if (initObj.hasOwnProperty('angle')) {
        this.angle = initObj.angle
      }
      else {
        this.angle = 0.0;
      }
      if (initObj.hasOwnProperty('response')) {
        this.response = initObj.response
      }
      else {
        this.response = 0.0;
      }
      if (initObj.hasOwnProperty('octave')) {
        this.octave = initObj.octave
      }
      else {
        this.octave = 0;
      }
      if (initObj.hasOwnProperty('class_id')) {
        this.class_id = initObj.class_id
      }
      else {
        this.class_id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Keypoint
    // Serialize message field [xl]
    bufferOffset = _serializer.float32(obj.xl, buffer, bufferOffset);
    // Serialize message field [xr]
    bufferOffset = _serializer.float32(obj.xr, buffer, bufferOffset);
    // Serialize message field [yl]
    bufferOffset = _serializer.float32(obj.yl, buffer, bufferOffset);
    // Serialize message field [size]
    bufferOffset = _serializer.float32(obj.size, buffer, bufferOffset);
    // Serialize message field [angle]
    bufferOffset = _serializer.float32(obj.angle, buffer, bufferOffset);
    // Serialize message field [response]
    bufferOffset = _serializer.float32(obj.response, buffer, bufferOffset);
    // Serialize message field [octave]
    bufferOffset = _serializer.int32(obj.octave, buffer, bufferOffset);
    // Serialize message field [class_id]
    bufferOffset = _serializer.int32(obj.class_id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Keypoint
    let len;
    let data = new Keypoint(null);
    // Deserialize message field [xl]
    data.xl = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [xr]
    data.xr = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [yl]
    data.yl = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [size]
    data.size = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [angle]
    data.angle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [response]
    data.response = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [octave]
    data.octave = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [class_id]
    data.class_id = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 32;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_msgs/Keypoint';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4071e967af42d47a019a49ee464fee9b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Copyright 2016 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    float32 xl
    float32 xr
    float32 yl
    float32 size
    float32 angle
    float32 response
    int32 octave
    int32 class_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Keypoint(null);
    if (msg.xl !== undefined) {
      resolved.xl = msg.xl;
    }
    else {
      resolved.xl = 0.0
    }

    if (msg.xr !== undefined) {
      resolved.xr = msg.xr;
    }
    else {
      resolved.xr = 0.0
    }

    if (msg.yl !== undefined) {
      resolved.yl = msg.yl;
    }
    else {
      resolved.yl = 0.0
    }

    if (msg.size !== undefined) {
      resolved.size = msg.size;
    }
    else {
      resolved.size = 0.0
    }

    if (msg.angle !== undefined) {
      resolved.angle = msg.angle;
    }
    else {
      resolved.angle = 0.0
    }

    if (msg.response !== undefined) {
      resolved.response = msg.response;
    }
    else {
      resolved.response = 0.0
    }

    if (msg.octave !== undefined) {
      resolved.octave = msg.octave;
    }
    else {
      resolved.octave = 0
    }

    if (msg.class_id !== undefined) {
      resolved.class_id = msg.class_id;
    }
    else {
      resolved.class_id = 0
    }

    return resolved;
    }
};

module.exports = Keypoint;
