// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class FrontEndNodeSwitchRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.commandType = null;
      this.origin_map_name = null;
      this.mapName = null;
      this.marks_enabled = null;
      this.odom_disabled = null;
      this.imu_disabled = null;
      this.mutilLaser_enabled = null;
      this.lasermark_enabled = null;
      this.tag_codec_type = null;
      this.pose = null;
    }
    else {
      if (initObj.hasOwnProperty('commandType')) {
        this.commandType = initObj.commandType
      }
      else {
        this.commandType = 0;
      }
      if (initObj.hasOwnProperty('origin_map_name')) {
        this.origin_map_name = initObj.origin_map_name
      }
      else {
        this.origin_map_name = '';
      }
      if (initObj.hasOwnProperty('mapName')) {
        this.mapName = initObj.mapName
      }
      else {
        this.mapName = '';
      }
      if (initObj.hasOwnProperty('marks_enabled')) {
        this.marks_enabled = initObj.marks_enabled
      }
      else {
        this.marks_enabled = false;
      }
      if (initObj.hasOwnProperty('odom_disabled')) {
        this.odom_disabled = initObj.odom_disabled
      }
      else {
        this.odom_disabled = false;
      }
      if (initObj.hasOwnProperty('imu_disabled')) {
        this.imu_disabled = initObj.imu_disabled
      }
      else {
        this.imu_disabled = false;
      }
      if (initObj.hasOwnProperty('mutilLaser_enabled')) {
        this.mutilLaser_enabled = initObj.mutilLaser_enabled
      }
      else {
        this.mutilLaser_enabled = false;
      }
      if (initObj.hasOwnProperty('lasermark_enabled')) {
        this.lasermark_enabled = initObj.lasermark_enabled
      }
      else {
        this.lasermark_enabled = false;
      }
      if (initObj.hasOwnProperty('tag_codec_type')) {
        this.tag_codec_type = initObj.tag_codec_type
      }
      else {
        this.tag_codec_type = 0;
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndNodeSwitchRequest
    // Serialize message field [commandType]
    bufferOffset = _serializer.uint8(obj.commandType, buffer, bufferOffset);
    // Serialize message field [origin_map_name]
    bufferOffset = _serializer.string(obj.origin_map_name, buffer, bufferOffset);
    // Serialize message field [mapName]
    bufferOffset = _serializer.string(obj.mapName, buffer, bufferOffset);
    // Serialize message field [marks_enabled]
    bufferOffset = _serializer.bool(obj.marks_enabled, buffer, bufferOffset);
    // Serialize message field [odom_disabled]
    bufferOffset = _serializer.bool(obj.odom_disabled, buffer, bufferOffset);
    // Serialize message field [imu_disabled]
    bufferOffset = _serializer.bool(obj.imu_disabled, buffer, bufferOffset);
    // Serialize message field [mutilLaser_enabled]
    bufferOffset = _serializer.bool(obj.mutilLaser_enabled, buffer, bufferOffset);
    // Serialize message field [lasermark_enabled]
    bufferOffset = _serializer.bool(obj.lasermark_enabled, buffer, bufferOffset);
    // Serialize message field [tag_codec_type]
    bufferOffset = _serializer.int32(obj.tag_codec_type, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndNodeSwitchRequest
    let len;
    let data = new FrontEndNodeSwitchRequest(null);
    // Deserialize message field [commandType]
    data.commandType = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [origin_map_name]
    data.origin_map_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [mapName]
    data.mapName = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [marks_enabled]
    data.marks_enabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [odom_disabled]
    data.odom_disabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [imu_disabled]
    data.imu_disabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [mutilLaser_enabled]
    data.mutilLaser_enabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [lasermark_enabled]
    data.lasermark_enabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [tag_codec_type]
    data.tag_codec_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.origin_map_name.length;
    length += object.mapName.length;
    return length + 74;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/FrontEndNodeSwitchRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fd45810d91868ef7d134744538d63b72';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    uint8 commandType
    string origin_map_name
    string  mapName
    bool    marks_enabled
    bool odom_disabled
    bool imu_disabled
    bool mutilLaser_enabled
    bool lasermark_enabled
    
    int32 tag_codec_type
    int32 TAG36H11 = 0
    int32 TAG36H10 = 1
    
    geometry_msgs/Pose pose
    
    uint8 START_MAPPING = 0
    uint8 STOP_MAPPING = 1
    uint8 START_LOCALIZATION = 2
    uint8 STOP_LOCALIZATION = 3
    uint8 START_PATCH_MAPPING = 4
    uint8 STOP_PATCH_MAPPING = 5
    uint8 ABANDON_PATCH_MAPPING = 6
    uint8 PREPARE_PATCH_MAPPING = 7
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndNodeSwitchRequest(null);
    if (msg.commandType !== undefined) {
      resolved.commandType = msg.commandType;
    }
    else {
      resolved.commandType = 0
    }

    if (msg.origin_map_name !== undefined) {
      resolved.origin_map_name = msg.origin_map_name;
    }
    else {
      resolved.origin_map_name = ''
    }

    if (msg.mapName !== undefined) {
      resolved.mapName = msg.mapName;
    }
    else {
      resolved.mapName = ''
    }

    if (msg.marks_enabled !== undefined) {
      resolved.marks_enabled = msg.marks_enabled;
    }
    else {
      resolved.marks_enabled = false
    }

    if (msg.odom_disabled !== undefined) {
      resolved.odom_disabled = msg.odom_disabled;
    }
    else {
      resolved.odom_disabled = false
    }

    if (msg.imu_disabled !== undefined) {
      resolved.imu_disabled = msg.imu_disabled;
    }
    else {
      resolved.imu_disabled = false
    }

    if (msg.mutilLaser_enabled !== undefined) {
      resolved.mutilLaser_enabled = msg.mutilLaser_enabled;
    }
    else {
      resolved.mutilLaser_enabled = false
    }

    if (msg.lasermark_enabled !== undefined) {
      resolved.lasermark_enabled = msg.lasermark_enabled;
    }
    else {
      resolved.lasermark_enabled = false
    }

    if (msg.tag_codec_type !== undefined) {
      resolved.tag_codec_type = msg.tag_codec_type;
    }
    else {
      resolved.tag_codec_type = 0
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    return resolved;
    }
};

// Constants for message
FrontEndNodeSwitchRequest.Constants = {
  TAG36H11: 0,
  TAG36H10: 1,
  START_MAPPING: 0,
  STOP_MAPPING: 1,
  START_LOCALIZATION: 2,
  STOP_LOCALIZATION: 3,
  START_PATCH_MAPPING: 4,
  STOP_PATCH_MAPPING: 5,
  ABANDON_PATCH_MAPPING: 6,
  PREPARE_PATCH_MAPPING: 7,
}

class FrontEndNodeSwitchResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndNodeSwitchResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndNodeSwitchResponse
    let len;
    let data = new FrontEndNodeSwitchResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.error_message.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/FrontEndNodeSwitchResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2eb3fecdbdc9677fb5036c2f18283ac8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndNodeSwitchResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: FrontEndNodeSwitchRequest,
  Response: FrontEndNodeSwitchResponse,
  md5sum() { return '9aade7b1e777dae9b2302aa60e3b4886'; },
  datatype() { return 'cartographer_ros_msgs/FrontEndNodeSwitch'; }
};
