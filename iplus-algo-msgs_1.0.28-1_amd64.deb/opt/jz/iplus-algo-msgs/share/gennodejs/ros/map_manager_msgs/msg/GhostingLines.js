// Auto-generated. Do not edit!

// (in-package map_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LinePoints2d = require('./LinePoints2d.js');

//-----------------------------------------------------------

class GhostingLines {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.firstLine = null;
      this.secondLine = null;
    }
    else {
      if (initObj.hasOwnProperty('firstLine')) {
        this.firstLine = initObj.firstLine
      }
      else {
        this.firstLine = new LinePoints2d();
      }
      if (initObj.hasOwnProperty('secondLine')) {
        this.secondLine = initObj.secondLine
      }
      else {
        this.secondLine = new LinePoints2d();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GhostingLines
    // Serialize message field [firstLine]
    bufferOffset = LinePoints2d.serialize(obj.firstLine, buffer, bufferOffset);
    // Serialize message field [secondLine]
    bufferOffset = LinePoints2d.serialize(obj.secondLine, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GhostingLines
    let len;
    let data = new GhostingLines(null);
    // Deserialize message field [firstLine]
    data.firstLine = LinePoints2d.deserialize(buffer, bufferOffset);
    // Deserialize message field [secondLine]
    data.secondLine = LinePoints2d.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 64;
  }

  static datatype() {
    // Returns string type for a message object
    return 'map_manager_msgs/GhostingLines';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f830c4afee5e190aef687db47183fb82';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    map_manager_msgs/LinePoints2d firstLine
    map_manager_msgs/LinePoints2d secondLine
    ================================================================================
    MSG: map_manager_msgs/LinePoints2d
    map_manager_msgs/Point2d startPoint
    map_manager_msgs/Point2d endPoint
    ================================================================================
    MSG: map_manager_msgs/Point2d
    float64 x
    float64 y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GhostingLines(null);
    if (msg.firstLine !== undefined) {
      resolved.firstLine = LinePoints2d.Resolve(msg.firstLine)
    }
    else {
      resolved.firstLine = new LinePoints2d()
    }

    if (msg.secondLine !== undefined) {
      resolved.secondLine = LinePoints2d.Resolve(msg.secondLine)
    }
    else {
      resolved.secondLine = new LinePoints2d()
    }

    return resolved;
    }
};

module.exports = GhostingLines;
