// Auto-generated. Do not edit!

// (in-package sensors_check_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let RigidBody = require('./RigidBody.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class RigidBodys {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.rigid_bodys = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('rigid_bodys')) {
        this.rigid_bodys = initObj.rigid_bodys
      }
      else {
        this.rigid_bodys = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RigidBodys
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [rigid_bodys]
    // Serialize the length for message field [rigid_bodys]
    bufferOffset = _serializer.uint32(obj.rigid_bodys.length, buffer, bufferOffset);
    obj.rigid_bodys.forEach((val) => {
      bufferOffset = RigidBody.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RigidBodys
    let len;
    let data = new RigidBodys(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [rigid_bodys]
    // Deserialize array length for message field [rigid_bodys]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.rigid_bodys = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.rigid_bodys[i] = RigidBody.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.rigid_bodys.forEach((val) => {
      length += RigidBody.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sensors_check_msgs/RigidBodys';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '20d29bc70aaf755cf9267265fc79d7e9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    sensors_check_msgs/RigidBody[] rigid_bodys
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: sensors_check_msgs/RigidBody
    std_msgs/Header header
    int32 frame_id
    int32 body_id
    string body_name
    geometry_msgs/PoseStamped pose
    sensors_check_msgs/Marker[] markers
    
    float32 mean_marker_error
    bool tracking_valid
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensors_check_msgs/Marker
    std_msgs/Header header
    int32 id
    float32[3] pose
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RigidBodys(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.rigid_bodys !== undefined) {
      resolved.rigid_bodys = new Array(msg.rigid_bodys.length);
      for (let i = 0; i < resolved.rigid_bodys.length; ++i) {
        resolved.rigid_bodys[i] = RigidBody.Resolve(msg.rigid_bodys[i]);
      }
    }
    else {
      resolved.rigid_bodys = []
    }

    return resolved;
    }
};

module.exports = RigidBodys;
