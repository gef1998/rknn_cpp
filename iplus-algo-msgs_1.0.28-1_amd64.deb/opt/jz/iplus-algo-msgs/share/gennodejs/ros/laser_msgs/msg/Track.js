// Auto-generated. Do not edit!

// (in-package laser_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class Track {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.position = null;
      this.velocity = null;
      this.x_size = null;
      this.y_size = null;
      this.avg_intensity = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('position')) {
        this.position = initObj.position
      }
      else {
        this.position = new geometry_msgs.msg.Point();
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = new geometry_msgs.msg.Point();
      }
      if (initObj.hasOwnProperty('x_size')) {
        this.x_size = initObj.x_size
      }
      else {
        this.x_size = 0.0;
      }
      if (initObj.hasOwnProperty('y_size')) {
        this.y_size = initObj.y_size
      }
      else {
        this.y_size = 0.0;
      }
      if (initObj.hasOwnProperty('avg_intensity')) {
        this.avg_intensity = initObj.avg_intensity
      }
      else {
        this.avg_intensity = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Track
    // Serialize message field [id]
    bufferOffset = _serializer.int64(obj.id, buffer, bufferOffset);
    // Serialize message field [position]
    bufferOffset = geometry_msgs.msg.Point.serialize(obj.position, buffer, bufferOffset);
    // Serialize message field [velocity]
    bufferOffset = geometry_msgs.msg.Point.serialize(obj.velocity, buffer, bufferOffset);
    // Serialize message field [x_size]
    bufferOffset = _serializer.float32(obj.x_size, buffer, bufferOffset);
    // Serialize message field [y_size]
    bufferOffset = _serializer.float32(obj.y_size, buffer, bufferOffset);
    // Serialize message field [avg_intensity]
    bufferOffset = _serializer.float32(obj.avg_intensity, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Track
    let len;
    let data = new Track(null);
    // Deserialize message field [id]
    data.id = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [position]
    data.position = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [velocity]
    data.velocity = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [x_size]
    data.x_size = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [y_size]
    data.y_size = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [avg_intensity]
    data.avg_intensity = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 68;
  }

  static datatype() {
    // Returns string type for a message object
    return 'laser_msgs/Track';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b264402bfb0be9926c0a4c5e3411da12';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int64 id
    geometry_msgs/Point position
    geometry_msgs/Point velocity
    float32 x_size
    float32 y_size
    float32 avg_intensity
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Track(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.position !== undefined) {
      resolved.position = geometry_msgs.msg.Point.Resolve(msg.position)
    }
    else {
      resolved.position = new geometry_msgs.msg.Point()
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = geometry_msgs.msg.Point.Resolve(msg.velocity)
    }
    else {
      resolved.velocity = new geometry_msgs.msg.Point()
    }

    if (msg.x_size !== undefined) {
      resolved.x_size = msg.x_size;
    }
    else {
      resolved.x_size = 0.0
    }

    if (msg.y_size !== undefined) {
      resolved.y_size = msg.y_size;
    }
    else {
      resolved.y_size = 0.0
    }

    if (msg.avg_intensity !== undefined) {
      resolved.avg_intensity = msg.avg_intensity;
    }
    else {
      resolved.avg_intensity = 0.0
    }

    return resolved;
    }
};

module.exports = Track;
