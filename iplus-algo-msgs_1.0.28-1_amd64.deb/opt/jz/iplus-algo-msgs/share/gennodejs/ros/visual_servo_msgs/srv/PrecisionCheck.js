// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class PrecisionCheckRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.mode = null;
      this.truth_sensor = null;
      this.camera_type = null;
      this.tag_type = null;
      this.template_id = null;
      this.templete_path = null;
      this.minCorner = null;
      this.maxCorner = null;
      this.angleThreashOnDegree = null;
      this.baseInWorld = null;
      this.baseInTest = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = 0;
      }
      if (initObj.hasOwnProperty('truth_sensor')) {
        this.truth_sensor = initObj.truth_sensor
      }
      else {
        this.truth_sensor = 0;
      }
      if (initObj.hasOwnProperty('camera_type')) {
        this.camera_type = initObj.camera_type
      }
      else {
        this.camera_type = 0;
      }
      if (initObj.hasOwnProperty('tag_type')) {
        this.tag_type = initObj.tag_type
      }
      else {
        this.tag_type = 0;
      }
      if (initObj.hasOwnProperty('template_id')) {
        this.template_id = initObj.template_id
      }
      else {
        this.template_id = 0;
      }
      if (initObj.hasOwnProperty('templete_path')) {
        this.templete_path = initObj.templete_path
      }
      else {
        this.templete_path = '';
      }
      if (initObj.hasOwnProperty('minCorner')) {
        this.minCorner = initObj.minCorner
      }
      else {
        this.minCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('maxCorner')) {
        this.maxCorner = initObj.maxCorner
      }
      else {
        this.maxCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('angleThreashOnDegree')) {
        this.angleThreashOnDegree = initObj.angleThreashOnDegree
      }
      else {
        this.angleThreashOnDegree = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('baseInWorld')) {
        this.baseInWorld = initObj.baseInWorld
      }
      else {
        this.baseInWorld = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('baseInTest')) {
        this.baseInTest = initObj.baseInTest
      }
      else {
        this.baseInTest = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PrecisionCheckRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [mode]
    bufferOffset = _serializer.uint8(obj.mode, buffer, bufferOffset);
    // Serialize message field [truth_sensor]
    bufferOffset = _serializer.uint8(obj.truth_sensor, buffer, bufferOffset);
    // Serialize message field [camera_type]
    bufferOffset = _serializer.uint8(obj.camera_type, buffer, bufferOffset);
    // Serialize message field [tag_type]
    bufferOffset = _serializer.uint8(obj.tag_type, buffer, bufferOffset);
    // Serialize message field [template_id]
    bufferOffset = _serializer.int32(obj.template_id, buffer, bufferOffset);
    // Serialize message field [templete_path]
    bufferOffset = _serializer.string(obj.templete_path, buffer, bufferOffset);
    // Check that the constant length array field [minCorner] has the right length
    if (obj.minCorner.length !== 2) {
      throw new Error('Unable to serialize array field minCorner - length must be 2')
    }
    // Serialize message field [minCorner]
    bufferOffset = _arraySerializer.float32(obj.minCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [maxCorner] has the right length
    if (obj.maxCorner.length !== 2) {
      throw new Error('Unable to serialize array field maxCorner - length must be 2')
    }
    // Serialize message field [maxCorner]
    bufferOffset = _arraySerializer.float32(obj.maxCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [angleThreashOnDegree] has the right length
    if (obj.angleThreashOnDegree.length !== 2) {
      throw new Error('Unable to serialize array field angleThreashOnDegree - length must be 2')
    }
    // Serialize message field [angleThreashOnDegree]
    bufferOffset = _arraySerializer.float32(obj.angleThreashOnDegree, buffer, bufferOffset, 2);
    // Serialize message field [baseInWorld]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.baseInWorld, buffer, bufferOffset);
    // Serialize message field [baseInTest]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.baseInTest, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PrecisionCheckRequest
    let len;
    let data = new PrecisionCheckRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [mode]
    data.mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [truth_sensor]
    data.truth_sensor = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [camera_type]
    data.camera_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [tag_type]
    data.tag_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [template_id]
    data.template_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [templete_path]
    data.templete_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [minCorner]
    data.minCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [maxCorner]
    data.maxCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [angleThreashOnDegree]
    data.angleThreashOnDegree = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [baseInWorld]
    data.baseInWorld = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [baseInTest]
    data.baseInTest = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.templete_path.length;
    length += object.json_string.length;
    return length + 88;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/PrecisionCheckRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1db8bd9cc08acf7b5e3a1f4dca06cdd2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    uint8 mode
    uint8 TEACHING_BASE2MAP = 0
    uint8 TEACHING_BASE2TEMPLATE = 1
    uint8 TESTING_BASE2MAP = 10
    uint8 TESTING_BASE2TEMPLATE = 11
    
    uint8 truth_sensor
    uint8 CAMERA_SENSOR = 0
    uint8 OPTITRACK_SENSOR = 1
    
    
    uint8 camera_type
    uint8 UP_CAMERA = 0
    uint8 DOWN_CAMERA = 1
    uint8 tag_type
    uint8 SHELF_TAG = 0
    uint8 NORMAL_TAG = 1
    uint8 LANDMARK_TAG = 2
    
    
    
    
    
    int32 template_id
    string templete_path
    float32[2] minCorner
    float32[2] maxCorner
    float32[2] angleThreashOnDegree
    
    
    geometry_msgs/Pose2D baseInWorld
    geometry_msgs/Pose2D baseInTest
    string json_string
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PrecisionCheckRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.mode !== undefined) {
      resolved.mode = msg.mode;
    }
    else {
      resolved.mode = 0
    }

    if (msg.truth_sensor !== undefined) {
      resolved.truth_sensor = msg.truth_sensor;
    }
    else {
      resolved.truth_sensor = 0
    }

    if (msg.camera_type !== undefined) {
      resolved.camera_type = msg.camera_type;
    }
    else {
      resolved.camera_type = 0
    }

    if (msg.tag_type !== undefined) {
      resolved.tag_type = msg.tag_type;
    }
    else {
      resolved.tag_type = 0
    }

    if (msg.template_id !== undefined) {
      resolved.template_id = msg.template_id;
    }
    else {
      resolved.template_id = 0
    }

    if (msg.templete_path !== undefined) {
      resolved.templete_path = msg.templete_path;
    }
    else {
      resolved.templete_path = ''
    }

    if (msg.minCorner !== undefined) {
      resolved.minCorner = msg.minCorner;
    }
    else {
      resolved.minCorner = new Array(2).fill(0)
    }

    if (msg.maxCorner !== undefined) {
      resolved.maxCorner = msg.maxCorner;
    }
    else {
      resolved.maxCorner = new Array(2).fill(0)
    }

    if (msg.angleThreashOnDegree !== undefined) {
      resolved.angleThreashOnDegree = msg.angleThreashOnDegree;
    }
    else {
      resolved.angleThreashOnDegree = new Array(2).fill(0)
    }

    if (msg.baseInWorld !== undefined) {
      resolved.baseInWorld = geometry_msgs.msg.Pose2D.Resolve(msg.baseInWorld)
    }
    else {
      resolved.baseInWorld = new geometry_msgs.msg.Pose2D()
    }

    if (msg.baseInTest !== undefined) {
      resolved.baseInTest = geometry_msgs.msg.Pose2D.Resolve(msg.baseInTest)
    }
    else {
      resolved.baseInTest = new geometry_msgs.msg.Pose2D()
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

// Constants for message
PrecisionCheckRequest.Constants = {
  TEACHING_BASE2MAP: 0,
  TEACHING_BASE2TEMPLATE: 1,
  TESTING_BASE2MAP: 10,
  TESTING_BASE2TEMPLATE: 11,
  CAMERA_SENSOR: 0,
  OPTITRACK_SENSOR: 1,
  UP_CAMERA: 0,
  DOWN_CAMERA: 1,
  SHELF_TAG: 0,
  NORMAL_TAG: 1,
  LANDMARK_TAG: 2,
}

class PrecisionCheckResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.baseInWorld = null;
      this.baseInTest = null;
      this.error_test = null;
      this.error_world = null;
      this.error = null;
      this.error_message = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('baseInWorld')) {
        this.baseInWorld = initObj.baseInWorld
      }
      else {
        this.baseInWorld = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('baseInTest')) {
        this.baseInTest = initObj.baseInTest
      }
      else {
        this.baseInTest = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('error_test')) {
        this.error_test = initObj.error_test
      }
      else {
        this.error_test = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('error_world')) {
        this.error_world = initObj.error_world
      }
      else {
        this.error_world = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('error')) {
        this.error = initObj.error
      }
      else {
        this.error = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PrecisionCheckResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [baseInWorld]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.baseInWorld, buffer, bufferOffset);
    // Serialize message field [baseInTest]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.baseInTest, buffer, bufferOffset);
    // Check that the constant length array field [error_test] has the right length
    if (obj.error_test.length !== 3) {
      throw new Error('Unable to serialize array field error_test - length must be 3')
    }
    // Serialize message field [error_test]
    bufferOffset = _arraySerializer.float32(obj.error_test, buffer, bufferOffset, 3);
    // Check that the constant length array field [error_world] has the right length
    if (obj.error_world.length !== 3) {
      throw new Error('Unable to serialize array field error_world - length must be 3')
    }
    // Serialize message field [error_world]
    bufferOffset = _arraySerializer.float32(obj.error_world, buffer, bufferOffset, 3);
    // Check that the constant length array field [error] has the right length
    if (obj.error.length !== 3) {
      throw new Error('Unable to serialize array field error - length must be 3')
    }
    // Serialize message field [error]
    bufferOffset = _arraySerializer.float32(obj.error, buffer, bufferOffset, 3);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PrecisionCheckResponse
    let len;
    let data = new PrecisionCheckResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [baseInWorld]
    data.baseInWorld = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [baseInTest]
    data.baseInTest = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_test]
    data.error_test = _arrayDeserializer.float32(buffer, bufferOffset, 3)
    // Deserialize message field [error_world]
    data.error_world = _arrayDeserializer.float32(buffer, bufferOffset, 3)
    // Deserialize message field [error]
    data.error = _arrayDeserializer.float32(buffer, bufferOffset, 3)
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.error_message.length;
    length += object.json_string.length;
    return length + 92;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/PrecisionCheckResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'eb14209d94c3031da499762b4ece22bc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    geometry_msgs/Pose2D baseInWorld
    geometry_msgs/Pose2D baseInTest
    
    float32[3] error_test
    float32[3] error_world
    float32[3] error
    string error_message
    string json_string
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PrecisionCheckResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.baseInWorld !== undefined) {
      resolved.baseInWorld = geometry_msgs.msg.Pose2D.Resolve(msg.baseInWorld)
    }
    else {
      resolved.baseInWorld = new geometry_msgs.msg.Pose2D()
    }

    if (msg.baseInTest !== undefined) {
      resolved.baseInTest = geometry_msgs.msg.Pose2D.Resolve(msg.baseInTest)
    }
    else {
      resolved.baseInTest = new geometry_msgs.msg.Pose2D()
    }

    if (msg.error_test !== undefined) {
      resolved.error_test = msg.error_test;
    }
    else {
      resolved.error_test = new Array(3).fill(0)
    }

    if (msg.error_world !== undefined) {
      resolved.error_world = msg.error_world;
    }
    else {
      resolved.error_world = new Array(3).fill(0)
    }

    if (msg.error !== undefined) {
      resolved.error = msg.error;
    }
    else {
      resolved.error = new Array(3).fill(0)
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: PrecisionCheckRequest,
  Response: PrecisionCheckResponse,
  md5sum() { return 'a2688a93c980a02de3f7404d904bdd18'; },
  datatype() { return 'visual_servo_msgs/PrecisionCheck'; }
};
