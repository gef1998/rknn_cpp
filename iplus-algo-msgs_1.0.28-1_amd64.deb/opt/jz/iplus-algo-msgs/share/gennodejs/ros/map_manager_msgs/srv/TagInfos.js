// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let TagMapInfo = require('../msg/TagMapInfo.js');

//-----------------------------------------------------------

class TagInfosRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tag_map_path = null;
    }
    else {
      if (initObj.hasOwnProperty('tag_map_path')) {
        this.tag_map_path = initObj.tag_map_path
      }
      else {
        this.tag_map_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TagInfosRequest
    // Serialize message field [tag_map_path]
    bufferOffset = _serializer.string(obj.tag_map_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TagInfosRequest
    let len;
    let data = new TagInfosRequest(null);
    // Deserialize message field [tag_map_path]
    data.tag_map_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.tag_map_path.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/TagInfosRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b8734bf2df1e2ea5893c8de45308787b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string tag_map_path
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TagInfosRequest(null);
    if (msg.tag_map_path !== undefined) {
      resolved.tag_map_path = msg.tag_map_path;
    }
    else {
      resolved.tag_map_path = ''
    }

    return resolved;
    }
};

class TagInfosResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.tags = null;
      this.error_msgs = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('tags')) {
        this.tags = initObj.tags
      }
      else {
        this.tags = [];
      }
      if (initObj.hasOwnProperty('error_msgs')) {
        this.error_msgs = initObj.error_msgs
      }
      else {
        this.error_msgs = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TagInfosResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [tags]
    // Serialize the length for message field [tags]
    bufferOffset = _serializer.uint32(obj.tags.length, buffer, bufferOffset);
    obj.tags.forEach((val) => {
      bufferOffset = TagMapInfo.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [error_msgs]
    bufferOffset = _serializer.string(obj.error_msgs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TagInfosResponse
    let len;
    let data = new TagInfosResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [tags]
    // Deserialize array length for message field [tags]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tags = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tags[i] = TagMapInfo.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [error_msgs]
    data.error_msgs = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.tags.forEach((val) => {
      length += TagMapInfo.getMessageSize(val);
    });
    length += object.error_msgs.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/TagInfosResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b5e8cb52e46b807fe9c31b035f1c5cd8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    map_manager_msgs/TagMapInfo[] tags
    string error_msgs
    
    
    ================================================================================
    MSG: map_manager_msgs/TagMapInfo
    int32 tag_id
    int32 submap_id
    geometry_msgs/Pose pose
    geometry_msgs/Pose tag_pose_in_laser
    int32[] neighbors_id
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TagInfosResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.tags !== undefined) {
      resolved.tags = new Array(msg.tags.length);
      for (let i = 0; i < resolved.tags.length; ++i) {
        resolved.tags[i] = TagMapInfo.Resolve(msg.tags[i]);
      }
    }
    else {
      resolved.tags = []
    }

    if (msg.error_msgs !== undefined) {
      resolved.error_msgs = msg.error_msgs;
    }
    else {
      resolved.error_msgs = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: TagInfosRequest,
  Response: TagInfosResponse,
  md5sum() { return 'f1f0acbe63464c251e02250ebfa395fd'; },
  datatype() { return 'map_manager_msgs/TagInfos'; }
};
