
"use strict";

let IgnoreRegion = require('./IgnoreRegion.js')
let RegionPolys = require('./RegionPolys.js')

module.exports = {
  IgnoreRegion: IgnoreRegion,
  RegionPolys: RegionPolys,
};
