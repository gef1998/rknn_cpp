// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class Model3DGuardRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.mode = null;
      this.type = null;
      this.model_name = null;
      this.sensor_topic = null;
      this.x_length = null;
      this.y_length = null;
      this.z_length = null;
      this.ref_pose = null;
      this.json = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = 0;
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('model_name')) {
        this.model_name = initObj.model_name
      }
      else {
        this.model_name = '';
      }
      if (initObj.hasOwnProperty('sensor_topic')) {
        this.sensor_topic = initObj.sensor_topic
      }
      else {
        this.sensor_topic = '';
      }
      if (initObj.hasOwnProperty('x_length')) {
        this.x_length = initObj.x_length
      }
      else {
        this.x_length = 0.0;
      }
      if (initObj.hasOwnProperty('y_length')) {
        this.y_length = initObj.y_length
      }
      else {
        this.y_length = 0.0;
      }
      if (initObj.hasOwnProperty('z_length')) {
        this.z_length = initObj.z_length
      }
      else {
        this.z_length = 0.0;
      }
      if (initObj.hasOwnProperty('ref_pose')) {
        this.ref_pose = initObj.ref_pose
      }
      else {
        this.ref_pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('json')) {
        this.json = initObj.json
      }
      else {
        this.json = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Model3DGuardRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [mode]
    bufferOffset = _serializer.uint8(obj.mode, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [model_name]
    bufferOffset = _serializer.string(obj.model_name, buffer, bufferOffset);
    // Serialize message field [sensor_topic]
    bufferOffset = _serializer.string(obj.sensor_topic, buffer, bufferOffset);
    // Serialize message field [x_length]
    bufferOffset = _serializer.float32(obj.x_length, buffer, bufferOffset);
    // Serialize message field [y_length]
    bufferOffset = _serializer.float32(obj.y_length, buffer, bufferOffset);
    // Serialize message field [z_length]
    bufferOffset = _serializer.float32(obj.z_length, buffer, bufferOffset);
    // Serialize message field [ref_pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.ref_pose, buffer, bufferOffset);
    // Serialize message field [json]
    bufferOffset = _serializer.string(obj.json, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Model3DGuardRequest
    let len;
    let data = new Model3DGuardRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [mode]
    data.mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [model_name]
    data.model_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [sensor_topic]
    data.sensor_topic = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [x_length]
    data.x_length = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [y_length]
    data.y_length = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [z_length]
    data.z_length = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [ref_pose]
    data.ref_pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [json]
    data.json = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.model_name.length;
    length += object.sensor_topic.length;
    length += object.json.length;
    return length + 82;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/Model3DGuardRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '362e4b9088e17da5bafb624ed36ab82e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    uint8 mode
    uint8 MODE_START = 0
    uint8 MODE_STOP = 1
    uint8 type
    uint8 LOAD_AND_BASE_UNCONNECTED = 0
    uint8 LOAD_AND_BASE_CONNECTED = 1
    string model_name
    string sensor_topic
    float32 x_length
    float32 y_length
    float32 z_length
    geometry_msgs/Pose ref_pose
    string json
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Model3DGuardRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.mode !== undefined) {
      resolved.mode = msg.mode;
    }
    else {
      resolved.mode = 0
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.model_name !== undefined) {
      resolved.model_name = msg.model_name;
    }
    else {
      resolved.model_name = ''
    }

    if (msg.sensor_topic !== undefined) {
      resolved.sensor_topic = msg.sensor_topic;
    }
    else {
      resolved.sensor_topic = ''
    }

    if (msg.x_length !== undefined) {
      resolved.x_length = msg.x_length;
    }
    else {
      resolved.x_length = 0.0
    }

    if (msg.y_length !== undefined) {
      resolved.y_length = msg.y_length;
    }
    else {
      resolved.y_length = 0.0
    }

    if (msg.z_length !== undefined) {
      resolved.z_length = msg.z_length;
    }
    else {
      resolved.z_length = 0.0
    }

    if (msg.ref_pose !== undefined) {
      resolved.ref_pose = geometry_msgs.msg.Pose.Resolve(msg.ref_pose)
    }
    else {
      resolved.ref_pose = new geometry_msgs.msg.Pose()
    }

    if (msg.json !== undefined) {
      resolved.json = msg.json;
    }
    else {
      resolved.json = ''
    }

    return resolved;
    }
};

// Constants for message
Model3DGuardRequest.Constants = {
  MODE_START: 0,
  MODE_STOP: 1,
  LOAD_AND_BASE_UNCONNECTED: 0,
  LOAD_AND_BASE_CONNECTED: 1,
}

class Model3DGuardResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.success = null;
      this.error_message = null;
      this.json = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
      if (initObj.hasOwnProperty('json')) {
        this.json = initObj.json
      }
      else {
        this.json = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Model3DGuardResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    // Serialize message field [json]
    bufferOffset = _serializer.string(obj.json, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Model3DGuardResponse
    let len;
    let data = new Model3DGuardResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [json]
    data.json = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.error_message.length;
    length += object.json.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/Model3DGuardResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '167cca601a0d4e9905b926bf7c94e27b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    bool success
    string error_message
    string json
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Model3DGuardResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    if (msg.json !== undefined) {
      resolved.json = msg.json;
    }
    else {
      resolved.json = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: Model3DGuardRequest,
  Response: Model3DGuardResponse,
  md5sum() { return '4f691a40d93079796497e504ba1a6e59'; },
  datatype() { return 'visual_servo_msgs/Model3DGuard'; }
};
