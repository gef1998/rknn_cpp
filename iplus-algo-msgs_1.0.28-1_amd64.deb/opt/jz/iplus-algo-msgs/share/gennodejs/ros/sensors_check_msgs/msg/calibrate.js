// Auto-generated. Do not edit!

// (in-package sensors_check_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class calibrate {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.calib_part = null;
      this.calib_type = null;
      this.camera_type = null;
      this.tag_type = null;
      this.x = null;
      this.radius = null;
    }
    else {
      if (initObj.hasOwnProperty('calib_part')) {
        this.calib_part = initObj.calib_part
      }
      else {
        this.calib_part = 0;
      }
      if (initObj.hasOwnProperty('calib_type')) {
        this.calib_type = initObj.calib_type
      }
      else {
        this.calib_type = 0;
      }
      if (initObj.hasOwnProperty('camera_type')) {
        this.camera_type = initObj.camera_type
      }
      else {
        this.camera_type = 0;
      }
      if (initObj.hasOwnProperty('tag_type')) {
        this.tag_type = initObj.tag_type
      }
      else {
        this.tag_type = 0;
      }
      if (initObj.hasOwnProperty('x')) {
        this.x = initObj.x
      }
      else {
        this.x = 0.0;
      }
      if (initObj.hasOwnProperty('radius')) {
        this.radius = initObj.radius
      }
      else {
        this.radius = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type calibrate
    // Serialize message field [calib_part]
    bufferOffset = _serializer.uint8(obj.calib_part, buffer, bufferOffset);
    // Serialize message field [calib_type]
    bufferOffset = _serializer.uint8(obj.calib_type, buffer, bufferOffset);
    // Serialize message field [camera_type]
    bufferOffset = _serializer.uint8(obj.camera_type, buffer, bufferOffset);
    // Serialize message field [tag_type]
    bufferOffset = _serializer.uint8(obj.tag_type, buffer, bufferOffset);
    // Serialize message field [x]
    bufferOffset = _serializer.float32(obj.x, buffer, bufferOffset);
    // Serialize message field [radius]
    bufferOffset = _serializer.float32(obj.radius, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type calibrate
    let len;
    let data = new calibrate(null);
    // Deserialize message field [calib_part]
    data.calib_part = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [calib_type]
    data.calib_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [camera_type]
    data.camera_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [tag_type]
    data.tag_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [x]
    data.x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [radius]
    data.radius = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sensors_check_msgs/calibrate';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'af582c3a136d25a1cca10961d633d183';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8 calib_part
    uint8 CALIB_LASER = 0
    uint8 CALIB_ODOM = 1
    uint8 CALIB_VISUAL_SERVO = 2
    
    uint8 calib_type
    uint8 CALIB_LINE = 0
    uint8 CALIB_ROTATE = 1
    
    uint8 camera_type
    uint8 UP_CAMERA = 0
    uint8 DOWN_CAMERA = 1
    uint8 tag_type
    uint8 SHELF_TAG = 0
    uint8 NORMAL_TAG = 1
    uint8 LANDMARK_TAG = 2
    
    float32 x
    float32 radius
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new calibrate(null);
    if (msg.calib_part !== undefined) {
      resolved.calib_part = msg.calib_part;
    }
    else {
      resolved.calib_part = 0
    }

    if (msg.calib_type !== undefined) {
      resolved.calib_type = msg.calib_type;
    }
    else {
      resolved.calib_type = 0
    }

    if (msg.camera_type !== undefined) {
      resolved.camera_type = msg.camera_type;
    }
    else {
      resolved.camera_type = 0
    }

    if (msg.tag_type !== undefined) {
      resolved.tag_type = msg.tag_type;
    }
    else {
      resolved.tag_type = 0
    }

    if (msg.x !== undefined) {
      resolved.x = msg.x;
    }
    else {
      resolved.x = 0.0
    }

    if (msg.radius !== undefined) {
      resolved.radius = msg.radius;
    }
    else {
      resolved.radius = 0.0
    }

    return resolved;
    }
};

// Constants for message
calibrate.Constants = {
  CALIB_LASER: 0,
  CALIB_ODOM: 1,
  CALIB_VISUAL_SERVO: 2,
  CALIB_LINE: 0,
  CALIB_ROTATE: 1,
  UP_CAMERA: 0,
  DOWN_CAMERA: 1,
  SHELF_TAG: 0,
  NORMAL_TAG: 1,
  LANDMARK_TAG: 2,
}

module.exports = calibrate;
