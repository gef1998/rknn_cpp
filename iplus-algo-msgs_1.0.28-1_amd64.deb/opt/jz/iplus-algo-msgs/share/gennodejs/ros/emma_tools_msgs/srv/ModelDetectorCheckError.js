// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class ModelDetectorCheckErrorRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map2opti = null;
      this.model2map = null;
      this.rigid_body_name = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('map2opti')) {
        this.map2opti = initObj.map2opti
      }
      else {
        this.map2opti = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('model2map')) {
        this.model2map = initObj.model2map
      }
      else {
        this.model2map = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('rigid_body_name')) {
        this.rigid_body_name = initObj.rigid_body_name
      }
      else {
        this.rigid_body_name = '';
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ModelDetectorCheckErrorRequest
    // Serialize message field [map2opti]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.map2opti, buffer, bufferOffset);
    // Serialize message field [model2map]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.model2map, buffer, bufferOffset);
    // Serialize message field [rigid_body_name]
    bufferOffset = _serializer.string(obj.rigid_body_name, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ModelDetectorCheckErrorRequest
    let len;
    let data = new ModelDetectorCheckErrorRequest(null);
    // Deserialize message field [map2opti]
    data.map2opti = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [model2map]
    data.model2map = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [rigid_body_name]
    data.rigid_body_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.rigid_body_name.length;
    length += object.json_string.length;
    return length + 88;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/ModelDetectorCheckErrorRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd2df13b562ca608030a1343ef81fbb87';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Pose map2opti
    geometry_msgs/Pose2D model2map
    string rigid_body_name
    string json_string
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ModelDetectorCheckErrorRequest(null);
    if (msg.map2opti !== undefined) {
      resolved.map2opti = geometry_msgs.msg.Pose.Resolve(msg.map2opti)
    }
    else {
      resolved.map2opti = new geometry_msgs.msg.Pose()
    }

    if (msg.model2map !== undefined) {
      resolved.model2map = geometry_msgs.msg.Pose2D.Resolve(msg.model2map)
    }
    else {
      resolved.model2map = new geometry_msgs.msg.Pose2D()
    }

    if (msg.rigid_body_name !== undefined) {
      resolved.rigid_body_name = msg.rigid_body_name;
    }
    else {
      resolved.rigid_body_name = ''
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

class ModelDetectorCheckErrorResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.succeed = null;
      this.message = null;
      this.error_x = null;
      this.error_y = null;
      this.error_theta = null;
      this.error = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('succeed')) {
        this.succeed = initObj.succeed
      }
      else {
        this.succeed = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('error_x')) {
        this.error_x = initObj.error_x
      }
      else {
        this.error_x = 0.0;
      }
      if (initObj.hasOwnProperty('error_y')) {
        this.error_y = initObj.error_y
      }
      else {
        this.error_y = 0.0;
      }
      if (initObj.hasOwnProperty('error_theta')) {
        this.error_theta = initObj.error_theta
      }
      else {
        this.error_theta = 0.0;
      }
      if (initObj.hasOwnProperty('error')) {
        this.error = initObj.error
      }
      else {
        this.error = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ModelDetectorCheckErrorResponse
    // Serialize message field [succeed]
    bufferOffset = _serializer.bool(obj.succeed, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [error_x]
    bufferOffset = _serializer.float32(obj.error_x, buffer, bufferOffset);
    // Serialize message field [error_y]
    bufferOffset = _serializer.float32(obj.error_y, buffer, bufferOffset);
    // Serialize message field [error_theta]
    bufferOffset = _serializer.float32(obj.error_theta, buffer, bufferOffset);
    // Serialize message field [error]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.error, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ModelDetectorCheckErrorResponse
    let len;
    let data = new ModelDetectorCheckErrorResponse(null);
    // Deserialize message field [succeed]
    data.succeed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_x]
    data.error_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [error_y]
    data.error_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [error_theta]
    data.error_theta = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [error]
    data.error = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    length += object.json_string.length;
    return length + 77;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/ModelDetectorCheckErrorResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e1f056aeae5705435b4328f3f6f09a32';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool succeed
    string message
    float32 error_x
    float32 error_y
    float32 error_theta
    geometry_msgs/Pose error
    string json_string
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ModelDetectorCheckErrorResponse(null);
    if (msg.succeed !== undefined) {
      resolved.succeed = msg.succeed;
    }
    else {
      resolved.succeed = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.error_x !== undefined) {
      resolved.error_x = msg.error_x;
    }
    else {
      resolved.error_x = 0.0
    }

    if (msg.error_y !== undefined) {
      resolved.error_y = msg.error_y;
    }
    else {
      resolved.error_y = 0.0
    }

    if (msg.error_theta !== undefined) {
      resolved.error_theta = msg.error_theta;
    }
    else {
      resolved.error_theta = 0.0
    }

    if (msg.error !== undefined) {
      resolved.error = geometry_msgs.msg.Pose.Resolve(msg.error)
    }
    else {
      resolved.error = new geometry_msgs.msg.Pose()
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: ModelDetectorCheckErrorRequest,
  Response: ModelDetectorCheckErrorResponse,
  md5sum() { return '8f892664d6198631aa41dde168330b6d'; },
  datatype() { return 'emma_tools_msgs/ModelDetectorCheckError'; }
};
