// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class FrontEndPoseInitializationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.use_currentPose = null;
      this.imagePose = null;
    }
    else {
      if (initObj.hasOwnProperty('use_currentPose')) {
        this.use_currentPose = initObj.use_currentPose
      }
      else {
        this.use_currentPose = false;
      }
      if (initObj.hasOwnProperty('imagePose')) {
        this.imagePose = initObj.imagePose
      }
      else {
        this.imagePose = new geometry_msgs.msg.Pose2D();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndPoseInitializationRequest
    // Serialize message field [use_currentPose]
    bufferOffset = _serializer.bool(obj.use_currentPose, buffer, bufferOffset);
    // Serialize message field [imagePose]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.imagePose, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndPoseInitializationRequest
    let len;
    let data = new FrontEndPoseInitializationRequest(null);
    // Deserialize message field [use_currentPose]
    data.use_currentPose = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [imagePose]
    data.imagePose = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 25;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/FrontEndPoseInitializationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7d35e84ac728d1fc33be508cfa0267d6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    bool use_currentPose
    geometry_msgs/Pose2D imagePose
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndPoseInitializationRequest(null);
    if (msg.use_currentPose !== undefined) {
      resolved.use_currentPose = msg.use_currentPose;
    }
    else {
      resolved.use_currentPose = false
    }

    if (msg.imagePose !== undefined) {
      resolved.imagePose = geometry_msgs.msg.Pose2D.Resolve(msg.imagePose)
    }
    else {
      resolved.imagePose = new geometry_msgs.msg.Pose2D()
    }

    return resolved;
    }
};

class FrontEndPoseInitializationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.is_successed = null;
      this.header = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('is_successed')) {
        this.is_successed = initObj.is_successed
      }
      else {
        this.is_successed = false;
      }
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndPoseInitializationResponse
    // Serialize message field [is_successed]
    bufferOffset = _serializer.bool(obj.is_successed, buffer, bufferOffset);
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndPoseInitializationResponse
    let len;
    let data = new FrontEndPoseInitializationResponse(null);
    // Deserialize message field [is_successed]
    data.is_successed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.error_message.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/FrontEndPoseInitializationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '29032a558b95ecfa75a698aeab7de1f6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool is_successed
    std_msgs/Header header
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndPoseInitializationResponse(null);
    if (msg.is_successed !== undefined) {
      resolved.is_successed = msg.is_successed;
    }
    else {
      resolved.is_successed = false
    }

    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: FrontEndPoseInitializationRequest,
  Response: FrontEndPoseInitializationResponse,
  md5sum() { return 'd6f6927ee759641d78b8e662c907f152'; },
  datatype() { return 'cartographer_ros_msgs/FrontEndPoseInitialization'; }
};
