// Auto-generated. Do not edit!

// (in-package move_task_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class TaskErrorType {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error = null;
      this.error_des = null;
    }
    else {
      if (initObj.hasOwnProperty('error')) {
        this.error = initObj.error
      }
      else {
        this.error = 0;
      }
      if (initObj.hasOwnProperty('error_des')) {
        this.error_des = initObj.error_des
      }
      else {
        this.error_des = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskErrorType
    // Serialize message field [error]
    bufferOffset = _serializer.uint8(obj.error, buffer, bufferOffset);
    // Serialize message field [error_des]
    bufferOffset = _serializer.string(obj.error_des, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskErrorType
    let len;
    let data = new TaskErrorType(null);
    // Deserialize message field [error]
    data.error = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [error_des]
    data.error_des = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_des.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'move_task_msgs/TaskErrorType';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '85fc7b3d3ddb4901415c418760d643bf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # move task error type
    
    uint8 error
    
    uint8 INVALID_FRAME_ID = 0
    uint8 INVALID_GOAL_ID  = 1
    uint8 NO_TOPO_ROUTE    = 2
    uint8 MB_DISCONNECTED  = 3
    uint8 VS_DISCONNECTED  = 4
    uint8 INVALID_LOCAL_MOVE_FRAME = 5
    uint8 CANCEL_SIGNAL = 6
    uint8 LOCALIZATION_FAILED = 7
    uint8 VS_ERROR_DIST =8
    uint8 VS_ABORTED = 9
    uint8 LFVS_ERROR_Y = 10
    uint8 LFVS_ERROR_THETA = 11
    uint8 LFVS_ABORTED = 12
    uint8 ABORTED_IN_NEAREST_WP = 13
    uint8 ABORTED_IN_LAST_WP = 14
    uint8 MB_GOAL_BEYOND_SCOPE = 15
    uint8 LOCAL_MOVE_ABORTED = 16
    uint8 TASK_SERVER_KILLED = 17
    
    string error_des
    
    
    
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskErrorType(null);
    if (msg.error !== undefined) {
      resolved.error = msg.error;
    }
    else {
      resolved.error = 0
    }

    if (msg.error_des !== undefined) {
      resolved.error_des = msg.error_des;
    }
    else {
      resolved.error_des = ''
    }

    return resolved;
    }
};

// Constants for message
TaskErrorType.Constants = {
  INVALID_FRAME_ID: 0,
  INVALID_GOAL_ID: 1,
  NO_TOPO_ROUTE: 2,
  MB_DISCONNECTED: 3,
  VS_DISCONNECTED: 4,
  INVALID_LOCAL_MOVE_FRAME: 5,
  CANCEL_SIGNAL: 6,
  LOCALIZATION_FAILED: 7,
  VS_ERROR_DIST: 8,
  VS_ABORTED: 9,
  LFVS_ERROR_Y: 10,
  LFVS_ERROR_THETA: 11,
  LFVS_ABORTED: 12,
  ABORTED_IN_NEAREST_WP: 13,
  ABORTED_IN_LAST_WP: 14,
  MB_GOAL_BEYOND_SCOPE: 15,
  LOCAL_MOVE_ABORTED: 16,
  TASK_SERVER_KILLED: 17,
}

module.exports = TaskErrorType;
