// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class MergeMapServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.path1 = null;
      this.path2 = null;
      this.init_pose = null;
    }
    else {
      if (initObj.hasOwnProperty('path1')) {
        this.path1 = initObj.path1
      }
      else {
        this.path1 = '';
      }
      if (initObj.hasOwnProperty('path2')) {
        this.path2 = initObj.path2
      }
      else {
        this.path2 = '';
      }
      if (initObj.hasOwnProperty('init_pose')) {
        this.init_pose = initObj.init_pose
      }
      else {
        this.init_pose = new geometry_msgs.msg.Pose();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MergeMapServiceRequest
    // Serialize message field [path1]
    bufferOffset = _serializer.string(obj.path1, buffer, bufferOffset);
    // Serialize message field [path2]
    bufferOffset = _serializer.string(obj.path2, buffer, bufferOffset);
    // Serialize message field [init_pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.init_pose, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MergeMapServiceRequest
    let len;
    let data = new MergeMapServiceRequest(null);
    // Deserialize message field [path1]
    data.path1 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [path2]
    data.path2 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [init_pose]
    data.init_pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.path1.length;
    length += object.path2.length;
    return length + 64;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/MergeMapServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'af9dc88c35f23a521d3ff56f2b2a5ff4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string path1
    string path2
    geometry_msgs/Pose init_pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MergeMapServiceRequest(null);
    if (msg.path1 !== undefined) {
      resolved.path1 = msg.path1;
    }
    else {
      resolved.path1 = ''
    }

    if (msg.path2 !== undefined) {
      resolved.path2 = msg.path2;
    }
    else {
      resolved.path2 = ''
    }

    if (msg.init_pose !== undefined) {
      resolved.init_pose = geometry_msgs.msg.Pose.Resolve(msg.init_pose)
    }
    else {
      resolved.init_pose = new geometry_msgs.msg.Pose()
    }

    return resolved;
    }
};

class MergeMapServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.info = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('info')) {
        this.info = initObj.info
      }
      else {
        this.info = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MergeMapServiceResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [info]
    bufferOffset = _serializer.string(obj.info, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MergeMapServiceResponse
    let len;
    let data = new MergeMapServiceResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [info]
    data.info = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.info.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/MergeMapServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5b014a3b1f45715ffd8087f5d5c89429';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string info
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MergeMapServiceResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.info !== undefined) {
      resolved.info = msg.info;
    }
    else {
      resolved.info = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: MergeMapServiceRequest,
  Response: MergeMapServiceResponse,
  md5sum() { return 'ccb1b2ccd2af45f05fc59c7de871b004'; },
  datatype() { return 'map_manager_msgs/MergeMapService'; }
};
