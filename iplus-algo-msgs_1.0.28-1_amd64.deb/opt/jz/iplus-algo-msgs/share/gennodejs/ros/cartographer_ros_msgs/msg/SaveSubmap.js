// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SubmapID = require('./SubmapID.js');
let SubmapTexture = require('./SubmapTexture.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class SaveSubmap {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.pose_in_map = null;
      this.pose_in_local = null;
      this.num_cells = null;
      this.max = null;
      this.constraints = null;
      this.submap_version = null;
      this.textures = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = new SubmapID();
      }
      if (initObj.hasOwnProperty('pose_in_map')) {
        this.pose_in_map = initObj.pose_in_map
      }
      else {
        this.pose_in_map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('pose_in_local')) {
        this.pose_in_local = initObj.pose_in_local
      }
      else {
        this.pose_in_local = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('num_cells')) {
        this.num_cells = initObj.num_cells
      }
      else {
        this.num_cells = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('max')) {
        this.max = initObj.max
      }
      else {
        this.max = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('constraints')) {
        this.constraints = initObj.constraints
      }
      else {
        this.constraints = [];
      }
      if (initObj.hasOwnProperty('submap_version')) {
        this.submap_version = initObj.submap_version
      }
      else {
        this.submap_version = 0;
      }
      if (initObj.hasOwnProperty('textures')) {
        this.textures = initObj.textures
      }
      else {
        this.textures = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveSubmap
    // Serialize message field [id]
    bufferOffset = SubmapID.serialize(obj.id, buffer, bufferOffset);
    // Serialize message field [pose_in_map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose_in_map, buffer, bufferOffset);
    // Serialize message field [pose_in_local]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose_in_local, buffer, bufferOffset);
    // Check that the constant length array field [num_cells] has the right length
    if (obj.num_cells.length !== 2) {
      throw new Error('Unable to serialize array field num_cells - length must be 2')
    }
    // Serialize message field [num_cells]
    bufferOffset = _arraySerializer.float32(obj.num_cells, buffer, bufferOffset, 2);
    // Check that the constant length array field [max] has the right length
    if (obj.max.length !== 2) {
      throw new Error('Unable to serialize array field max - length must be 2')
    }
    // Serialize message field [max]
    bufferOffset = _arraySerializer.float32(obj.max, buffer, bufferOffset, 2);
    // Serialize message field [constraints]
    // Serialize the length for message field [constraints]
    bufferOffset = _serializer.uint32(obj.constraints.length, buffer, bufferOffset);
    obj.constraints.forEach((val) => {
      bufferOffset = SubmapID.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [submap_version]
    bufferOffset = _serializer.int32(obj.submap_version, buffer, bufferOffset);
    // Serialize message field [textures]
    // Serialize the length for message field [textures]
    bufferOffset = _serializer.uint32(obj.textures.length, buffer, bufferOffset);
    obj.textures.forEach((val) => {
      bufferOffset = SubmapTexture.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveSubmap
    let len;
    let data = new SaveSubmap(null);
    // Deserialize message field [id]
    data.id = SubmapID.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose_in_map]
    data.pose_in_map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose_in_local]
    data.pose_in_local = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [num_cells]
    data.num_cells = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [max]
    data.max = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [constraints]
    // Deserialize array length for message field [constraints]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.constraints = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.constraints[i] = SubmapID.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [submap_version]
    data.submap_version = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [textures]
    // Deserialize array length for message field [textures]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.textures = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.textures[i] = SubmapTexture.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 12 * object.constraints.length;
    object.textures.forEach((val) => {
      length += SubmapTexture.getMessageSize(val);
    });
    return length + 152;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/SaveSubmap';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a1a3498304f05dd2da742845cc26abfd';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    cartographer_ros_msgs/SubmapID id
    geometry_msgs/Pose pose_in_map
    geometry_msgs/Pose pose_in_local
    float32[2] num_cells
    float32[2] max
    cartographer_ros_msgs/SubmapID[] constraints
    int32 submap_version
    cartographer_ros_msgs/SubmapTexture[] textures
    
    ================================================================================
    MSG: cartographer_ros_msgs/SubmapID
    int32 trajectory_id
    int32 submap_index
    int32 submap_version
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: cartographer_ros_msgs/SubmapTexture
    # Copyright 2017 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    uint8[] cells
    int32 width
    int32 height
    float64 resolution
    geometry_msgs/Pose slice_pose
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveSubmap(null);
    if (msg.id !== undefined) {
      resolved.id = SubmapID.Resolve(msg.id)
    }
    else {
      resolved.id = new SubmapID()
    }

    if (msg.pose_in_map !== undefined) {
      resolved.pose_in_map = geometry_msgs.msg.Pose.Resolve(msg.pose_in_map)
    }
    else {
      resolved.pose_in_map = new geometry_msgs.msg.Pose()
    }

    if (msg.pose_in_local !== undefined) {
      resolved.pose_in_local = geometry_msgs.msg.Pose.Resolve(msg.pose_in_local)
    }
    else {
      resolved.pose_in_local = new geometry_msgs.msg.Pose()
    }

    if (msg.num_cells !== undefined) {
      resolved.num_cells = msg.num_cells;
    }
    else {
      resolved.num_cells = new Array(2).fill(0)
    }

    if (msg.max !== undefined) {
      resolved.max = msg.max;
    }
    else {
      resolved.max = new Array(2).fill(0)
    }

    if (msg.constraints !== undefined) {
      resolved.constraints = new Array(msg.constraints.length);
      for (let i = 0; i < resolved.constraints.length; ++i) {
        resolved.constraints[i] = SubmapID.Resolve(msg.constraints[i]);
      }
    }
    else {
      resolved.constraints = []
    }

    if (msg.submap_version !== undefined) {
      resolved.submap_version = msg.submap_version;
    }
    else {
      resolved.submap_version = 0
    }

    if (msg.textures !== undefined) {
      resolved.textures = new Array(msg.textures.length);
      for (let i = 0; i < resolved.textures.length; ++i) {
        resolved.textures[i] = SubmapTexture.Resolve(msg.textures[i]);
      }
    }
    else {
      resolved.textures = []
    }

    return resolved;
    }
};

module.exports = SaveSubmap;
