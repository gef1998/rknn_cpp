// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let SubmapImageEntry = require('../msg/SubmapImageEntry.js');

//-----------------------------------------------------------

class SubmapImagesPreviewServerRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map_path1 = null;
      this.map_path2 = null;
    }
    else {
      if (initObj.hasOwnProperty('map_path1')) {
        this.map_path1 = initObj.map_path1
      }
      else {
        this.map_path1 = '';
      }
      if (initObj.hasOwnProperty('map_path2')) {
        this.map_path2 = initObj.map_path2
      }
      else {
        this.map_path2 = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SubmapImagesPreviewServerRequest
    // Serialize message field [map_path1]
    bufferOffset = _serializer.string(obj.map_path1, buffer, bufferOffset);
    // Serialize message field [map_path2]
    bufferOffset = _serializer.string(obj.map_path2, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SubmapImagesPreviewServerRequest
    let len;
    let data = new SubmapImagesPreviewServerRequest(null);
    // Deserialize message field [map_path1]
    data.map_path1 = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [map_path2]
    data.map_path2 = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.map_path1.length;
    length += object.map_path2.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/SubmapImagesPreviewServerRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '43150dd6fd14b68d44c9649f9ce1d712';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string map_path1
    string map_path2
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SubmapImagesPreviewServerRequest(null);
    if (msg.map_path1 !== undefined) {
      resolved.map_path1 = msg.map_path1;
    }
    else {
      resolved.map_path1 = ''
    }

    if (msg.map_path2 !== undefined) {
      resolved.map_path2 = msg.map_path2;
    }
    else {
      resolved.map_path2 = ''
    }

    return resolved;
    }
};

class SubmapImagesPreviewServerResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.submap_images = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('submap_images')) {
        this.submap_images = initObj.submap_images
      }
      else {
        this.submap_images = [];
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SubmapImagesPreviewServerResponse
    // Serialize message field [submap_images]
    // Serialize the length for message field [submap_images]
    bufferOffset = _serializer.uint32(obj.submap_images.length, buffer, bufferOffset);
    obj.submap_images.forEach((val) => {
      bufferOffset = SubmapImageEntry.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SubmapImagesPreviewServerResponse
    let len;
    let data = new SubmapImagesPreviewServerResponse(null);
    // Deserialize message field [submap_images]
    // Deserialize array length for message field [submap_images]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.submap_images = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.submap_images[i] = SubmapImageEntry.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.submap_images.forEach((val) => {
      length += SubmapImageEntry.getMessageSize(val);
    });
    length += object.error_message.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/SubmapImagesPreviewServerResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f776a3fceaec3ff6a303d93d9b1181ef';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    cartographer_ros_msgs/SubmapImageEntry[] submap_images
    string error_message
    
    ================================================================================
    MSG: cartographer_ros_msgs/SubmapImageEntry
    int32 trajectory_id
    int32 submap_index
    int32 submap_version
    float64 resolution
    geometry_msgs/Pose pose_in_map
    sensor_msgs/CompressedImage image
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensor_msgs/CompressedImage
    # This message contains a compressed image
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of cameara
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
    
    string format        # Specifies the format of the data
                         #   Acceptable values:
                         #     jpeg, png
    uint8[] data         # Compressed image buffer
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SubmapImagesPreviewServerResponse(null);
    if (msg.submap_images !== undefined) {
      resolved.submap_images = new Array(msg.submap_images.length);
      for (let i = 0; i < resolved.submap_images.length; ++i) {
        resolved.submap_images[i] = SubmapImageEntry.Resolve(msg.submap_images[i]);
      }
    }
    else {
      resolved.submap_images = []
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SubmapImagesPreviewServerRequest,
  Response: SubmapImagesPreviewServerResponse,
  md5sum() { return '0524afdf25f3c3f0c4321a87c7c02fc3'; },
  datatype() { return 'cartographer_ros_msgs/SubmapImagesPreviewServer'; }
};
