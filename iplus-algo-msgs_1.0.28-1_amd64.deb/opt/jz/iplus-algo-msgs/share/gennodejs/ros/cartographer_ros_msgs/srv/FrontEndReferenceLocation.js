// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class FrontEndReferenceLocationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.imagePose = null;
    }
    else {
      if (initObj.hasOwnProperty('imagePose')) {
        this.imagePose = initObj.imagePose
      }
      else {
        this.imagePose = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndReferenceLocationRequest
    // Serialize message field [imagePose]
    // Serialize the length for message field [imagePose]
    bufferOffset = _serializer.uint32(obj.imagePose.length, buffer, bufferOffset);
    obj.imagePose.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose2D.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndReferenceLocationRequest
    let len;
    let data = new FrontEndReferenceLocationRequest(null);
    // Deserialize message field [imagePose]
    // Deserialize array length for message field [imagePose]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.imagePose = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.imagePose[i] = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 24 * object.imagePose.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/FrontEndReferenceLocationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0bc33512e5a911bacd2d7f2fc0fd3c29';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    geometry_msgs/Pose2D[] imagePose
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndReferenceLocationRequest(null);
    if (msg.imagePose !== undefined) {
      resolved.imagePose = new Array(msg.imagePose.length);
      for (let i = 0; i < resolved.imagePose.length; ++i) {
        resolved.imagePose[i] = geometry_msgs.msg.Pose2D.Resolve(msg.imagePose[i]);
      }
    }
    else {
      resolved.imagePose = []
    }

    return resolved;
    }
};

class FrontEndReferenceLocationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.reference_id = null;
      this.referencePose = null;
      this.worldPose = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('reference_id')) {
        this.reference_id = initObj.reference_id
      }
      else {
        this.reference_id = [];
      }
      if (initObj.hasOwnProperty('referencePose')) {
        this.referencePose = initObj.referencePose
      }
      else {
        this.referencePose = [];
      }
      if (initObj.hasOwnProperty('worldPose')) {
        this.worldPose = initObj.worldPose
      }
      else {
        this.worldPose = [];
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndReferenceLocationResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [reference_id]
    bufferOffset = _arraySerializer.int32(obj.reference_id, buffer, bufferOffset, null);
    // Serialize message field [referencePose]
    // Serialize the length for message field [referencePose]
    bufferOffset = _serializer.uint32(obj.referencePose.length, buffer, bufferOffset);
    obj.referencePose.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [worldPose]
    // Serialize the length for message field [worldPose]
    bufferOffset = _serializer.uint32(obj.worldPose.length, buffer, bufferOffset);
    obj.worldPose.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndReferenceLocationResponse
    let len;
    let data = new FrontEndReferenceLocationResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [reference_id]
    data.reference_id = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [referencePose]
    // Deserialize array length for message field [referencePose]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.referencePose = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.referencePose[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [worldPose]
    // Deserialize array length for message field [worldPose]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.worldPose = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.worldPose[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += 4 * object.reference_id.length;
    length += 56 * object.referencePose.length;
    length += 56 * object.worldPose.length;
    length += object.error_message.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/FrontEndReferenceLocationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd25f6c5b7bf27d8f9de3582790b58e10';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    int32[] reference_id
    geometry_msgs/Pose[] referencePose
    geometry_msgs/Pose[] worldPose
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndReferenceLocationResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.reference_id !== undefined) {
      resolved.reference_id = msg.reference_id;
    }
    else {
      resolved.reference_id = []
    }

    if (msg.referencePose !== undefined) {
      resolved.referencePose = new Array(msg.referencePose.length);
      for (let i = 0; i < resolved.referencePose.length; ++i) {
        resolved.referencePose[i] = geometry_msgs.msg.Pose.Resolve(msg.referencePose[i]);
      }
    }
    else {
      resolved.referencePose = []
    }

    if (msg.worldPose !== undefined) {
      resolved.worldPose = new Array(msg.worldPose.length);
      for (let i = 0; i < resolved.worldPose.length; ++i) {
        resolved.worldPose[i] = geometry_msgs.msg.Pose.Resolve(msg.worldPose[i]);
      }
    }
    else {
      resolved.worldPose = []
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: FrontEndReferenceLocationRequest,
  Response: FrontEndReferenceLocationResponse,
  md5sum() { return 'e6cca772267e436abd3394c93d54dd68'; },
  datatype() { return 'cartographer_ros_msgs/FrontEndReferenceLocation'; }
};
