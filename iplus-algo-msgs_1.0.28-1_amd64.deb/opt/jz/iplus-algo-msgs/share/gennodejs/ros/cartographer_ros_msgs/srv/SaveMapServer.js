// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let SaveSubmap = require('../msg/SaveSubmap.js');
let LandmarkNewEntry = require('../msg/LandmarkNewEntry.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SaveMapServerRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map_name = null;
      this.submaps = null;
      this.landmarks = null;
      this.nodes_poses_with_stamp = null;
    }
    else {
      if (initObj.hasOwnProperty('map_name')) {
        this.map_name = initObj.map_name
      }
      else {
        this.map_name = '';
      }
      if (initObj.hasOwnProperty('submaps')) {
        this.submaps = initObj.submaps
      }
      else {
        this.submaps = [];
      }
      if (initObj.hasOwnProperty('landmarks')) {
        this.landmarks = initObj.landmarks
      }
      else {
        this.landmarks = [];
      }
      if (initObj.hasOwnProperty('nodes_poses_with_stamp')) {
        this.nodes_poses_with_stamp = initObj.nodes_poses_with_stamp
      }
      else {
        this.nodes_poses_with_stamp = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveMapServerRequest
    // Serialize message field [map_name]
    bufferOffset = _serializer.string(obj.map_name, buffer, bufferOffset);
    // Serialize message field [submaps]
    // Serialize the length for message field [submaps]
    bufferOffset = _serializer.uint32(obj.submaps.length, buffer, bufferOffset);
    obj.submaps.forEach((val) => {
      bufferOffset = SaveSubmap.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [landmarks]
    // Serialize the length for message field [landmarks]
    bufferOffset = _serializer.uint32(obj.landmarks.length, buffer, bufferOffset);
    obj.landmarks.forEach((val) => {
      bufferOffset = LandmarkNewEntry.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [nodes_poses_with_stamp]
    // Serialize the length for message field [nodes_poses_with_stamp]
    bufferOffset = _serializer.uint32(obj.nodes_poses_with_stamp.length, buffer, bufferOffset);
    obj.nodes_poses_with_stamp.forEach((val) => {
      bufferOffset = geometry_msgs.msg.PoseStamped.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveMapServerRequest
    let len;
    let data = new SaveMapServerRequest(null);
    // Deserialize message field [map_name]
    data.map_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [submaps]
    // Deserialize array length for message field [submaps]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.submaps = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.submaps[i] = SaveSubmap.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [landmarks]
    // Deserialize array length for message field [landmarks]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.landmarks = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.landmarks[i] = LandmarkNewEntry.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [nodes_poses_with_stamp]
    // Deserialize array length for message field [nodes_poses_with_stamp]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.nodes_poses_with_stamp = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.nodes_poses_with_stamp[i] = geometry_msgs.msg.PoseStamped.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.map_name.length;
    object.submaps.forEach((val) => {
      length += SaveSubmap.getMessageSize(val);
    });
    object.landmarks.forEach((val) => {
      length += LandmarkNewEntry.getMessageSize(val);
    });
    object.nodes_poses_with_stamp.forEach((val) => {
      length += geometry_msgs.msg.PoseStamped.getMessageSize(val);
    });
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/SaveMapServerRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '51e081be3da14970ce900e7687e15416';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string map_name
    cartographer_ros_msgs/SaveSubmap[] submaps
    cartographer_ros_msgs/LandmarkNewEntry[] landmarks
    geometry_msgs/PoseStamped[] nodes_poses_with_stamp
    
    ================================================================================
    MSG: cartographer_ros_msgs/SaveSubmap
    cartographer_ros_msgs/SubmapID id
    geometry_msgs/Pose pose_in_map
    geometry_msgs/Pose pose_in_local
    float32[2] num_cells
    float32[2] max
    cartographer_ros_msgs/SubmapID[] constraints
    int32 submap_version
    cartographer_ros_msgs/SubmapTexture[] textures
    
    ================================================================================
    MSG: cartographer_ros_msgs/SubmapID
    int32 trajectory_id
    int32 submap_index
    int32 submap_version
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: cartographer_ros_msgs/SubmapTexture
    # Copyright 2017 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    uint8[] cells
    int32 width
    int32 height
    float64 resolution
    geometry_msgs/Pose slice_pose
    
    ================================================================================
    MSG: cartographer_ros_msgs/LandmarkNewEntry
    # 2018 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    string ns
    string id
    int32 visible
    float64 normal_x
    float64 normal_y
    float64 normal_z
    geometry_msgs/Pose tracking_from_landmark_transform
    float64 translation_weight
    float64 rotation_weight
    float64 pole_radius
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveMapServerRequest(null);
    if (msg.map_name !== undefined) {
      resolved.map_name = msg.map_name;
    }
    else {
      resolved.map_name = ''
    }

    if (msg.submaps !== undefined) {
      resolved.submaps = new Array(msg.submaps.length);
      for (let i = 0; i < resolved.submaps.length; ++i) {
        resolved.submaps[i] = SaveSubmap.Resolve(msg.submaps[i]);
      }
    }
    else {
      resolved.submaps = []
    }

    if (msg.landmarks !== undefined) {
      resolved.landmarks = new Array(msg.landmarks.length);
      for (let i = 0; i < resolved.landmarks.length; ++i) {
        resolved.landmarks[i] = LandmarkNewEntry.Resolve(msg.landmarks[i]);
      }
    }
    else {
      resolved.landmarks = []
    }

    if (msg.nodes_poses_with_stamp !== undefined) {
      resolved.nodes_poses_with_stamp = new Array(msg.nodes_poses_with_stamp.length);
      for (let i = 0; i < resolved.nodes_poses_with_stamp.length; ++i) {
        resolved.nodes_poses_with_stamp[i] = geometry_msgs.msg.PoseStamped.Resolve(msg.nodes_poses_with_stamp[i]);
      }
    }
    else {
      resolved.nodes_poses_with_stamp = []
    }

    return resolved;
    }
};

class SaveMapServerResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SaveMapServerResponse
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SaveMapServerResponse
    let len;
    let data = new SaveMapServerResponse(null);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_message.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/SaveMapServerResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a13979422fc129b30b15994450a302b5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SaveMapServerResponse(null);
    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SaveMapServerRequest,
  Response: SaveMapServerResponse,
  md5sum() { return 'f4d78d225001afc0edd9009b0538ea69'; },
  datatype() { return 'cartographer_ros_msgs/SaveMapServer'; }
};
