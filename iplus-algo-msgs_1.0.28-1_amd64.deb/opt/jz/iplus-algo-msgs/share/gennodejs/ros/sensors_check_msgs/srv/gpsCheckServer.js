// Auto-generated. Do not edit!

// (in-package sensors_check_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class gpsCheckServerRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.mode = null;
      this.base2ecef = null;
      this.base2map = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = 0;
      }
      if (initObj.hasOwnProperty('base2ecef')) {
        this.base2ecef = initObj.base2ecef
      }
      else {
        this.base2ecef = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('base2map')) {
        this.base2map = initObj.base2map
      }
      else {
        this.base2map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type gpsCheckServerRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [mode]
    bufferOffset = _serializer.uint8(obj.mode, buffer, bufferOffset);
    // Serialize message field [base2ecef]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.base2ecef, buffer, bufferOffset);
    // Serialize message field [base2map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.base2map, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type gpsCheckServerRequest
    let len;
    let data = new gpsCheckServerRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [mode]
    data.mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [base2ecef]
    data.base2ecef = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [base2map]
    data.base2map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.json_string.length;
    return length + 117;
  }

  static datatype() {
    // Returns string type for a service object
    return 'sensors_check_msgs/gpsCheckServerRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '395f24e277bf3627af0928e93d2c4521';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    uint8 mode
    uint8 TEACHING_BASE2ECEF=0
    uint8 TESTING_BASE2ECEF=1
    geometry_msgs/Pose base2ecef
    geometry_msgs/Pose base2map
    
    string json_string
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new gpsCheckServerRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.mode !== undefined) {
      resolved.mode = msg.mode;
    }
    else {
      resolved.mode = 0
    }

    if (msg.base2ecef !== undefined) {
      resolved.base2ecef = geometry_msgs.msg.Pose.Resolve(msg.base2ecef)
    }
    else {
      resolved.base2ecef = new geometry_msgs.msg.Pose()
    }

    if (msg.base2map !== undefined) {
      resolved.base2map = geometry_msgs.msg.Pose.Resolve(msg.base2map)
    }
    else {
      resolved.base2map = new geometry_msgs.msg.Pose()
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

// Constants for message
gpsCheckServerRequest.Constants = {
  TEACHING_BASE2ECEF: 0,
  TESTING_BASE2ECEF: 1,
}

class gpsCheckServerResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.success = null;
      this.base2ecef = null;
      this.base2map = null;
      this.error_test = null;
      this.error_world = null;
      this.error = null;
      this.error_message = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('base2ecef')) {
        this.base2ecef = initObj.base2ecef
      }
      else {
        this.base2ecef = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('base2map')) {
        this.base2map = initObj.base2map
      }
      else {
        this.base2map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('error_test')) {
        this.error_test = initObj.error_test
      }
      else {
        this.error_test = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('error_world')) {
        this.error_world = initObj.error_world
      }
      else {
        this.error_world = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('error')) {
        this.error = initObj.error
      }
      else {
        this.error = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type gpsCheckServerResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [base2ecef]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.base2ecef, buffer, bufferOffset);
    // Serialize message field [base2map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.base2map, buffer, bufferOffset);
    // Check that the constant length array field [error_test] has the right length
    if (obj.error_test.length !== 3) {
      throw new Error('Unable to serialize array field error_test - length must be 3')
    }
    // Serialize message field [error_test]
    bufferOffset = _arraySerializer.float32(obj.error_test, buffer, bufferOffset, 3);
    // Check that the constant length array field [error_world] has the right length
    if (obj.error_world.length !== 3) {
      throw new Error('Unable to serialize array field error_world - length must be 3')
    }
    // Serialize message field [error_world]
    bufferOffset = _arraySerializer.float32(obj.error_world, buffer, bufferOffset, 3);
    // Check that the constant length array field [error] has the right length
    if (obj.error.length !== 3) {
      throw new Error('Unable to serialize array field error - length must be 3')
    }
    // Serialize message field [error]
    bufferOffset = _arraySerializer.float32(obj.error, buffer, bufferOffset, 3);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type gpsCheckServerResponse
    let len;
    let data = new gpsCheckServerResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [base2ecef]
    data.base2ecef = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [base2map]
    data.base2map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_test]
    data.error_test = _arrayDeserializer.float32(buffer, bufferOffset, 3)
    // Deserialize message field [error_world]
    data.error_world = _arrayDeserializer.float32(buffer, bufferOffset, 3)
    // Deserialize message field [error]
    data.error = _arrayDeserializer.float32(buffer, bufferOffset, 3)
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.error_message.length;
    length += object.json_string.length;
    return length + 157;
  }

  static datatype() {
    // Returns string type for a service object
    return 'sensors_check_msgs/gpsCheckServerResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2ff1899baab3ab5118b13aa0c043ae58';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    bool success
    geometry_msgs/Pose base2ecef
    geometry_msgs/Pose base2map
    
    float32[3] error_test
    float32[3] error_world
    float32[3] error
    string error_message
    string json_string
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new gpsCheckServerResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.base2ecef !== undefined) {
      resolved.base2ecef = geometry_msgs.msg.Pose.Resolve(msg.base2ecef)
    }
    else {
      resolved.base2ecef = new geometry_msgs.msg.Pose()
    }

    if (msg.base2map !== undefined) {
      resolved.base2map = geometry_msgs.msg.Pose.Resolve(msg.base2map)
    }
    else {
      resolved.base2map = new geometry_msgs.msg.Pose()
    }

    if (msg.error_test !== undefined) {
      resolved.error_test = msg.error_test;
    }
    else {
      resolved.error_test = new Array(3).fill(0)
    }

    if (msg.error_world !== undefined) {
      resolved.error_world = msg.error_world;
    }
    else {
      resolved.error_world = new Array(3).fill(0)
    }

    if (msg.error !== undefined) {
      resolved.error = msg.error;
    }
    else {
      resolved.error = new Array(3).fill(0)
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: gpsCheckServerRequest,
  Response: gpsCheckServerResponse,
  md5sum() { return '0997f590d4af659c15055af4251a3bef'; },
  datatype() { return 'sensors_check_msgs/gpsCheckServer'; }
};
