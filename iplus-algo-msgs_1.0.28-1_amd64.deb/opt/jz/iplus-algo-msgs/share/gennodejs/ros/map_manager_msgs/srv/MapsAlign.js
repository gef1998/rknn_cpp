// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let TagPose = require('../msg/TagPose.js');

//-----------------------------------------------------------

class MapsAlignRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tag_map_path = null;
      this.laser_map_path = null;
    }
    else {
      if (initObj.hasOwnProperty('tag_map_path')) {
        this.tag_map_path = initObj.tag_map_path
      }
      else {
        this.tag_map_path = '';
      }
      if (initObj.hasOwnProperty('laser_map_path')) {
        this.laser_map_path = initObj.laser_map_path
      }
      else {
        this.laser_map_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MapsAlignRequest
    // Serialize message field [tag_map_path]
    bufferOffset = _serializer.string(obj.tag_map_path, buffer, bufferOffset);
    // Serialize message field [laser_map_path]
    bufferOffset = _serializer.string(obj.laser_map_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MapsAlignRequest
    let len;
    let data = new MapsAlignRequest(null);
    // Deserialize message field [tag_map_path]
    data.tag_map_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [laser_map_path]
    data.laser_map_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.tag_map_path.length;
    length += object.laser_map_path.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/MapsAlignRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4de8447ee90d76232dc6c0ca3c2a7dc4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string tag_map_path
    string laser_map_path
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MapsAlignRequest(null);
    if (msg.tag_map_path !== undefined) {
      resolved.tag_map_path = msg.tag_map_path;
    }
    else {
      resolved.tag_map_path = ''
    }

    if (msg.laser_map_path !== undefined) {
      resolved.laser_map_path = msg.laser_map_path;
    }
    else {
      resolved.laser_map_path = ''
    }

    return resolved;
    }
};

class MapsAlignResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.tags_in_laser_map = null;
      this.tags_in_tag_map = null;
      this.error_msgs = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('tags_in_laser_map')) {
        this.tags_in_laser_map = initObj.tags_in_laser_map
      }
      else {
        this.tags_in_laser_map = [];
      }
      if (initObj.hasOwnProperty('tags_in_tag_map')) {
        this.tags_in_tag_map = initObj.tags_in_tag_map
      }
      else {
        this.tags_in_tag_map = [];
      }
      if (initObj.hasOwnProperty('error_msgs')) {
        this.error_msgs = initObj.error_msgs
      }
      else {
        this.error_msgs = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MapsAlignResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [tags_in_laser_map]
    // Serialize the length for message field [tags_in_laser_map]
    bufferOffset = _serializer.uint32(obj.tags_in_laser_map.length, buffer, bufferOffset);
    obj.tags_in_laser_map.forEach((val) => {
      bufferOffset = TagPose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [tags_in_tag_map]
    // Serialize the length for message field [tags_in_tag_map]
    bufferOffset = _serializer.uint32(obj.tags_in_tag_map.length, buffer, bufferOffset);
    obj.tags_in_tag_map.forEach((val) => {
      bufferOffset = TagPose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [error_msgs]
    bufferOffset = _serializer.string(obj.error_msgs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MapsAlignResponse
    let len;
    let data = new MapsAlignResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [tags_in_laser_map]
    // Deserialize array length for message field [tags_in_laser_map]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tags_in_laser_map = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tags_in_laser_map[i] = TagPose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [tags_in_tag_map]
    // Deserialize array length for message field [tags_in_tag_map]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tags_in_tag_map = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tags_in_tag_map[i] = TagPose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [error_msgs]
    data.error_msgs = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.tags_in_laser_map.forEach((val) => {
      length += TagPose.getMessageSize(val);
    });
    object.tags_in_tag_map.forEach((val) => {
      length += TagPose.getMessageSize(val);
    });
    length += object.error_msgs.length;
    return length + 13;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/MapsAlignResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f599bc49abff90b93c9d358924994593';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    map_manager_msgs/TagPose[] tags_in_laser_map
    map_manager_msgs/TagPose[] tags_in_tag_map
    string error_msgs
    
    
    ================================================================================
    MSG: map_manager_msgs/TagPose
    int32 id
    geometry_msgs/Pose pose
    int32[] neighbors_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MapsAlignResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.tags_in_laser_map !== undefined) {
      resolved.tags_in_laser_map = new Array(msg.tags_in_laser_map.length);
      for (let i = 0; i < resolved.tags_in_laser_map.length; ++i) {
        resolved.tags_in_laser_map[i] = TagPose.Resolve(msg.tags_in_laser_map[i]);
      }
    }
    else {
      resolved.tags_in_laser_map = []
    }

    if (msg.tags_in_tag_map !== undefined) {
      resolved.tags_in_tag_map = new Array(msg.tags_in_tag_map.length);
      for (let i = 0; i < resolved.tags_in_tag_map.length; ++i) {
        resolved.tags_in_tag_map[i] = TagPose.Resolve(msg.tags_in_tag_map[i]);
      }
    }
    else {
      resolved.tags_in_tag_map = []
    }

    if (msg.error_msgs !== undefined) {
      resolved.error_msgs = msg.error_msgs;
    }
    else {
      resolved.error_msgs = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: MapsAlignRequest,
  Response: MapsAlignResponse,
  md5sum() { return 'b30ee66294f91e212acaa361eece6f30'; },
  datatype() { return 'map_manager_msgs/MapsAlign'; }
};
