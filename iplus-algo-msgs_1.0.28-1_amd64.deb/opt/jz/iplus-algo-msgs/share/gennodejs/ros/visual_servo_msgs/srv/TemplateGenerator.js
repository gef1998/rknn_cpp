// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PointArray = require('../msg/PointArray.js');
let LineArray = require('../msg/LineArray.js');

//-----------------------------------------------------------

let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class TemplateGeneratorRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.resolution = null;
      this.point_array = null;
      this.line_array = null;
      this.templete_path = null;
      this.configure_json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('resolution')) {
        this.resolution = initObj.resolution
      }
      else {
        this.resolution = 0.0;
      }
      if (initObj.hasOwnProperty('point_array')) {
        this.point_array = initObj.point_array
      }
      else {
        this.point_array = new PointArray();
      }
      if (initObj.hasOwnProperty('line_array')) {
        this.line_array = initObj.line_array
      }
      else {
        this.line_array = new LineArray();
      }
      if (initObj.hasOwnProperty('templete_path')) {
        this.templete_path = initObj.templete_path
      }
      else {
        this.templete_path = '';
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TemplateGeneratorRequest
    // Serialize message field [resolution]
    bufferOffset = _serializer.float32(obj.resolution, buffer, bufferOffset);
    // Serialize message field [point_array]
    bufferOffset = PointArray.serialize(obj.point_array, buffer, bufferOffset);
    // Serialize message field [line_array]
    bufferOffset = LineArray.serialize(obj.line_array, buffer, bufferOffset);
    // Serialize message field [templete_path]
    bufferOffset = _serializer.string(obj.templete_path, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TemplateGeneratorRequest
    let len;
    let data = new TemplateGeneratorRequest(null);
    // Deserialize message field [resolution]
    data.resolution = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [point_array]
    data.point_array = PointArray.deserialize(buffer, bufferOffset);
    // Deserialize message field [line_array]
    data.line_array = LineArray.deserialize(buffer, bufferOffset);
    // Deserialize message field [templete_path]
    data.templete_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += PointArray.getMessageSize(object.point_array);
    length += LineArray.getMessageSize(object.line_array);
    length += object.templete_path.length;
    length += object.configure_json_string.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/TemplateGeneratorRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '81c62ca96e896a7614a88eec714b772c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 resolution
    float32 DEFAULT_RESOLUTION = 0.002
    visual_servo_msgs/PointArray point_array
    visual_servo_msgs/LineArray line_array
    string templete_path
    string configure_json_string
    
    ================================================================================
    MSG: visual_servo_msgs/PointArray
    visual_servo_msgs/Point[] points
    
    ================================================================================
    MSG: visual_servo_msgs/Point
    float32 x
    float32 y
    float32 r
    
    ================================================================================
    MSG: visual_servo_msgs/LineArray
    visual_servo_msgs/Line[] lines
    
    ================================================================================
    MSG: visual_servo_msgs/Line
    visual_servo_msgs/Point[2] points
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TemplateGeneratorRequest(null);
    if (msg.resolution !== undefined) {
      resolved.resolution = msg.resolution;
    }
    else {
      resolved.resolution = 0.0
    }

    if (msg.point_array !== undefined) {
      resolved.point_array = PointArray.Resolve(msg.point_array)
    }
    else {
      resolved.point_array = new PointArray()
    }

    if (msg.line_array !== undefined) {
      resolved.line_array = LineArray.Resolve(msg.line_array)
    }
    else {
      resolved.line_array = new LineArray()
    }

    if (msg.templete_path !== undefined) {
      resolved.templete_path = msg.templete_path;
    }
    else {
      resolved.templete_path = ''
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    return resolved;
    }
};

// Constants for message
TemplateGeneratorRequest.Constants = {
  DEFAULT_RESOLUTION: 0.002,
}

class TemplateGeneratorResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.image = null;
      this.configure_json_string = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('image')) {
        this.image = initObj.image
      }
      else {
        this.image = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TemplateGeneratorResponse
    // Serialize message field [image]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.image, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TemplateGeneratorResponse
    let len;
    let data = new TemplateGeneratorResponse(null);
    // Deserialize message field [image]
    data.image = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += sensor_msgs.msg.Image.getMessageSize(object.image);
    length += object.configure_json_string.length;
    length += object.error_message.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/TemplateGeneratorResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '611cba5c85838d4fb8b7e8c6f25f51d6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    sensor_msgs/Image image
    string configure_json_string
    string error_message
    
    
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of cameara
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TemplateGeneratorResponse(null);
    if (msg.image !== undefined) {
      resolved.image = sensor_msgs.msg.Image.Resolve(msg.image)
    }
    else {
      resolved.image = new sensor_msgs.msg.Image()
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: TemplateGeneratorRequest,
  Response: TemplateGeneratorResponse,
  md5sum() { return '64deb1d23b1b78cab5abc3f0c35698e5'; },
  datatype() { return 'visual_servo_msgs/TemplateGenerator'; }
};
