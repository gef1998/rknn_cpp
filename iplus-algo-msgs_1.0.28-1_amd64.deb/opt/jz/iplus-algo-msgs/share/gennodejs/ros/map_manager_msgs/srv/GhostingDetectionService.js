// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let GhostingLines = require('../msg/GhostingLines.js');
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class GhostingDetectionServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.path = null;
    }
    else {
      if (initObj.hasOwnProperty('path')) {
        this.path = initObj.path
      }
      else {
        this.path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GhostingDetectionServiceRequest
    // Serialize message field [path]
    bufferOffset = _serializer.string(obj.path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GhostingDetectionServiceRequest
    let len;
    let data = new GhostingDetectionServiceRequest(null);
    // Deserialize message field [path]
    data.path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.path.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/GhostingDetectionServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1d00cd540af97efeb6b1589112fab63e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string path
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GhostingDetectionServiceRequest(null);
    if (msg.path !== undefined) {
      resolved.path = msg.path;
    }
    else {
      resolved.path = ''
    }

    return resolved;
    }
};

class GhostingDetectionServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.image = null;
      this.ghosting_lines = null;
      this.success = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('image')) {
        this.image = initObj.image
      }
      else {
        this.image = new sensor_msgs.msg.CompressedImage();
      }
      if (initObj.hasOwnProperty('ghosting_lines')) {
        this.ghosting_lines = initObj.ghosting_lines
      }
      else {
        this.ghosting_lines = [];
      }
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GhostingDetectionServiceResponse
    // Serialize message field [image]
    bufferOffset = sensor_msgs.msg.CompressedImage.serialize(obj.image, buffer, bufferOffset);
    // Serialize message field [ghosting_lines]
    // Serialize the length for message field [ghosting_lines]
    bufferOffset = _serializer.uint32(obj.ghosting_lines.length, buffer, bufferOffset);
    obj.ghosting_lines.forEach((val) => {
      bufferOffset = GhostingLines.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GhostingDetectionServiceResponse
    let len;
    let data = new GhostingDetectionServiceResponse(null);
    // Deserialize message field [image]
    data.image = sensor_msgs.msg.CompressedImage.deserialize(buffer, bufferOffset);
    // Deserialize message field [ghosting_lines]
    // Deserialize array length for message field [ghosting_lines]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.ghosting_lines = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.ghosting_lines[i] = GhostingLines.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += sensor_msgs.msg.CompressedImage.getMessageSize(object.image);
    length += 64 * object.ghosting_lines.length;
    length += object.error_message.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/GhostingDetectionServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '90926ff73a5de3cf33cfab246d3c4004';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    sensor_msgs/CompressedImage image
    map_manager_msgs/GhostingLines[] ghosting_lines
    bool success
    string error_message
    
    
    ================================================================================
    MSG: sensor_msgs/CompressedImage
    # This message contains a compressed image
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of cameara
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
    
    string format        # Specifies the format of the data
                         #   Acceptable values:
                         #     jpeg, png
    uint8[] data         # Compressed image buffer
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: map_manager_msgs/GhostingLines
    map_manager_msgs/LinePoints2d firstLine
    map_manager_msgs/LinePoints2d secondLine
    ================================================================================
    MSG: map_manager_msgs/LinePoints2d
    map_manager_msgs/Point2d startPoint
    map_manager_msgs/Point2d endPoint
    ================================================================================
    MSG: map_manager_msgs/Point2d
    float64 x
    float64 y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GhostingDetectionServiceResponse(null);
    if (msg.image !== undefined) {
      resolved.image = sensor_msgs.msg.CompressedImage.Resolve(msg.image)
    }
    else {
      resolved.image = new sensor_msgs.msg.CompressedImage()
    }

    if (msg.ghosting_lines !== undefined) {
      resolved.ghosting_lines = new Array(msg.ghosting_lines.length);
      for (let i = 0; i < resolved.ghosting_lines.length; ++i) {
        resolved.ghosting_lines[i] = GhostingLines.Resolve(msg.ghosting_lines[i]);
      }
    }
    else {
      resolved.ghosting_lines = []
    }

    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GhostingDetectionServiceRequest,
  Response: GhostingDetectionServiceResponse,
  md5sum() { return '46d13b1a30e225a4be68b391bcef0403'; },
  datatype() { return 'map_manager_msgs/GhostingDetectionService'; }
};
