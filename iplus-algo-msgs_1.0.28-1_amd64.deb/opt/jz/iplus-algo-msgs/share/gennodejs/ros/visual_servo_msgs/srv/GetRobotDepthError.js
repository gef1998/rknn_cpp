// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class GetRobotDepthErrorRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.teaching_pose = null;
      this.dock_type = null;
      this.configure_json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('teaching_pose')) {
        this.teaching_pose = initObj.teaching_pose
      }
      else {
        this.teaching_pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('dock_type')) {
        this.dock_type = initObj.dock_type
      }
      else {
        this.dock_type = 0;
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetRobotDepthErrorRequest
    // Serialize message field [teaching_pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.teaching_pose, buffer, bufferOffset);
    // Serialize message field [dock_type]
    bufferOffset = _serializer.int32(obj.dock_type, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetRobotDepthErrorRequest
    let len;
    let data = new GetRobotDepthErrorRequest(null);
    // Deserialize message field [teaching_pose]
    data.teaching_pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [dock_type]
    data.dock_type = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.configure_json_string.length;
    return length + 64;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/GetRobotDepthErrorRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '22bf8789b99a6ddede650ead0164bf1e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Pose teaching_pose
    int32 dock_type
    string configure_json_string
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetRobotDepthErrorRequest(null);
    if (msg.teaching_pose !== undefined) {
      resolved.teaching_pose = geometry_msgs.msg.Pose.Resolve(msg.teaching_pose)
    }
    else {
      resolved.teaching_pose = new geometry_msgs.msg.Pose()
    }

    if (msg.dock_type !== undefined) {
      resolved.dock_type = msg.dock_type;
    }
    else {
      resolved.dock_type = 0
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    return resolved;
    }
};

class GetRobotDepthErrorResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.depth_error = null;
      this.configure_json_string = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('depth_error')) {
        this.depth_error = initObj.depth_error
      }
      else {
        this.depth_error = 0.0;
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetRobotDepthErrorResponse
    // Serialize message field [depth_error]
    bufferOffset = _serializer.float32(obj.depth_error, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetRobotDepthErrorResponse
    let len;
    let data = new GetRobotDepthErrorResponse(null);
    // Deserialize message field [depth_error]
    data.depth_error = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.configure_json_string.length;
    length += object.error_message.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/GetRobotDepthErrorResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '469ccc1ea2fd3bb2a76434e855c78540';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 depth_error
    string configure_json_string
    string error_message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetRobotDepthErrorResponse(null);
    if (msg.depth_error !== undefined) {
      resolved.depth_error = msg.depth_error;
    }
    else {
      resolved.depth_error = 0.0
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GetRobotDepthErrorRequest,
  Response: GetRobotDepthErrorResponse,
  md5sum() { return 'e17ac42b79be87399ab2f391a3ee8421'; },
  datatype() { return 'visual_servo_msgs/GetRobotDepthError'; }
};
