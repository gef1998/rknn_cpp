// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Model3DPose = require('./Model3DPose.js');

//-----------------------------------------------------------

class Model3DPoseArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.model_pose_array = null;
    }
    else {
      if (initObj.hasOwnProperty('model_pose_array')) {
        this.model_pose_array = initObj.model_pose_array
      }
      else {
        this.model_pose_array = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Model3DPoseArray
    // Serialize message field [model_pose_array]
    // Serialize the length for message field [model_pose_array]
    bufferOffset = _serializer.uint32(obj.model_pose_array.length, buffer, bufferOffset);
    obj.model_pose_array.forEach((val) => {
      bufferOffset = Model3DPose.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Model3DPoseArray
    let len;
    let data = new Model3DPoseArray(null);
    // Deserialize message field [model_pose_array]
    // Deserialize array length for message field [model_pose_array]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.model_pose_array = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.model_pose_array[i] = Model3DPose.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.model_pose_array.forEach((val) => {
      length += Model3DPose.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'visual_servo_msgs/Model3DPoseArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '80fad10082b452aa4ba8554ad1d60f5c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    visual_servo_msgs/Model3DPose[] model_pose_array
    
    ================================================================================
    MSG: visual_servo_msgs/Model3DPose
    string model_name
    bool valid
    geometry_msgs/Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Model3DPoseArray(null);
    if (msg.model_pose_array !== undefined) {
      resolved.model_pose_array = new Array(msg.model_pose_array.length);
      for (let i = 0; i < resolved.model_pose_array.length; ++i) {
        resolved.model_pose_array[i] = Model3DPose.Resolve(msg.model_pose_array[i]);
      }
    }
    else {
      resolved.model_pose_array = []
    }

    return resolved;
    }
};

module.exports = Model3DPoseArray;
