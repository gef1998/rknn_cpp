// Auto-generated. Do not edit!

// (in-package sensors_check_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let MarkerSets = require('../msg/MarkerSets.js');

//-----------------------------------------------------------

class getMarerSetsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type getMarerSetsRequest
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type getMarerSetsRequest
    let len;
    let data = new getMarerSetsRequest(null);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.json_string.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'sensors_check_msgs/getMarerSetsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '99611b8ec56704fa6a4948fbcc54e25b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string json_string
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new getMarerSetsRequest(null);
    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

class getMarerSetsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.succeed = null;
      this.message = null;
      this.markersets = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('succeed')) {
        this.succeed = initObj.succeed
      }
      else {
        this.succeed = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('markersets')) {
        this.markersets = initObj.markersets
      }
      else {
        this.markersets = new MarkerSets();
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type getMarerSetsResponse
    // Serialize message field [succeed]
    bufferOffset = _serializer.bool(obj.succeed, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [markersets]
    bufferOffset = MarkerSets.serialize(obj.markersets, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type getMarerSetsResponse
    let len;
    let data = new getMarerSetsResponse(null);
    // Deserialize message field [succeed]
    data.succeed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [markersets]
    data.markersets = MarkerSets.deserialize(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    length += MarkerSets.getMessageSize(object.markersets);
    length += object.json_string.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'sensors_check_msgs/getMarerSetsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f129bec18c0a171c533b5178414558ae';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool succeed
    string message
    sensors_check_msgs/MarkerSets markersets
    string json_string
    
    
    
    ================================================================================
    MSG: sensors_check_msgs/MarkerSets
    std_msgs/Header header
    sensors_check_msgs/MarkerSet[] marker_sets
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: sensors_check_msgs/MarkerSet
    std_msgs/Header header
    int32 frame_id
    string marker_set_name
    sensors_check_msgs/Marker[] markers
    
    
    
    
    
    ================================================================================
    MSG: sensors_check_msgs/Marker
    std_msgs/Header header
    int32 id
    float32[3] pose
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new getMarerSetsResponse(null);
    if (msg.succeed !== undefined) {
      resolved.succeed = msg.succeed;
    }
    else {
      resolved.succeed = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.markersets !== undefined) {
      resolved.markersets = MarkerSets.Resolve(msg.markersets)
    }
    else {
      resolved.markersets = new MarkerSets()
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: getMarerSetsRequest,
  Response: getMarerSetsResponse,
  md5sum() { return '3d0a4e8ee018d76cf6afd0fdda8ca0f8'; },
  datatype() { return 'sensors_check_msgs/getMarerSets'; }
};
