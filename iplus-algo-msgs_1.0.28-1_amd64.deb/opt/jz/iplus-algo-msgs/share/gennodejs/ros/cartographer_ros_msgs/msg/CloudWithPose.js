// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class CloudWithPose {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.local_pose = null;
      this.lidar2base_poses = null;
      this.clouds = null;
      this.manual_valid = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('local_pose')) {
        this.local_pose = initObj.local_pose
      }
      else {
        this.local_pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('lidar2base_poses')) {
        this.lidar2base_poses = initObj.lidar2base_poses
      }
      else {
        this.lidar2base_poses = [];
      }
      if (initObj.hasOwnProperty('clouds')) {
        this.clouds = initObj.clouds
      }
      else {
        this.clouds = [];
      }
      if (initObj.hasOwnProperty('manual_valid')) {
        this.manual_valid = initObj.manual_valid
      }
      else {
        this.manual_valid = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CloudWithPose
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [local_pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.local_pose, buffer, bufferOffset);
    // Serialize message field [lidar2base_poses]
    // Serialize the length for message field [lidar2base_poses]
    bufferOffset = _serializer.uint32(obj.lidar2base_poses.length, buffer, bufferOffset);
    obj.lidar2base_poses.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [clouds]
    // Serialize the length for message field [clouds]
    bufferOffset = _serializer.uint32(obj.clouds.length, buffer, bufferOffset);
    obj.clouds.forEach((val) => {
      bufferOffset = sensor_msgs.msg.PointCloud2.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [manual_valid]
    bufferOffset = _serializer.bool(obj.manual_valid, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CloudWithPose
    let len;
    let data = new CloudWithPose(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [local_pose]
    data.local_pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [lidar2base_poses]
    // Deserialize array length for message field [lidar2base_poses]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.lidar2base_poses = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.lidar2base_poses[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [clouds]
    // Deserialize array length for message field [clouds]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.clouds = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.clouds[i] = sensor_msgs.msg.PointCloud2.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [manual_valid]
    data.manual_valid = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += 56 * object.lidar2base_poses.length;
    object.clouds.forEach((val) => {
      length += sensor_msgs.msg.PointCloud2.getMessageSize(val);
    });
    return length + 65;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/CloudWithPose';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8d7436353928b6fd744b6ddaf3a2a917';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    geometry_msgs/Pose local_pose
    geometry_msgs/Pose[] lidar2base_poses
    sensor_msgs/PointCloud2[] clouds
    bool manual_valid
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensor_msgs/PointCloud2
    # This message holds a collection of N-dimensional points, which may
    # contain additional information such as normals, intensity, etc. The
    # point data is stored as a binary blob, its layout described by the
    # contents of the "fields" array.
    
    # The point cloud data may be organized 2d (image-like) or 1d
    # (unordered). Point clouds organized as 2d images may be produced by
    # camera depth sensors such as stereo or time-of-flight.
    
    # Time of sensor data acquisition, and the coordinate frame ID (for 3d
    # points).
    Header header
    
    # 2D structure of the point cloud. If the cloud is unordered, height is
    # 1 and width is the length of the point cloud.
    uint32 height
    uint32 width
    
    # Describes the channels and their layout in the binary data blob.
    PointField[] fields
    
    bool    is_bigendian # Is this data bigendian?
    uint32  point_step   # Length of a point in bytes
    uint32  row_step     # Length of a row in bytes
    uint8[] data         # Actual point data, size is (row_step*height)
    
    bool is_dense        # True if there are no invalid points
    
    ================================================================================
    MSG: sensor_msgs/PointField
    # This message holds the description of one point entry in the
    # PointCloud2 message format.
    uint8 INT8    = 1
    uint8 UINT8   = 2
    uint8 INT16   = 3
    uint8 UINT16  = 4
    uint8 INT32   = 5
    uint8 UINT32  = 6
    uint8 FLOAT32 = 7
    uint8 FLOAT64 = 8
    
    string name      # Name of field
    uint32 offset    # Offset from start of point struct
    uint8  datatype  # Datatype enumeration, see above
    uint32 count     # How many elements in the field
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CloudWithPose(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.local_pose !== undefined) {
      resolved.local_pose = geometry_msgs.msg.Pose.Resolve(msg.local_pose)
    }
    else {
      resolved.local_pose = new geometry_msgs.msg.Pose()
    }

    if (msg.lidar2base_poses !== undefined) {
      resolved.lidar2base_poses = new Array(msg.lidar2base_poses.length);
      for (let i = 0; i < resolved.lidar2base_poses.length; ++i) {
        resolved.lidar2base_poses[i] = geometry_msgs.msg.Pose.Resolve(msg.lidar2base_poses[i]);
      }
    }
    else {
      resolved.lidar2base_poses = []
    }

    if (msg.clouds !== undefined) {
      resolved.clouds = new Array(msg.clouds.length);
      for (let i = 0; i < resolved.clouds.length; ++i) {
        resolved.clouds[i] = sensor_msgs.msg.PointCloud2.Resolve(msg.clouds[i]);
      }
    }
    else {
      resolved.clouds = []
    }

    if (msg.manual_valid !== undefined) {
      resolved.manual_valid = msg.manual_valid;
    }
    else {
      resolved.manual_valid = false
    }

    return resolved;
    }
};

module.exports = CloudWithPose;
