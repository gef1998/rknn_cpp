// Auto-generated. Do not edit!

// (in-package vtr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetParamsRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.laser_localization_enabled = null;
    }
    else {
      if (initObj.hasOwnProperty('laser_localization_enabled')) {
        this.laser_localization_enabled = initObj.laser_localization_enabled
      }
      else {
        this.laser_localization_enabled = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetParamsRequest
    // Serialize message field [laser_localization_enabled]
    bufferOffset = _serializer.bool(obj.laser_localization_enabled, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetParamsRequest
    let len;
    let data = new SetParamsRequest(null);
    // Deserialize message field [laser_localization_enabled]
    data.laser_localization_enabled = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/SetParamsRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd07ae5391c50949dddbf617b2a229b98';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    bool laser_localization_enabled
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetParamsRequest(null);
    if (msg.laser_localization_enabled !== undefined) {
      resolved.laser_localization_enabled = msg.laser_localization_enabled;
    }
    else {
      resolved.laser_localization_enabled = false
    }

    return resolved;
    }
};

class SetParamsResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetParamsResponse
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetParamsResponse
    let len;
    let data = new SetParamsResponse(null);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_message.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'vtr_msgs/SetParamsResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a13979422fc129b30b15994450a302b5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string error_message
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetParamsResponse(null);
    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SetParamsRequest,
  Response: SetParamsResponse,
  md5sum() { return '947c332a3454846492cdda8fba55edc7'; },
  datatype() { return 'vtr_msgs/SetParams'; }
};
