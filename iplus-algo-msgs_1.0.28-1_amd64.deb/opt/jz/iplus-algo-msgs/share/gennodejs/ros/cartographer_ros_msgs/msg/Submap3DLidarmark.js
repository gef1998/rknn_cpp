// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LasermarkEntry = require('./LasermarkEntry.js');
let Submap3D = require('./Submap3D.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Submap3DLidarmark {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.landmarks_in_map = null;
      this.landmarks_in_odom = null;
      this.submap = null;
      this.use_lidar_localization = null;
      this.debug_flag = null;
      this.localization_type = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('landmarks_in_map')) {
        this.landmarks_in_map = initObj.landmarks_in_map
      }
      else {
        this.landmarks_in_map = [];
      }
      if (initObj.hasOwnProperty('landmarks_in_odom')) {
        this.landmarks_in_odom = initObj.landmarks_in_odom
      }
      else {
        this.landmarks_in_odom = [];
      }
      if (initObj.hasOwnProperty('submap')) {
        this.submap = initObj.submap
      }
      else {
        this.submap = new Submap3D();
      }
      if (initObj.hasOwnProperty('use_lidar_localization')) {
        this.use_lidar_localization = initObj.use_lidar_localization
      }
      else {
        this.use_lidar_localization = false;
      }
      if (initObj.hasOwnProperty('debug_flag')) {
        this.debug_flag = initObj.debug_flag
      }
      else {
        this.debug_flag = false;
      }
      if (initObj.hasOwnProperty('localization_type')) {
        this.localization_type = initObj.localization_type
      }
      else {
        this.localization_type = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Submap3DLidarmark
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [landmarks_in_map]
    // Serialize the length for message field [landmarks_in_map]
    bufferOffset = _serializer.uint32(obj.landmarks_in_map.length, buffer, bufferOffset);
    obj.landmarks_in_map.forEach((val) => {
      bufferOffset = LasermarkEntry.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [landmarks_in_odom]
    // Serialize the length for message field [landmarks_in_odom]
    bufferOffset = _serializer.uint32(obj.landmarks_in_odom.length, buffer, bufferOffset);
    obj.landmarks_in_odom.forEach((val) => {
      bufferOffset = LasermarkEntry.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [submap]
    bufferOffset = Submap3D.serialize(obj.submap, buffer, bufferOffset);
    // Serialize message field [use_lidar_localization]
    bufferOffset = _serializer.bool(obj.use_lidar_localization, buffer, bufferOffset);
    // Serialize message field [debug_flag]
    bufferOffset = _serializer.bool(obj.debug_flag, buffer, bufferOffset);
    // Serialize message field [localization_type]
    bufferOffset = _serializer.string(obj.localization_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Submap3DLidarmark
    let len;
    let data = new Submap3DLidarmark(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [landmarks_in_map]
    // Deserialize array length for message field [landmarks_in_map]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.landmarks_in_map = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.landmarks_in_map[i] = LasermarkEntry.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [landmarks_in_odom]
    // Deserialize array length for message field [landmarks_in_odom]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.landmarks_in_odom = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.landmarks_in_odom[i] = LasermarkEntry.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [submap]
    data.submap = Submap3D.deserialize(buffer, bufferOffset);
    // Deserialize message field [use_lidar_localization]
    data.use_lidar_localization = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [debug_flag]
    data.debug_flag = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [localization_type]
    data.localization_type = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.landmarks_in_map.forEach((val) => {
      length += LasermarkEntry.getMessageSize(val);
    });
    object.landmarks_in_odom.forEach((val) => {
      length += LasermarkEntry.getMessageSize(val);
    });
    length += Submap3D.getMessageSize(object.submap);
    length += object.localization_type.length;
    return length + 14;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/Submap3DLidarmark';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'aa7ab3549e50e48113f718a109c93a79';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    cartographer_ros_msgs/LasermarkEntry[] landmarks_in_map
    cartographer_ros_msgs/LasermarkEntry[] landmarks_in_odom
    cartographer_ros_msgs/Submap3D submap
    bool use_lidar_localization
    bool debug_flag
    string localization_type
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: cartographer_ros_msgs/LasermarkEntry
    string id
    float64 x
    float64 y
    float64 z
    float64 normal_x
    float64 normal_y
    float64 normal_z
    float32 pole_radius
    
    ================================================================================
    MSG: cartographer_ros_msgs/Submap3D
    std_msgs/Header header
    string submap
    bool manual_valid
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Submap3DLidarmark(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.landmarks_in_map !== undefined) {
      resolved.landmarks_in_map = new Array(msg.landmarks_in_map.length);
      for (let i = 0; i < resolved.landmarks_in_map.length; ++i) {
        resolved.landmarks_in_map[i] = LasermarkEntry.Resolve(msg.landmarks_in_map[i]);
      }
    }
    else {
      resolved.landmarks_in_map = []
    }

    if (msg.landmarks_in_odom !== undefined) {
      resolved.landmarks_in_odom = new Array(msg.landmarks_in_odom.length);
      for (let i = 0; i < resolved.landmarks_in_odom.length; ++i) {
        resolved.landmarks_in_odom[i] = LasermarkEntry.Resolve(msg.landmarks_in_odom[i]);
      }
    }
    else {
      resolved.landmarks_in_odom = []
    }

    if (msg.submap !== undefined) {
      resolved.submap = Submap3D.Resolve(msg.submap)
    }
    else {
      resolved.submap = new Submap3D()
    }

    if (msg.use_lidar_localization !== undefined) {
      resolved.use_lidar_localization = msg.use_lidar_localization;
    }
    else {
      resolved.use_lidar_localization = false
    }

    if (msg.debug_flag !== undefined) {
      resolved.debug_flag = msg.debug_flag;
    }
    else {
      resolved.debug_flag = false
    }

    if (msg.localization_type !== undefined) {
      resolved.localization_type = msg.localization_type;
    }
    else {
      resolved.localization_type = ''
    }

    return resolved;
    }
};

module.exports = Submap3DLidarmark;
