// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class DualCameraInitialPoseRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.status = null;
      this.refCam2curCam = null;
      this.refBase2Map = null;
      this.left_image = null;
      this.right_image = null;
      this.configure_json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = false;
      }
      if (initObj.hasOwnProperty('refCam2curCam')) {
        this.refCam2curCam = initObj.refCam2curCam
      }
      else {
        this.refCam2curCam = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('refBase2Map')) {
        this.refBase2Map = initObj.refBase2Map
      }
      else {
        this.refBase2Map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('left_image')) {
        this.left_image = initObj.left_image
      }
      else {
        this.left_image = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('right_image')) {
        this.right_image = initObj.right_image
      }
      else {
        this.right_image = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DualCameraInitialPoseRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.bool(obj.status, buffer, bufferOffset);
    // Serialize message field [refCam2curCam]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.refCam2curCam, buffer, bufferOffset);
    // Serialize message field [refBase2Map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.refBase2Map, buffer, bufferOffset);
    // Serialize message field [left_image]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.left_image, buffer, bufferOffset);
    // Serialize message field [right_image]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.right_image, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DualCameraInitialPoseRequest
    let len;
    let data = new DualCameraInitialPoseRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [refCam2curCam]
    data.refCam2curCam = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [refBase2Map]
    data.refBase2Map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [left_image]
    data.left_image = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [right_image]
    data.right_image = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += sensor_msgs.msg.Image.getMessageSize(object.left_image);
    length += sensor_msgs.msg.Image.getMessageSize(object.right_image);
    length += object.configure_json_string.length;
    return length + 117;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/DualCameraInitialPoseRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'deb62853f4bf4fd50819995e46d04046';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    bool status
    geometry_msgs/Pose refCam2curCam
    geometry_msgs/Pose refBase2Map
    sensor_msgs/Image left_image
    sensor_msgs/Image right_image
    
    string configure_json_string
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of cameara
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DualCameraInitialPoseRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = false
    }

    if (msg.refCam2curCam !== undefined) {
      resolved.refCam2curCam = geometry_msgs.msg.Pose.Resolve(msg.refCam2curCam)
    }
    else {
      resolved.refCam2curCam = new geometry_msgs.msg.Pose()
    }

    if (msg.refBase2Map !== undefined) {
      resolved.refBase2Map = geometry_msgs.msg.Pose.Resolve(msg.refBase2Map)
    }
    else {
      resolved.refBase2Map = new geometry_msgs.msg.Pose()
    }

    if (msg.left_image !== undefined) {
      resolved.left_image = sensor_msgs.msg.Image.Resolve(msg.left_image)
    }
    else {
      resolved.left_image = new sensor_msgs.msg.Image()
    }

    if (msg.right_image !== undefined) {
      resolved.right_image = sensor_msgs.msg.Image.Resolve(msg.right_image)
    }
    else {
      resolved.right_image = new sensor_msgs.msg.Image()
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    return resolved;
    }
};

class DualCameraInitialPoseResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.configure_json_string = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DualCameraInitialPoseResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DualCameraInitialPoseResponse
    let len;
    let data = new DualCameraInitialPoseResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.configure_json_string.length;
    length += object.error_message.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/DualCameraInitialPoseResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '080e76f0f5daf29d2ea03560665fa0da';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    string configure_json_string
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DualCameraInitialPoseResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: DualCameraInitialPoseRequest,
  Response: DualCameraInitialPoseResponse,
  md5sum() { return '4653473c50298cf8fcf7ae4222949dc0'; },
  datatype() { return 'visual_servo_msgs/DualCameraInitialPose'; }
};
