// Auto-generated. Do not edit!

// (in-package poslvx.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Status = require('./Status.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class INS {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.status = null;
      this.latitude = null;
      this.longitude = null;
      this.altitude = null;
      this.north_velocity = null;
      this.east_velocity = null;
      this.down_velocity = null;
      this.total_speed = null;
      this.roll = null;
      this.pitch = null;
      this.heading = null;
      this.track_angle = null;
      this.angular_rate_x = null;
      this.angular_rate_y = null;
      this.angular_rate_z = null;
      this.acceleration_x = null;
      this.acceleration_y = null;
      this.acceleration_z = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = new Status();
      }
      if (initObj.hasOwnProperty('latitude')) {
        this.latitude = initObj.latitude
      }
      else {
        this.latitude = 0.0;
      }
      if (initObj.hasOwnProperty('longitude')) {
        this.longitude = initObj.longitude
      }
      else {
        this.longitude = 0.0;
      }
      if (initObj.hasOwnProperty('altitude')) {
        this.altitude = initObj.altitude
      }
      else {
        this.altitude = 0.0;
      }
      if (initObj.hasOwnProperty('north_velocity')) {
        this.north_velocity = initObj.north_velocity
      }
      else {
        this.north_velocity = 0.0;
      }
      if (initObj.hasOwnProperty('east_velocity')) {
        this.east_velocity = initObj.east_velocity
      }
      else {
        this.east_velocity = 0.0;
      }
      if (initObj.hasOwnProperty('down_velocity')) {
        this.down_velocity = initObj.down_velocity
      }
      else {
        this.down_velocity = 0.0;
      }
      if (initObj.hasOwnProperty('total_speed')) {
        this.total_speed = initObj.total_speed
      }
      else {
        this.total_speed = 0.0;
      }
      if (initObj.hasOwnProperty('roll')) {
        this.roll = initObj.roll
      }
      else {
        this.roll = 0.0;
      }
      if (initObj.hasOwnProperty('pitch')) {
        this.pitch = initObj.pitch
      }
      else {
        this.pitch = 0.0;
      }
      if (initObj.hasOwnProperty('heading')) {
        this.heading = initObj.heading
      }
      else {
        this.heading = 0.0;
      }
      if (initObj.hasOwnProperty('track_angle')) {
        this.track_angle = initObj.track_angle
      }
      else {
        this.track_angle = 0.0;
      }
      if (initObj.hasOwnProperty('angular_rate_x')) {
        this.angular_rate_x = initObj.angular_rate_x
      }
      else {
        this.angular_rate_x = 0.0;
      }
      if (initObj.hasOwnProperty('angular_rate_y')) {
        this.angular_rate_y = initObj.angular_rate_y
      }
      else {
        this.angular_rate_y = 0.0;
      }
      if (initObj.hasOwnProperty('angular_rate_z')) {
        this.angular_rate_z = initObj.angular_rate_z
      }
      else {
        this.angular_rate_z = 0.0;
      }
      if (initObj.hasOwnProperty('acceleration_x')) {
        this.acceleration_x = initObj.acceleration_x
      }
      else {
        this.acceleration_x = 0.0;
      }
      if (initObj.hasOwnProperty('acceleration_y')) {
        this.acceleration_y = initObj.acceleration_y
      }
      else {
        this.acceleration_y = 0.0;
      }
      if (initObj.hasOwnProperty('acceleration_z')) {
        this.acceleration_z = initObj.acceleration_z
      }
      else {
        this.acceleration_z = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type INS
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = Status.serialize(obj.status, buffer, bufferOffset);
    // Serialize message field [latitude]
    bufferOffset = _serializer.float64(obj.latitude, buffer, bufferOffset);
    // Serialize message field [longitude]
    bufferOffset = _serializer.float64(obj.longitude, buffer, bufferOffset);
    // Serialize message field [altitude]
    bufferOffset = _serializer.float64(obj.altitude, buffer, bufferOffset);
    // Serialize message field [north_velocity]
    bufferOffset = _serializer.float32(obj.north_velocity, buffer, bufferOffset);
    // Serialize message field [east_velocity]
    bufferOffset = _serializer.float32(obj.east_velocity, buffer, bufferOffset);
    // Serialize message field [down_velocity]
    bufferOffset = _serializer.float32(obj.down_velocity, buffer, bufferOffset);
    // Serialize message field [total_speed]
    bufferOffset = _serializer.float32(obj.total_speed, buffer, bufferOffset);
    // Serialize message field [roll]
    bufferOffset = _serializer.float64(obj.roll, buffer, bufferOffset);
    // Serialize message field [pitch]
    bufferOffset = _serializer.float64(obj.pitch, buffer, bufferOffset);
    // Serialize message field [heading]
    bufferOffset = _serializer.float64(obj.heading, buffer, bufferOffset);
    // Serialize message field [track_angle]
    bufferOffset = _serializer.float64(obj.track_angle, buffer, bufferOffset);
    // Serialize message field [angular_rate_x]
    bufferOffset = _serializer.float32(obj.angular_rate_x, buffer, bufferOffset);
    // Serialize message field [angular_rate_y]
    bufferOffset = _serializer.float32(obj.angular_rate_y, buffer, bufferOffset);
    // Serialize message field [angular_rate_z]
    bufferOffset = _serializer.float32(obj.angular_rate_z, buffer, bufferOffset);
    // Serialize message field [acceleration_x]
    bufferOffset = _serializer.float32(obj.acceleration_x, buffer, bufferOffset);
    // Serialize message field [acceleration_y]
    bufferOffset = _serializer.float32(obj.acceleration_y, buffer, bufferOffset);
    // Serialize message field [acceleration_z]
    bufferOffset = _serializer.float32(obj.acceleration_z, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type INS
    let len;
    let data = new INS(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = Status.deserialize(buffer, bufferOffset);
    // Deserialize message field [latitude]
    data.latitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [longitude]
    data.longitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [altitude]
    data.altitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [north_velocity]
    data.north_velocity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [east_velocity]
    data.east_velocity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [down_velocity]
    data.down_velocity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [total_speed]
    data.total_speed = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [roll]
    data.roll = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pitch]
    data.pitch = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [heading]
    data.heading = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [track_angle]
    data.track_angle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [angular_rate_x]
    data.angular_rate_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [angular_rate_y]
    data.angular_rate_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [angular_rate_z]
    data.angular_rate_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [acceleration_x]
    data.acceleration_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [acceleration_y]
    data.acceleration_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [acceleration_z]
    data.acceleration_z = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 104;
  }

  static datatype() {
    // Returns string type for a message object
    return 'poslvx/INS';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b74c8dc8833f5f93d95883ed61d8a4a5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    Status status
    
    float64 latitude
    float64 longitude
    float64 altitude
    float32 north_velocity
    float32 east_velocity
    float32 down_velocity
    float32 total_speed
    float64 roll
    float64 pitch
    float64 heading
    float64 track_angle
    float32 angular_rate_x
    float32 angular_rate_y
    float32 angular_rate_z
    float32 acceleration_x
    float32 acceleration_y
    float32 acceleration_z
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: poslvx/Status
    
    int16 gps_week
    uint32 gps_time
    uint8 imu_alignment_status
    uint8 gnss_status
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new INS(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.status !== undefined) {
      resolved.status = Status.Resolve(msg.status)
    }
    else {
      resolved.status = new Status()
    }

    if (msg.latitude !== undefined) {
      resolved.latitude = msg.latitude;
    }
    else {
      resolved.latitude = 0.0
    }

    if (msg.longitude !== undefined) {
      resolved.longitude = msg.longitude;
    }
    else {
      resolved.longitude = 0.0
    }

    if (msg.altitude !== undefined) {
      resolved.altitude = msg.altitude;
    }
    else {
      resolved.altitude = 0.0
    }

    if (msg.north_velocity !== undefined) {
      resolved.north_velocity = msg.north_velocity;
    }
    else {
      resolved.north_velocity = 0.0
    }

    if (msg.east_velocity !== undefined) {
      resolved.east_velocity = msg.east_velocity;
    }
    else {
      resolved.east_velocity = 0.0
    }

    if (msg.down_velocity !== undefined) {
      resolved.down_velocity = msg.down_velocity;
    }
    else {
      resolved.down_velocity = 0.0
    }

    if (msg.total_speed !== undefined) {
      resolved.total_speed = msg.total_speed;
    }
    else {
      resolved.total_speed = 0.0
    }

    if (msg.roll !== undefined) {
      resolved.roll = msg.roll;
    }
    else {
      resolved.roll = 0.0
    }

    if (msg.pitch !== undefined) {
      resolved.pitch = msg.pitch;
    }
    else {
      resolved.pitch = 0.0
    }

    if (msg.heading !== undefined) {
      resolved.heading = msg.heading;
    }
    else {
      resolved.heading = 0.0
    }

    if (msg.track_angle !== undefined) {
      resolved.track_angle = msg.track_angle;
    }
    else {
      resolved.track_angle = 0.0
    }

    if (msg.angular_rate_x !== undefined) {
      resolved.angular_rate_x = msg.angular_rate_x;
    }
    else {
      resolved.angular_rate_x = 0.0
    }

    if (msg.angular_rate_y !== undefined) {
      resolved.angular_rate_y = msg.angular_rate_y;
    }
    else {
      resolved.angular_rate_y = 0.0
    }

    if (msg.angular_rate_z !== undefined) {
      resolved.angular_rate_z = msg.angular_rate_z;
    }
    else {
      resolved.angular_rate_z = 0.0
    }

    if (msg.acceleration_x !== undefined) {
      resolved.acceleration_x = msg.acceleration_x;
    }
    else {
      resolved.acceleration_x = 0.0
    }

    if (msg.acceleration_y !== undefined) {
      resolved.acceleration_y = msg.acceleration_y;
    }
    else {
      resolved.acceleration_y = 0.0
    }

    if (msg.acceleration_z !== undefined) {
      resolved.acceleration_z = msg.acceleration_z;
    }
    else {
      resolved.acceleration_z = 0.0
    }

    return resolved;
    }
};

module.exports = INS;
