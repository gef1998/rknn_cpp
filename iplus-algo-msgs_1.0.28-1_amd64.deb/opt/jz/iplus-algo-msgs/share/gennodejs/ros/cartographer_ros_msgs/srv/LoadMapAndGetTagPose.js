// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let LandmarkNewEntry = require('../msg/LandmarkNewEntry.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class LoadMapAndGetTagPoseRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.map_name = null;
    }
    else {
      if (initObj.hasOwnProperty('map_name')) {
        this.map_name = initObj.map_name
      }
      else {
        this.map_name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LoadMapAndGetTagPoseRequest
    // Serialize message field [map_name]
    bufferOffset = _serializer.string(obj.map_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LoadMapAndGetTagPoseRequest
    let len;
    let data = new LoadMapAndGetTagPoseRequest(null);
    // Deserialize message field [map_name]
    data.map_name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.map_name.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/LoadMapAndGetTagPoseRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '25e928a2d4ff388c294895b7af935978';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string map_name
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LoadMapAndGetTagPoseRequest(null);
    if (msg.map_name !== undefined) {
      resolved.map_name = msg.map_name;
    }
    else {
      resolved.map_name = ''
    }

    return resolved;
    }
};

class LoadMapAndGetTagPoseResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tag_pose = null;
      this.landmarks = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('tag_pose')) {
        this.tag_pose = initObj.tag_pose
      }
      else {
        this.tag_pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('landmarks')) {
        this.landmarks = initObj.landmarks
      }
      else {
        this.landmarks = [];
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LoadMapAndGetTagPoseResponse
    // Serialize message field [tag_pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.tag_pose, buffer, bufferOffset);
    // Serialize message field [landmarks]
    // Serialize the length for message field [landmarks]
    bufferOffset = _serializer.uint32(obj.landmarks.length, buffer, bufferOffset);
    obj.landmarks.forEach((val) => {
      bufferOffset = LandmarkNewEntry.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LoadMapAndGetTagPoseResponse
    let len;
    let data = new LoadMapAndGetTagPoseResponse(null);
    // Deserialize message field [tag_pose]
    data.tag_pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [landmarks]
    // Deserialize array length for message field [landmarks]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.landmarks = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.landmarks[i] = LandmarkNewEntry.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.landmarks.forEach((val) => {
      length += LandmarkNewEntry.getMessageSize(val);
    });
    length += object.error_message.length;
    return length + 64;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/LoadMapAndGetTagPoseResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd25a039d7acfd64d72544fa1adbd1357';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    geometry_msgs/Pose tag_pose
    cartographer_ros_msgs/LandmarkNewEntry[]  landmarks
    string error_message
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: cartographer_ros_msgs/LandmarkNewEntry
    # 2018 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    string ns
    string id
    int32 visible
    float64 normal_x
    float64 normal_y
    float64 normal_z
    geometry_msgs/Pose tracking_from_landmark_transform
    float64 translation_weight
    float64 rotation_weight
    float64 pole_radius
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LoadMapAndGetTagPoseResponse(null);
    if (msg.tag_pose !== undefined) {
      resolved.tag_pose = geometry_msgs.msg.Pose.Resolve(msg.tag_pose)
    }
    else {
      resolved.tag_pose = new geometry_msgs.msg.Pose()
    }

    if (msg.landmarks !== undefined) {
      resolved.landmarks = new Array(msg.landmarks.length);
      for (let i = 0; i < resolved.landmarks.length; ++i) {
        resolved.landmarks[i] = LandmarkNewEntry.Resolve(msg.landmarks[i]);
      }
    }
    else {
      resolved.landmarks = []
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: LoadMapAndGetTagPoseRequest,
  Response: LoadMapAndGetTagPoseResponse,
  md5sum() { return '38899b6e3e18705f2d39d4af7c5bcab0'; },
  datatype() { return 'cartographer_ros_msgs/LoadMapAndGetTagPose'; }
};
