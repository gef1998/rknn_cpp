// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class VModelTeachingRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.sensor_topic = null;
      this.minCorner = null;
      this.maxCorner = null;
      this.configure_json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('sensor_topic')) {
        this.sensor_topic = initObj.sensor_topic
      }
      else {
        this.sensor_topic = '';
      }
      if (initObj.hasOwnProperty('minCorner')) {
        this.minCorner = initObj.minCorner
      }
      else {
        this.minCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('maxCorner')) {
        this.maxCorner = initObj.maxCorner
      }
      else {
        this.maxCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VModelTeachingRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [sensor_topic]
    bufferOffset = _serializer.string(obj.sensor_topic, buffer, bufferOffset);
    // Check that the constant length array field [minCorner] has the right length
    if (obj.minCorner.length !== 2) {
      throw new Error('Unable to serialize array field minCorner - length must be 2')
    }
    // Serialize message field [minCorner]
    bufferOffset = _arraySerializer.float32(obj.minCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [maxCorner] has the right length
    if (obj.maxCorner.length !== 2) {
      throw new Error('Unable to serialize array field maxCorner - length must be 2')
    }
    // Serialize message field [maxCorner]
    bufferOffset = _arraySerializer.float32(obj.maxCorner, buffer, bufferOffset, 2);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VModelTeachingRequest
    let len;
    let data = new VModelTeachingRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [sensor_topic]
    data.sensor_topic = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [minCorner]
    data.minCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [maxCorner]
    data.maxCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.sensor_topic.length;
    length += object.configure_json_string.length;
    return length + 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/VModelTeachingRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '41918eef713af5a27d7e61786a5808b9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    string sensor_topic
    float32[2] minCorner
    float32[2] maxCorner
    string configure_json_string
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VModelTeachingRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.sensor_topic !== undefined) {
      resolved.sensor_topic = msg.sensor_topic;
    }
    else {
      resolved.sensor_topic = ''
    }

    if (msg.minCorner !== undefined) {
      resolved.minCorner = msg.minCorner;
    }
    else {
      resolved.minCorner = new Array(2).fill(0)
    }

    if (msg.maxCorner !== undefined) {
      resolved.maxCorner = msg.maxCorner;
    }
    else {
      resolved.maxCorner = new Array(2).fill(0)
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    return resolved;
    }
};

class VModelTeachingResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.ref_base2model = null;
      this.ref_base2map = null;
      this.configure_json_string = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('ref_base2model')) {
        this.ref_base2model = initObj.ref_base2model
      }
      else {
        this.ref_base2model = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('ref_base2map')) {
        this.ref_base2map = initObj.ref_base2map
      }
      else {
        this.ref_base2map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VModelTeachingResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [ref_base2model]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.ref_base2model, buffer, bufferOffset);
    // Serialize message field [ref_base2map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.ref_base2map, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VModelTeachingResponse
    let len;
    let data = new VModelTeachingResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [ref_base2model]
    data.ref_base2model = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [ref_base2map]
    data.ref_base2map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.configure_json_string.length;
    length += object.error_message.length;
    return length + 120;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/VModelTeachingResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a3b2476b3a250d94babb1b6a219d65b6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    geometry_msgs/Pose ref_base2model
    geometry_msgs/Pose ref_base2map
    string configure_json_string
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VModelTeachingResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.ref_base2model !== undefined) {
      resolved.ref_base2model = geometry_msgs.msg.Pose.Resolve(msg.ref_base2model)
    }
    else {
      resolved.ref_base2model = new geometry_msgs.msg.Pose()
    }

    if (msg.ref_base2map !== undefined) {
      resolved.ref_base2map = geometry_msgs.msg.Pose.Resolve(msg.ref_base2map)
    }
    else {
      resolved.ref_base2map = new geometry_msgs.msg.Pose()
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: VModelTeachingRequest,
  Response: VModelTeachingResponse,
  md5sum() { return 'ec828660b4b73a0fe898defdf098dd80'; },
  datatype() { return 'visual_servo_msgs/VModelTeaching'; }
};
