// Auto-generated. Do not edit!

// (in-package move_task_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class FrontEndReferenceLocationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.imagePose = null;
    }
    else {
      if (initObj.hasOwnProperty('imagePose')) {
        this.imagePose = initObj.imagePose
      }
      else {
        this.imagePose = new geometry_msgs.msg.Pose2D();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndReferenceLocationRequest
    // Serialize message field [imagePose]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.imagePose, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndReferenceLocationRequest
    let len;
    let data = new FrontEndReferenceLocationRequest(null);
    // Deserialize message field [imagePose]
    data.imagePose = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a service object
    return 'move_task_msgs/FrontEndReferenceLocationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0bc33512e5a911bacd2d7f2fc0fd3c29';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    geometry_msgs/Pose2D imagePose
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndReferenceLocationRequest(null);
    if (msg.imagePose !== undefined) {
      resolved.imagePose = geometry_msgs.msg.Pose2D.Resolve(msg.imagePose)
    }
    else {
      resolved.imagePose = new geometry_msgs.msg.Pose2D()
    }

    return resolved;
    }
};

class FrontEndReferenceLocationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.reference_id = null;
      this.referencePose = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('reference_id')) {
        this.reference_id = initObj.reference_id
      }
      else {
        this.reference_id = 0;
      }
      if (initObj.hasOwnProperty('referencePose')) {
        this.referencePose = initObj.referencePose
      }
      else {
        this.referencePose = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FrontEndReferenceLocationResponse
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [reference_id]
    bufferOffset = _serializer.int32(obj.reference_id, buffer, bufferOffset);
    // Serialize message field [referencePose]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.referencePose, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FrontEndReferenceLocationResponse
    let len;
    let data = new FrontEndReferenceLocationResponse(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [reference_id]
    data.reference_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [referencePose]
    data.referencePose = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.error_message.length;
    return length + 32;
  }

  static datatype() {
    // Returns string type for a service object
    return 'move_task_msgs/FrontEndReferenceLocationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '459bfb0b270a710e3cb6098653b6eea7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    int32 reference_id
    geometry_msgs/Pose2D referencePose
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FrontEndReferenceLocationResponse(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.reference_id !== undefined) {
      resolved.reference_id = msg.reference_id;
    }
    else {
      resolved.reference_id = 0
    }

    if (msg.referencePose !== undefined) {
      resolved.referencePose = geometry_msgs.msg.Pose2D.Resolve(msg.referencePose)
    }
    else {
      resolved.referencePose = new geometry_msgs.msg.Pose2D()
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: FrontEndReferenceLocationRequest,
  Response: FrontEndReferenceLocationResponse,
  md5sum() { return 'f334df2244b7a73473176f7b2a92cf1f'; },
  datatype() { return 'move_task_msgs/FrontEndReferenceLocation'; }
};
