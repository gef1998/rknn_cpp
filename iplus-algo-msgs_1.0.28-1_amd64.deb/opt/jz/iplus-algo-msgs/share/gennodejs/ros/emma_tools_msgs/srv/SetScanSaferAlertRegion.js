// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ScanSaferLaserRegion = require('../msg/ScanSaferLaserRegion.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetScanSaferAlertRegionRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.lasers = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('lasers')) {
        this.lasers = initObj.lasers
      }
      else {
        this.lasers = [];
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetScanSaferAlertRegionRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [lasers]
    // Serialize the length for message field [lasers]
    bufferOffset = _serializer.uint32(obj.lasers.length, buffer, bufferOffset);
    obj.lasers.forEach((val) => {
      bufferOffset = ScanSaferLaserRegion.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetScanSaferAlertRegionRequest
    let len;
    let data = new SetScanSaferAlertRegionRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [lasers]
    // Deserialize array length for message field [lasers]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.lasers = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.lasers[i] = ScanSaferLaserRegion.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.lasers.forEach((val) => {
      length += ScanSaferLaserRegion.getMessageSize(val);
    });
    length += object.json_string.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/SetScanSaferAlertRegionRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '86430de4279618da2efeae08f9c2cf2b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    ScanSaferLaserRegion[] lasers
    string json_string
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: emma_tools_msgs/ScanSaferLaserRegion
    std_msgs/Header header
    
    string config_topic
    
    geometry_msgs/Polygon region_alert_inner
    geometry_msgs/Polygon region_alert_mid
    geometry_msgs/Polygon region_alert_outer
    geometry_msgs/Polygon[] regions_ignored
    
    string json_string
    
    ================================================================================
    MSG: geometry_msgs/Polygon
    #A specification of a polygon where the first and last points are assumed to be connected
    Point32[] points
    
    ================================================================================
    MSG: geometry_msgs/Point32
    # This contains the position of a point in free space(with 32 bits of precision).
    # It is recommeded to use Point wherever possible instead of Point32.  
    # 
    # This recommendation is to promote interoperability.  
    #
    # This message is designed to take up less space when sending
    # lots of points at once, as in the case of a PointCloud.  
    
    float32 x
    float32 y
    float32 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetScanSaferAlertRegionRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.lasers !== undefined) {
      resolved.lasers = new Array(msg.lasers.length);
      for (let i = 0; i < resolved.lasers.length; ++i) {
        resolved.lasers[i] = ScanSaferLaserRegion.Resolve(msg.lasers[i]);
      }
    }
    else {
      resolved.lasers = []
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

class SetScanSaferAlertRegionResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.message = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetScanSaferAlertRegionResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetScanSaferAlertRegionResponse
    let len;
    let data = new SetScanSaferAlertRegionResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    length += object.json_string.length;
    return length + 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/SetScanSaferAlertRegionResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd62e9c0b0afb7f0bb0ba6f678ee0e3fc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string message
    string json_string
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetScanSaferAlertRegionResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SetScanSaferAlertRegionRequest,
  Response: SetScanSaferAlertRegionResponse,
  md5sum() { return 'ad5fde88fea4bcac0c56e79e9f1332db'; },
  datatype() { return 'emma_tools_msgs/SetScanSaferAlertRegion'; }
};
