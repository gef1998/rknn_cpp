// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let LasermarkEntry = require('./LasermarkEntry.js');
let PointCloudSubmap = require('./PointCloudSubmap.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class SubmapLasermark {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.landmarks_in_map = null;
      this.landmarks_in_odom = null;
      this.submaps = null;
      this.line_detect_submap = null;
      this.point_cloud_finished = null;
      this.debug_flag = null;
      this.localization_type = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('landmarks_in_map')) {
        this.landmarks_in_map = initObj.landmarks_in_map
      }
      else {
        this.landmarks_in_map = [];
      }
      if (initObj.hasOwnProperty('landmarks_in_odom')) {
        this.landmarks_in_odom = initObj.landmarks_in_odom
      }
      else {
        this.landmarks_in_odom = [];
      }
      if (initObj.hasOwnProperty('submaps')) {
        this.submaps = initObj.submaps
      }
      else {
        this.submaps = [];
      }
      if (initObj.hasOwnProperty('line_detect_submap')) {
        this.line_detect_submap = initObj.line_detect_submap
      }
      else {
        this.line_detect_submap = new PointCloudSubmap();
      }
      if (initObj.hasOwnProperty('point_cloud_finished')) {
        this.point_cloud_finished = initObj.point_cloud_finished
      }
      else {
        this.point_cloud_finished = false;
      }
      if (initObj.hasOwnProperty('debug_flag')) {
        this.debug_flag = initObj.debug_flag
      }
      else {
        this.debug_flag = false;
      }
      if (initObj.hasOwnProperty('localization_type')) {
        this.localization_type = initObj.localization_type
      }
      else {
        this.localization_type = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SubmapLasermark
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [landmarks_in_map]
    // Serialize the length for message field [landmarks_in_map]
    bufferOffset = _serializer.uint32(obj.landmarks_in_map.length, buffer, bufferOffset);
    obj.landmarks_in_map.forEach((val) => {
      bufferOffset = LasermarkEntry.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [landmarks_in_odom]
    // Serialize the length for message field [landmarks_in_odom]
    bufferOffset = _serializer.uint32(obj.landmarks_in_odom.length, buffer, bufferOffset);
    obj.landmarks_in_odom.forEach((val) => {
      bufferOffset = LasermarkEntry.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [submaps]
    // Serialize the length for message field [submaps]
    bufferOffset = _serializer.uint32(obj.submaps.length, buffer, bufferOffset);
    obj.submaps.forEach((val) => {
      bufferOffset = PointCloudSubmap.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [line_detect_submap]
    bufferOffset = PointCloudSubmap.serialize(obj.line_detect_submap, buffer, bufferOffset);
    // Serialize message field [point_cloud_finished]
    bufferOffset = _serializer.bool(obj.point_cloud_finished, buffer, bufferOffset);
    // Serialize message field [debug_flag]
    bufferOffset = _serializer.bool(obj.debug_flag, buffer, bufferOffset);
    // Serialize message field [localization_type]
    bufferOffset = _serializer.string(obj.localization_type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SubmapLasermark
    let len;
    let data = new SubmapLasermark(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [landmarks_in_map]
    // Deserialize array length for message field [landmarks_in_map]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.landmarks_in_map = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.landmarks_in_map[i] = LasermarkEntry.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [landmarks_in_odom]
    // Deserialize array length for message field [landmarks_in_odom]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.landmarks_in_odom = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.landmarks_in_odom[i] = LasermarkEntry.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [submaps]
    // Deserialize array length for message field [submaps]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.submaps = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.submaps[i] = PointCloudSubmap.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [line_detect_submap]
    data.line_detect_submap = PointCloudSubmap.deserialize(buffer, bufferOffset);
    // Deserialize message field [point_cloud_finished]
    data.point_cloud_finished = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [debug_flag]
    data.debug_flag = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [localization_type]
    data.localization_type = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    object.landmarks_in_map.forEach((val) => {
      length += LasermarkEntry.getMessageSize(val);
    });
    object.landmarks_in_odom.forEach((val) => {
      length += LasermarkEntry.getMessageSize(val);
    });
    object.submaps.forEach((val) => {
      length += PointCloudSubmap.getMessageSize(val);
    });
    length += PointCloudSubmap.getMessageSize(object.line_detect_submap);
    length += object.localization_type.length;
    return length + 18;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/SubmapLasermark';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '36b0c6988c250f4dba18d7b79c02eee5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    cartographer_ros_msgs/LasermarkEntry[] landmarks_in_map
    cartographer_ros_msgs/LasermarkEntry[] landmarks_in_odom
    cartographer_ros_msgs/PointCloudSubmap[] submaps
    cartographer_ros_msgs/PointCloudSubmap line_detect_submap
    
    bool point_cloud_finished
    bool debug_flag
    string localization_type
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: cartographer_ros_msgs/LasermarkEntry
    string id
    float64 x
    float64 y
    float64 z
    float64 normal_x
    float64 normal_y
    float64 normal_z
    float32 pole_radius
    
    ================================================================================
    MSG: cartographer_ros_msgs/PointCloudSubmap
    std_msgs/Header header
    geometry_msgs/Pose point_cloud_local_pose
    sensor_msgs/PointCloud point_cloud_in_tracking
    int32 point_cloud_frame_cnt
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensor_msgs/PointCloud
    # This message holds a collection of 3d points, plus optional additional
    # information about each point.
    
    # Time of sensor data acquisition, coordinate frame ID.
    Header header
    
    # Array of 3d points. Each Point32 should be interpreted as a 3d point
    # in the frame given in the header.
    geometry_msgs/Point32[] points
    
    # Each channel should have the same number of elements as points array,
    # and the data in each channel should correspond 1:1 with each point.
    # Channel names in common practice are listed in ChannelFloat32.msg.
    ChannelFloat32[] channels
    
    ================================================================================
    MSG: geometry_msgs/Point32
    # This contains the position of a point in free space(with 32 bits of precision).
    # It is recommeded to use Point wherever possible instead of Point32.  
    # 
    # This recommendation is to promote interoperability.  
    #
    # This message is designed to take up less space when sending
    # lots of points at once, as in the case of a PointCloud.  
    
    float32 x
    float32 y
    float32 z
    ================================================================================
    MSG: sensor_msgs/ChannelFloat32
    # This message is used by the PointCloud message to hold optional data
    # associated with each point in the cloud. The length of the values
    # array should be the same as the length of the points array in the
    # PointCloud, and each value should be associated with the corresponding
    # point.
    
    # Channel names in existing practice include:
    #   "u", "v" - row and column (respectively) in the left stereo image.
    #              This is opposite to usual conventions but remains for
    #              historical reasons. The newer PointCloud2 message has no
    #              such problem.
    #   "rgb" - For point clouds produced by color stereo cameras. uint8
    #           (R,G,B) values packed into the least significant 24 bits,
    #           in order.
    #   "intensity" - laser or pixel intensity.
    #   "distance"
    
    # The channel name should give semantics of the channel (e.g.
    # "intensity" instead of "value").
    string name
    
    # The values array should be 1-1 with the elements of the associated
    # PointCloud.
    float32[] values
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SubmapLasermark(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.landmarks_in_map !== undefined) {
      resolved.landmarks_in_map = new Array(msg.landmarks_in_map.length);
      for (let i = 0; i < resolved.landmarks_in_map.length; ++i) {
        resolved.landmarks_in_map[i] = LasermarkEntry.Resolve(msg.landmarks_in_map[i]);
      }
    }
    else {
      resolved.landmarks_in_map = []
    }

    if (msg.landmarks_in_odom !== undefined) {
      resolved.landmarks_in_odom = new Array(msg.landmarks_in_odom.length);
      for (let i = 0; i < resolved.landmarks_in_odom.length; ++i) {
        resolved.landmarks_in_odom[i] = LasermarkEntry.Resolve(msg.landmarks_in_odom[i]);
      }
    }
    else {
      resolved.landmarks_in_odom = []
    }

    if (msg.submaps !== undefined) {
      resolved.submaps = new Array(msg.submaps.length);
      for (let i = 0; i < resolved.submaps.length; ++i) {
        resolved.submaps[i] = PointCloudSubmap.Resolve(msg.submaps[i]);
      }
    }
    else {
      resolved.submaps = []
    }

    if (msg.line_detect_submap !== undefined) {
      resolved.line_detect_submap = PointCloudSubmap.Resolve(msg.line_detect_submap)
    }
    else {
      resolved.line_detect_submap = new PointCloudSubmap()
    }

    if (msg.point_cloud_finished !== undefined) {
      resolved.point_cloud_finished = msg.point_cloud_finished;
    }
    else {
      resolved.point_cloud_finished = false
    }

    if (msg.debug_flag !== undefined) {
      resolved.debug_flag = msg.debug_flag;
    }
    else {
      resolved.debug_flag = false
    }

    if (msg.localization_type !== undefined) {
      resolved.localization_type = msg.localization_type;
    }
    else {
      resolved.localization_type = ''
    }

    return resolved;
    }
};

module.exports = SubmapLasermark;
