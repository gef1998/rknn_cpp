// Auto-generated. Do not edit!

// (in-package sensors_check_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class SensorsCalibResult {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sensor_type = null;
      this.isSuccess = null;
      this.laser_translation_err = null;
      this.laser_rotation_err = null;
      this.odom_translation_err = null;
      this.odom_rotation_err = null;
      this.VS_translation_err = null;
      this.VS_rotation_err = null;
    }
    else {
      if (initObj.hasOwnProperty('sensor_type')) {
        this.sensor_type = initObj.sensor_type
      }
      else {
        this.sensor_type = 0;
      }
      if (initObj.hasOwnProperty('isSuccess')) {
        this.isSuccess = initObj.isSuccess
      }
      else {
        this.isSuccess = false;
      }
      if (initObj.hasOwnProperty('laser_translation_err')) {
        this.laser_translation_err = initObj.laser_translation_err
      }
      else {
        this.laser_translation_err = 0.0;
      }
      if (initObj.hasOwnProperty('laser_rotation_err')) {
        this.laser_rotation_err = initObj.laser_rotation_err
      }
      else {
        this.laser_rotation_err = 0.0;
      }
      if (initObj.hasOwnProperty('odom_translation_err')) {
        this.odom_translation_err = initObj.odom_translation_err
      }
      else {
        this.odom_translation_err = 0.0;
      }
      if (initObj.hasOwnProperty('odom_rotation_err')) {
        this.odom_rotation_err = initObj.odom_rotation_err
      }
      else {
        this.odom_rotation_err = 0.0;
      }
      if (initObj.hasOwnProperty('VS_translation_err')) {
        this.VS_translation_err = initObj.VS_translation_err
      }
      else {
        this.VS_translation_err = 0.0;
      }
      if (initObj.hasOwnProperty('VS_rotation_err')) {
        this.VS_rotation_err = initObj.VS_rotation_err
      }
      else {
        this.VS_rotation_err = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SensorsCalibResult
    // Serialize message field [sensor_type]
    bufferOffset = _serializer.uint8(obj.sensor_type, buffer, bufferOffset);
    // Serialize message field [isSuccess]
    bufferOffset = _serializer.bool(obj.isSuccess, buffer, bufferOffset);
    // Serialize message field [laser_translation_err]
    bufferOffset = _serializer.float32(obj.laser_translation_err, buffer, bufferOffset);
    // Serialize message field [laser_rotation_err]
    bufferOffset = _serializer.float32(obj.laser_rotation_err, buffer, bufferOffset);
    // Serialize message field [odom_translation_err]
    bufferOffset = _serializer.float32(obj.odom_translation_err, buffer, bufferOffset);
    // Serialize message field [odom_rotation_err]
    bufferOffset = _serializer.float32(obj.odom_rotation_err, buffer, bufferOffset);
    // Serialize message field [VS_translation_err]
    bufferOffset = _serializer.float32(obj.VS_translation_err, buffer, bufferOffset);
    // Serialize message field [VS_rotation_err]
    bufferOffset = _serializer.float32(obj.VS_rotation_err, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SensorsCalibResult
    let len;
    let data = new SensorsCalibResult(null);
    // Deserialize message field [sensor_type]
    data.sensor_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [isSuccess]
    data.isSuccess = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [laser_translation_err]
    data.laser_translation_err = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [laser_rotation_err]
    data.laser_rotation_err = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [odom_translation_err]
    data.odom_translation_err = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [odom_rotation_err]
    data.odom_rotation_err = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [VS_translation_err]
    data.VS_translation_err = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [VS_rotation_err]
    data.VS_rotation_err = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 26;
  }

  static datatype() {
    // Returns string type for a message object
    return 'sensors_check_msgs/SensorsCalibResult';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '87c80b7a9c3b00a5f2cb6172c931fb83';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    # result
    uint8 sensor_type
    uint8 LASER_AND_ODOM = 0
    uint8 VISUAL_SERVO = 1
    uint8 LINE_FOLLOWING_VS = 2
    
    bool    isSuccess
    float32 laser_translation_err
    float32 laser_rotation_err
    float32 odom_translation_err
    float32 odom_rotation_err
    float32 VS_translation_err
    float32 VS_rotation_err
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SensorsCalibResult(null);
    if (msg.sensor_type !== undefined) {
      resolved.sensor_type = msg.sensor_type;
    }
    else {
      resolved.sensor_type = 0
    }

    if (msg.isSuccess !== undefined) {
      resolved.isSuccess = msg.isSuccess;
    }
    else {
      resolved.isSuccess = false
    }

    if (msg.laser_translation_err !== undefined) {
      resolved.laser_translation_err = msg.laser_translation_err;
    }
    else {
      resolved.laser_translation_err = 0.0
    }

    if (msg.laser_rotation_err !== undefined) {
      resolved.laser_rotation_err = msg.laser_rotation_err;
    }
    else {
      resolved.laser_rotation_err = 0.0
    }

    if (msg.odom_translation_err !== undefined) {
      resolved.odom_translation_err = msg.odom_translation_err;
    }
    else {
      resolved.odom_translation_err = 0.0
    }

    if (msg.odom_rotation_err !== undefined) {
      resolved.odom_rotation_err = msg.odom_rotation_err;
    }
    else {
      resolved.odom_rotation_err = 0.0
    }

    if (msg.VS_translation_err !== undefined) {
      resolved.VS_translation_err = msg.VS_translation_err;
    }
    else {
      resolved.VS_translation_err = 0.0
    }

    if (msg.VS_rotation_err !== undefined) {
      resolved.VS_rotation_err = msg.VS_rotation_err;
    }
    else {
      resolved.VS_rotation_err = 0.0
    }

    return resolved;
    }
};

// Constants for message
SensorsCalibResult.Constants = {
  LASER_AND_ODOM: 0,
  VISUAL_SERVO: 1,
  LINE_FOLLOWING_VS: 2,
}

module.exports = SensorsCalibResult;
