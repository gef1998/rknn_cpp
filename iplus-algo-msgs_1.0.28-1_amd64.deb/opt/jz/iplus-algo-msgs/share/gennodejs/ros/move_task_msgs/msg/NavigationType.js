// Auto-generated. Do not edit!

// (in-package move_task_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class NavigationType {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.type = null;
    }
    else {
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NavigationType
    // Serialize message field [type]
    bufferOffset = _serializer.int8(obj.type, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NavigationType
    let len;
    let data = new NavigationType(null);
    // Deserialize message field [type]
    data.type = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'move_task_msgs/NavigationType';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e2f89595fdd094a410c60a08fc5382ac';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #navigation type: localise_based odometry_based visual_servo line_followiing_vs
    int8 type
    int8 LOCALIZED_NAVIGATION=0
    int8 ODOMETRY_NAVIGATION=1   #pure rotation, stight forward, three phases
    int8 VISUAL_SERVO_NAVIGATION=2
    int8 LINE_FOLLOWING_VS_NAVIGATION=3
    int8 FORKLIFT_LOADING = 4
    int8 FORKLIFT_UNLOADING = 5
    int8 LASER_SERVO = 6     #three phases
    int8 ICP_SERVO = 7       #three phases
    int8 LASER_INTENSITY_SERVO = 8    #three phases
    int8 NEW_ODOM_NAV = 9    
    int8 MOTION_TASK = 10    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NavigationType(null);
    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    return resolved;
    }
};

// Constants for message
NavigationType.Constants = {
  LOCALIZED_NAVIGATION: 0,
  ODOMETRY_NAVIGATION: 1,
  VISUAL_SERVO_NAVIGATION: 2,
  LINE_FOLLOWING_VS_NAVIGATION: 3,
  FORKLIFT_LOADING: 4,
  FORKLIFT_UNLOADING: 5,
  LASER_SERVO: 6,
  ICP_SERVO: 7,
  LASER_INTENSITY_SERVO: 8,
  NEW_ODOM_NAV: 9,
  MOTION_TASK: 10,
}

module.exports = NavigationType;
