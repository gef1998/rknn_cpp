// Auto-generated. Do not edit!

// (in-package map_manager_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class TagMapInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tag_id = null;
      this.submap_id = null;
      this.pose = null;
      this.tag_pose_in_laser = null;
      this.neighbors_id = null;
    }
    else {
      if (initObj.hasOwnProperty('tag_id')) {
        this.tag_id = initObj.tag_id
      }
      else {
        this.tag_id = 0;
      }
      if (initObj.hasOwnProperty('submap_id')) {
        this.submap_id = initObj.submap_id
      }
      else {
        this.submap_id = 0;
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('tag_pose_in_laser')) {
        this.tag_pose_in_laser = initObj.tag_pose_in_laser
      }
      else {
        this.tag_pose_in_laser = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('neighbors_id')) {
        this.neighbors_id = initObj.neighbors_id
      }
      else {
        this.neighbors_id = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TagMapInfo
    // Serialize message field [tag_id]
    bufferOffset = _serializer.int32(obj.tag_id, buffer, bufferOffset);
    // Serialize message field [submap_id]
    bufferOffset = _serializer.int32(obj.submap_id, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [tag_pose_in_laser]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.tag_pose_in_laser, buffer, bufferOffset);
    // Serialize message field [neighbors_id]
    bufferOffset = _arraySerializer.int32(obj.neighbors_id, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TagMapInfo
    let len;
    let data = new TagMapInfo(null);
    // Deserialize message field [tag_id]
    data.tag_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [submap_id]
    data.submap_id = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [tag_pose_in_laser]
    data.tag_pose_in_laser = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [neighbors_id]
    data.neighbors_id = _arrayDeserializer.int32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.neighbors_id.length;
    return length + 124;
  }

  static datatype() {
    // Returns string type for a message object
    return 'map_manager_msgs/TagMapInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f023467f8570c6b559018758bfcd8283';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32 tag_id
    int32 submap_id
    geometry_msgs/Pose pose
    geometry_msgs/Pose tag_pose_in_laser
    int32[] neighbors_id
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TagMapInfo(null);
    if (msg.tag_id !== undefined) {
      resolved.tag_id = msg.tag_id;
    }
    else {
      resolved.tag_id = 0
    }

    if (msg.submap_id !== undefined) {
      resolved.submap_id = msg.submap_id;
    }
    else {
      resolved.submap_id = 0
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.tag_pose_in_laser !== undefined) {
      resolved.tag_pose_in_laser = geometry_msgs.msg.Pose.Resolve(msg.tag_pose_in_laser)
    }
    else {
      resolved.tag_pose_in_laser = new geometry_msgs.msg.Pose()
    }

    if (msg.neighbors_id !== undefined) {
      resolved.neighbors_id = msg.neighbors_id;
    }
    else {
      resolved.neighbors_id = []
    }

    return resolved;
    }
};

module.exports = TagMapInfo;
