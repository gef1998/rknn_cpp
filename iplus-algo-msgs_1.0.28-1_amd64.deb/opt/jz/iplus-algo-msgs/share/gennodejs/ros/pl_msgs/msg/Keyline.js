// Auto-generated. Do not edit!

// (in-package pl_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Keyline {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.le_x = null;
      this.le_y = null;
      this.le_z = null;
      this.spl_x = null;
      this.spl_y = null;
      this.epl_x = null;
      this.epl_y = null;
    }
    else {
      if (initObj.hasOwnProperty('le_x')) {
        this.le_x = initObj.le_x
      }
      else {
        this.le_x = 0.0;
      }
      if (initObj.hasOwnProperty('le_y')) {
        this.le_y = initObj.le_y
      }
      else {
        this.le_y = 0.0;
      }
      if (initObj.hasOwnProperty('le_z')) {
        this.le_z = initObj.le_z
      }
      else {
        this.le_z = 0.0;
      }
      if (initObj.hasOwnProperty('spl_x')) {
        this.spl_x = initObj.spl_x
      }
      else {
        this.spl_x = 0.0;
      }
      if (initObj.hasOwnProperty('spl_y')) {
        this.spl_y = initObj.spl_y
      }
      else {
        this.spl_y = 0.0;
      }
      if (initObj.hasOwnProperty('epl_x')) {
        this.epl_x = initObj.epl_x
      }
      else {
        this.epl_x = 0.0;
      }
      if (initObj.hasOwnProperty('epl_y')) {
        this.epl_y = initObj.epl_y
      }
      else {
        this.epl_y = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Keyline
    // Serialize message field [le_x]
    bufferOffset = _serializer.float64(obj.le_x, buffer, bufferOffset);
    // Serialize message field [le_y]
    bufferOffset = _serializer.float64(obj.le_y, buffer, bufferOffset);
    // Serialize message field [le_z]
    bufferOffset = _serializer.float64(obj.le_z, buffer, bufferOffset);
    // Serialize message field [spl_x]
    bufferOffset = _serializer.float64(obj.spl_x, buffer, bufferOffset);
    // Serialize message field [spl_y]
    bufferOffset = _serializer.float64(obj.spl_y, buffer, bufferOffset);
    // Serialize message field [epl_x]
    bufferOffset = _serializer.float64(obj.epl_x, buffer, bufferOffset);
    // Serialize message field [epl_y]
    bufferOffset = _serializer.float64(obj.epl_y, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Keyline
    let len;
    let data = new Keyline(null);
    // Deserialize message field [le_x]
    data.le_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [le_y]
    data.le_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [le_z]
    data.le_z = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [spl_x]
    data.spl_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [spl_y]
    data.spl_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [epl_x]
    data.epl_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [epl_y]
    data.epl_y = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 56;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pl_msgs/Keyline';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f88d2e2f2a77e65e5e56cad29091b988';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Copyright 2016 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    float64 le_x
    float64 le_y
    float64 le_z
    float64 spl_x
    float64 spl_y
    float64 epl_x
    float64 epl_y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Keyline(null);
    if (msg.le_x !== undefined) {
      resolved.le_x = msg.le_x;
    }
    else {
      resolved.le_x = 0.0
    }

    if (msg.le_y !== undefined) {
      resolved.le_y = msg.le_y;
    }
    else {
      resolved.le_y = 0.0
    }

    if (msg.le_z !== undefined) {
      resolved.le_z = msg.le_z;
    }
    else {
      resolved.le_z = 0.0
    }

    if (msg.spl_x !== undefined) {
      resolved.spl_x = msg.spl_x;
    }
    else {
      resolved.spl_x = 0.0
    }

    if (msg.spl_y !== undefined) {
      resolved.spl_y = msg.spl_y;
    }
    else {
      resolved.spl_y = 0.0
    }

    if (msg.epl_x !== undefined) {
      resolved.epl_x = msg.epl_x;
    }
    else {
      resolved.epl_x = 0.0
    }

    if (msg.epl_y !== undefined) {
      resolved.epl_y = msg.epl_y;
    }
    else {
      resolved.epl_y = 0.0
    }

    return resolved;
    }
};

module.exports = Keyline;
