// Auto-generated. Do not edit!

// (in-package visual_servo_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

let geometry_msgs = _finder('geometry_msgs');
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class PalletTeachingRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.mode = null;
      this.sensor_topic = null;
      this.minCorner = null;
      this.maxCorner = null;
      this.zRange = null;
      this.configure_json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('mode')) {
        this.mode = initObj.mode
      }
      else {
        this.mode = 0;
      }
      if (initObj.hasOwnProperty('sensor_topic')) {
        this.sensor_topic = initObj.sensor_topic
      }
      else {
        this.sensor_topic = '';
      }
      if (initObj.hasOwnProperty('minCorner')) {
        this.minCorner = initObj.minCorner
      }
      else {
        this.minCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('maxCorner')) {
        this.maxCorner = initObj.maxCorner
      }
      else {
        this.maxCorner = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('zRange')) {
        this.zRange = initObj.zRange
      }
      else {
        this.zRange = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PalletTeachingRequest
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [mode]
    bufferOffset = _serializer.uint8(obj.mode, buffer, bufferOffset);
    // Serialize message field [sensor_topic]
    bufferOffset = _serializer.string(obj.sensor_topic, buffer, bufferOffset);
    // Check that the constant length array field [minCorner] has the right length
    if (obj.minCorner.length !== 2) {
      throw new Error('Unable to serialize array field minCorner - length must be 2')
    }
    // Serialize message field [minCorner]
    bufferOffset = _arraySerializer.float32(obj.minCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [maxCorner] has the right length
    if (obj.maxCorner.length !== 2) {
      throw new Error('Unable to serialize array field maxCorner - length must be 2')
    }
    // Serialize message field [maxCorner]
    bufferOffset = _arraySerializer.float32(obj.maxCorner, buffer, bufferOffset, 2);
    // Check that the constant length array field [zRange] has the right length
    if (obj.zRange.length !== 2) {
      throw new Error('Unable to serialize array field zRange - length must be 2')
    }
    // Serialize message field [zRange]
    bufferOffset = _arraySerializer.float32(obj.zRange, buffer, bufferOffset, 2);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PalletTeachingRequest
    let len;
    let data = new PalletTeachingRequest(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [mode]
    data.mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [sensor_topic]
    data.sensor_topic = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [minCorner]
    data.minCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [maxCorner]
    data.maxCorner = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [zRange]
    data.zRange = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += object.sensor_topic.length;
    length += object.configure_json_string.length;
    return length + 33;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/PalletTeachingRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '16f68e395710b182688252f4d8e459ee';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    uint8 mode
    uint8 START_TEACHING = 0
    uint8 TEACHING = 1
    uint8 STOP_TEACHING = 2
    string sensor_topic
    float32[2] minCorner
    float32[2] maxCorner
    float32[2] zRange
    string configure_json_string
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PalletTeachingRequest(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.mode !== undefined) {
      resolved.mode = msg.mode;
    }
    else {
      resolved.mode = 0
    }

    if (msg.sensor_topic !== undefined) {
      resolved.sensor_topic = msg.sensor_topic;
    }
    else {
      resolved.sensor_topic = ''
    }

    if (msg.minCorner !== undefined) {
      resolved.minCorner = msg.minCorner;
    }
    else {
      resolved.minCorner = new Array(2).fill(0)
    }

    if (msg.maxCorner !== undefined) {
      resolved.maxCorner = msg.maxCorner;
    }
    else {
      resolved.maxCorner = new Array(2).fill(0)
    }

    if (msg.zRange !== undefined) {
      resolved.zRange = msg.zRange;
    }
    else {
      resolved.zRange = new Array(2).fill(0)
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    return resolved;
    }
};

// Constants for message
PalletTeachingRequest.Constants = {
  START_TEACHING: 0,
  TEACHING: 1,
  STOP_TEACHING: 2,
}

class PalletTeachingResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.header = null;
      this.status = null;
      this.scan_in_base = null;
      this.pc_in_base = null;
      this.ref_base2map = null;
      this.ref_base2model = null;
      this.configure_json_string = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
      if (initObj.hasOwnProperty('scan_in_base')) {
        this.scan_in_base = initObj.scan_in_base
      }
      else {
        this.scan_in_base = new sensor_msgs.msg.LaserScan();
      }
      if (initObj.hasOwnProperty('pc_in_base')) {
        this.pc_in_base = initObj.pc_in_base
      }
      else {
        this.pc_in_base = new sensor_msgs.msg.PointCloud2();
      }
      if (initObj.hasOwnProperty('ref_base2map')) {
        this.ref_base2map = initObj.ref_base2map
      }
      else {
        this.ref_base2map = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('ref_base2model')) {
        this.ref_base2model = initObj.ref_base2model
      }
      else {
        this.ref_base2model = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('configure_json_string')) {
        this.configure_json_string = initObj.configure_json_string
      }
      else {
        this.configure_json_string = '';
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PalletTeachingResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    // Serialize message field [scan_in_base]
    bufferOffset = sensor_msgs.msg.LaserScan.serialize(obj.scan_in_base, buffer, bufferOffset);
    // Serialize message field [pc_in_base]
    bufferOffset = sensor_msgs.msg.PointCloud2.serialize(obj.pc_in_base, buffer, bufferOffset);
    // Serialize message field [ref_base2map]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.ref_base2map, buffer, bufferOffset);
    // Serialize message field [ref_base2model]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.ref_base2model, buffer, bufferOffset);
    // Serialize message field [configure_json_string]
    bufferOffset = _serializer.string(obj.configure_json_string, buffer, bufferOffset);
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PalletTeachingResponse
    let len;
    let data = new PalletTeachingResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [scan_in_base]
    data.scan_in_base = sensor_msgs.msg.LaserScan.deserialize(buffer, bufferOffset);
    // Deserialize message field [pc_in_base]
    data.pc_in_base = sensor_msgs.msg.PointCloud2.deserialize(buffer, bufferOffset);
    // Deserialize message field [ref_base2map]
    data.ref_base2map = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [ref_base2model]
    data.ref_base2model = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [configure_json_string]
    data.configure_json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += sensor_msgs.msg.LaserScan.getMessageSize(object.scan_in_base);
    length += sensor_msgs.msg.PointCloud2.getMessageSize(object.pc_in_base);
    length += object.configure_json_string.length;
    length += object.error_message.length;
    return length + 122;
  }

  static datatype() {
    // Returns string type for a service object
    return 'visual_servo_msgs/PalletTeachingResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c17f0a832a80589665b4765d6f0b0eea';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    std_msgs/Header header
    uint8 status
    uint8 TEACHING_STARTED = 0
    uint8 TEACHING_STOPED = 1
    uint8 TEACHING_RUNNING = 2
    uint8 TEACHING_NOT_RUNNING = 3
    uint8 TEACHING_IDLE = 4
    sensor_msgs/LaserScan  scan_in_base
    sensor_msgs/PointCloud2 pc_in_base
    geometry_msgs/Pose ref_base2map
    geometry_msgs/Pose ref_base2model
    string configure_json_string
    string error_message
    
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: sensor_msgs/LaserScan
    # Single scan from a planar laser range-finder
    #
    # If you have another ranging device with different behavior (e.g. a sonar
    # array), please find or create a different message, since applications
    # will make fairly laser-specific assumptions about this data
    
    Header header            # timestamp in the header is the acquisition time of 
                             # the first ray in the scan.
                             #
                             # in frame frame_id, angles are measured around 
                             # the positive Z axis (counterclockwise, if Z is up)
                             # with zero angle being forward along the x axis
                             
    float32 angle_min        # start angle of the scan [rad]
    float32 angle_max        # end angle of the scan [rad]
    float32 angle_increment  # angular distance between measurements [rad]
    
    float32 time_increment   # time between measurements [seconds] - if your scanner
                             # is moving, this will be used in interpolating position
                             # of 3d points
    float32 scan_time        # time between scans [seconds]
    
    float32 range_min        # minimum range value [m]
    float32 range_max        # maximum range value [m]
    
    float32[] ranges         # range data [m] (Note: values < range_min or > range_max should be discarded)
    float32[] intensities    # intensity data [device-specific units].  If your
                             # device does not provide intensities, please leave
                             # the array empty.
    
    ================================================================================
    MSG: sensor_msgs/PointCloud2
    # This message holds a collection of N-dimensional points, which may
    # contain additional information such as normals, intensity, etc. The
    # point data is stored as a binary blob, its layout described by the
    # contents of the "fields" array.
    
    # The point cloud data may be organized 2d (image-like) or 1d
    # (unordered). Point clouds organized as 2d images may be produced by
    # camera depth sensors such as stereo or time-of-flight.
    
    # Time of sensor data acquisition, and the coordinate frame ID (for 3d
    # points).
    Header header
    
    # 2D structure of the point cloud. If the cloud is unordered, height is
    # 1 and width is the length of the point cloud.
    uint32 height
    uint32 width
    
    # Describes the channels and their layout in the binary data blob.
    PointField[] fields
    
    bool    is_bigendian # Is this data bigendian?
    uint32  point_step   # Length of a point in bytes
    uint32  row_step     # Length of a row in bytes
    uint8[] data         # Actual point data, size is (row_step*height)
    
    bool is_dense        # True if there are no invalid points
    
    ================================================================================
    MSG: sensor_msgs/PointField
    # This message holds the description of one point entry in the
    # PointCloud2 message format.
    uint8 INT8    = 1
    uint8 UINT8   = 2
    uint8 INT16   = 3
    uint8 UINT16  = 4
    uint8 INT32   = 5
    uint8 UINT32  = 6
    uint8 FLOAT32 = 7
    uint8 FLOAT64 = 8
    
    string name      # Name of field
    uint32 offset    # Offset from start of point struct
    uint8  datatype  # Datatype enumeration, see above
    uint32 count     # How many elements in the field
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PalletTeachingResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    if (msg.scan_in_base !== undefined) {
      resolved.scan_in_base = sensor_msgs.msg.LaserScan.Resolve(msg.scan_in_base)
    }
    else {
      resolved.scan_in_base = new sensor_msgs.msg.LaserScan()
    }

    if (msg.pc_in_base !== undefined) {
      resolved.pc_in_base = sensor_msgs.msg.PointCloud2.Resolve(msg.pc_in_base)
    }
    else {
      resolved.pc_in_base = new sensor_msgs.msg.PointCloud2()
    }

    if (msg.ref_base2map !== undefined) {
      resolved.ref_base2map = geometry_msgs.msg.Pose.Resolve(msg.ref_base2map)
    }
    else {
      resolved.ref_base2map = new geometry_msgs.msg.Pose()
    }

    if (msg.ref_base2model !== undefined) {
      resolved.ref_base2model = geometry_msgs.msg.Pose.Resolve(msg.ref_base2model)
    }
    else {
      resolved.ref_base2model = new geometry_msgs.msg.Pose()
    }

    if (msg.configure_json_string !== undefined) {
      resolved.configure_json_string = msg.configure_json_string;
    }
    else {
      resolved.configure_json_string = ''
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

// Constants for message
PalletTeachingResponse.Constants = {
  TEACHING_STARTED: 0,
  TEACHING_STOPED: 1,
  TEACHING_RUNNING: 2,
  TEACHING_NOT_RUNNING: 3,
  TEACHING_IDLE: 4,
}

module.exports = {
  Request: PalletTeachingRequest,
  Response: PalletTeachingResponse,
  md5sum() { return 'd202624b4ab2739eb329c3a1be0257e6'; },
  datatype() { return 'visual_servo_msgs/PalletTeaching'; }
};
