// Auto-generated. Do not edit!

// (in-package move_task_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let NavigationType = require('./NavigationType.js');

//-----------------------------------------------------------

class TaskStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.nav_type = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('nav_type')) {
        this.nav_type = initObj.nav_type
      }
      else {
        this.nav_type = new NavigationType();
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TaskStatus
    // Serialize message field [nav_type]
    bufferOffset = NavigationType.serialize(obj.nav_type, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.int8(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TaskStatus
    let len;
    let data = new TaskStatus(null);
    // Deserialize message field [nav_type]
    data.nav_type = NavigationType.deserialize(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'move_task_msgs/TaskStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '878603fab26b3d779b7a3d7a59c85de0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # move task status
    move_task_msgs/NavigationType nav_type
    
    int8 status
    
    int8 ERROR     = -1
    int8 IDLING    = 0
    int8 RUNNING   = 1
    int8 PAUSED    = 2
    int8 COMPLETED = 3
    int8 CANCELLED = 4
    
    
    
    ================================================================================
    MSG: move_task_msgs/NavigationType
    #navigation type: localise_based odometry_based visual_servo line_followiing_vs
    int8 type
    int8 LOCALIZED_NAVIGATION=0
    int8 ODOMETRY_NAVIGATION=1   #pure rotation, stight forward, three phases
    int8 VISUAL_SERVO_NAVIGATION=2
    int8 LINE_FOLLOWING_VS_NAVIGATION=3
    int8 FORKLIFT_LOADING = 4
    int8 FORKLIFT_UNLOADING = 5
    int8 LASER_SERVO = 6     #three phases
    int8 ICP_SERVO = 7       #three phases
    int8 LASER_INTENSITY_SERVO = 8    #three phases
    int8 NEW_ODOM_NAV = 9    
    int8 MOTION_TASK = 10    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TaskStatus(null);
    if (msg.nav_type !== undefined) {
      resolved.nav_type = NavigationType.Resolve(msg.nav_type)
    }
    else {
      resolved.nav_type = new NavigationType()
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
TaskStatus.Constants = {
  ERROR: -1,
  IDLING: 0,
  RUNNING: 1,
  PAUSED: 2,
  COMPLETED: 3,
  CANCELLED: 4,
}

module.exports = TaskStatus;
