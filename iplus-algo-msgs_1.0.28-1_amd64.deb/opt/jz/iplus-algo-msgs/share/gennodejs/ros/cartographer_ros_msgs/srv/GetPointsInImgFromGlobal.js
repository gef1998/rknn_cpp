// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class GetPointsInImgFromGlobalRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.global_points = null;
    }
    else {
      if (initObj.hasOwnProperty('global_points')) {
        this.global_points = initObj.global_points
      }
      else {
        this.global_points = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetPointsInImgFromGlobalRequest
    // Serialize message field [global_points]
    // Serialize the length for message field [global_points]
    bufferOffset = _serializer.uint32(obj.global_points.length, buffer, bufferOffset);
    obj.global_points.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetPointsInImgFromGlobalRequest
    let len;
    let data = new GetPointsInImgFromGlobalRequest(null);
    // Deserialize message field [global_points]
    // Deserialize array length for message field [global_points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.global_points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.global_points[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 24 * object.global_points.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/GetPointsInImgFromGlobalRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9e57c5ac61f1f960ca984005899ba2c3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    geometry_msgs/Point[] global_points
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetPointsInImgFromGlobalRequest(null);
    if (msg.global_points !== undefined) {
      resolved.global_points = new Array(msg.global_points.length);
      for (let i = 0; i < resolved.global_points.length; ++i) {
        resolved.global_points[i] = geometry_msgs.msg.Point.Resolve(msg.global_points[i]);
      }
    }
    else {
      resolved.global_points = []
    }

    return resolved;
    }
};

class GetPointsInImgFromGlobalResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.submap_ids = null;
      this.img_points = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('submap_ids')) {
        this.submap_ids = initObj.submap_ids
      }
      else {
        this.submap_ids = [];
      }
      if (initObj.hasOwnProperty('img_points')) {
        this.img_points = initObj.img_points
      }
      else {
        this.img_points = [];
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetPointsInImgFromGlobalResponse
    // Serialize message field [submap_ids]
    bufferOffset = _arraySerializer.int32(obj.submap_ids, buffer, bufferOffset, null);
    // Serialize message field [img_points]
    // Serialize the length for message field [img_points]
    bufferOffset = _serializer.uint32(obj.img_points.length, buffer, bufferOffset);
    obj.img_points.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetPointsInImgFromGlobalResponse
    let len;
    let data = new GetPointsInImgFromGlobalResponse(null);
    // Deserialize message field [submap_ids]
    data.submap_ids = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [img_points]
    // Deserialize array length for message field [img_points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.img_points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.img_points[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.submap_ids.length;
    length += 24 * object.img_points.length;
    length += object.error_message.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/GetPointsInImgFromGlobalResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '088e567b0c30316fda29b413d8ea8951';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32[] submap_ids
    geometry_msgs/Point[] img_points
    string error_message
    
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetPointsInImgFromGlobalResponse(null);
    if (msg.submap_ids !== undefined) {
      resolved.submap_ids = msg.submap_ids;
    }
    else {
      resolved.submap_ids = []
    }

    if (msg.img_points !== undefined) {
      resolved.img_points = new Array(msg.img_points.length);
      for (let i = 0; i < resolved.img_points.length; ++i) {
        resolved.img_points[i] = geometry_msgs.msg.Point.Resolve(msg.img_points[i]);
      }
    }
    else {
      resolved.img_points = []
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: GetPointsInImgFromGlobalRequest,
  Response: GetPointsInImgFromGlobalResponse,
  md5sum() { return 'bc4e159a78087f0fb63eac26085cd553'; },
  datatype() { return 'cartographer_ros_msgs/GetPointsInImgFromGlobal'; }
};
