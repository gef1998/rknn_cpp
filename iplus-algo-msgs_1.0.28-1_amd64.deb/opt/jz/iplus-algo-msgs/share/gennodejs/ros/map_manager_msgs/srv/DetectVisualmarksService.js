// Auto-generated. Do not edit!

// (in-package map_manager_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class DetectVisualmarksServiceRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.tag_map_path = null;
    }
    else {
      if (initObj.hasOwnProperty('tag_map_path')) {
        this.tag_map_path = initObj.tag_map_path
      }
      else {
        this.tag_map_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DetectVisualmarksServiceRequest
    // Serialize message field [tag_map_path]
    bufferOffset = _serializer.string(obj.tag_map_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DetectVisualmarksServiceRequest
    let len;
    let data = new DetectVisualmarksServiceRequest(null);
    // Deserialize message field [tag_map_path]
    data.tag_map_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.tag_map_path.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/DetectVisualmarksServiceRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b8734bf2df1e2ea5893c8de45308787b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string tag_map_path
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DetectVisualmarksServiceRequest(null);
    if (msg.tag_map_path !== undefined) {
      resolved.tag_map_path = msg.tag_map_path;
    }
    else {
      resolved.tag_map_path = ''
    }

    return resolved;
    }
};

class DetectVisualmarksServiceResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.error_msgs = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('error_msgs')) {
        this.error_msgs = initObj.error_msgs
      }
      else {
        this.error_msgs = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DetectVisualmarksServiceResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [error_msgs]
    bufferOffset = _serializer.string(obj.error_msgs, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DetectVisualmarksServiceResponse
    let len;
    let data = new DetectVisualmarksServiceResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_msgs]
    data.error_msgs = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.error_msgs.length;
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'map_manager_msgs/DetectVisualmarksServiceResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'af6942a396e00ad28d25207e6c55c3a8';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string error_msgs
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DetectVisualmarksServiceResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.error_msgs !== undefined) {
      resolved.error_msgs = msg.error_msgs;
    }
    else {
      resolved.error_msgs = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: DetectVisualmarksServiceRequest,
  Response: DetectVisualmarksServiceResponse,
  md5sum() { return '84a42aecf1bc0da0892742376c271be7'; },
  datatype() { return 'map_manager_msgs/DetectVisualmarksService'; }
};
