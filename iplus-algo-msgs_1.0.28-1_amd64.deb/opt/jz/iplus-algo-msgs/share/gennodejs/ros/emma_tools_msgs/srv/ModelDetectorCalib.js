// Auto-generated. Do not edit!

// (in-package emma_tools_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class ModelDetectorCalibRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.json_string = null;
      this.tag2map = null;
      this.tag2opti = null;
    }
    else {
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
      if (initObj.hasOwnProperty('tag2map')) {
        this.tag2map = initObj.tag2map
      }
      else {
        this.tag2map = [];
      }
      if (initObj.hasOwnProperty('tag2opti')) {
        this.tag2opti = initObj.tag2opti
      }
      else {
        this.tag2opti = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ModelDetectorCalibRequest
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    // Serialize message field [tag2map]
    // Serialize the length for message field [tag2map]
    bufferOffset = _serializer.uint32(obj.tag2map.length, buffer, bufferOffset);
    obj.tag2map.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [tag2opti]
    // Serialize the length for message field [tag2opti]
    bufferOffset = _serializer.uint32(obj.tag2opti.length, buffer, bufferOffset);
    obj.tag2opti.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Point.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ModelDetectorCalibRequest
    let len;
    let data = new ModelDetectorCalibRequest(null);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [tag2map]
    // Deserialize array length for message field [tag2map]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tag2map = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tag2map[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [tag2opti]
    // Deserialize array length for message field [tag2opti]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.tag2opti = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.tag2opti[i] = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.json_string.length;
    length += 24 * object.tag2map.length;
    length += 24 * object.tag2opti.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/ModelDetectorCalibRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '999c0e4307bcf5e18665479ac85ac503';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string json_string
    geometry_msgs/Point[] tag2map
    geometry_msgs/Point[] tag2opti
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ModelDetectorCalibRequest(null);
    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    if (msg.tag2map !== undefined) {
      resolved.tag2map = new Array(msg.tag2map.length);
      for (let i = 0; i < resolved.tag2map.length; ++i) {
        resolved.tag2map[i] = geometry_msgs.msg.Point.Resolve(msg.tag2map[i]);
      }
    }
    else {
      resolved.tag2map = []
    }

    if (msg.tag2opti !== undefined) {
      resolved.tag2opti = new Array(msg.tag2opti.length);
      for (let i = 0; i < resolved.tag2opti.length; ++i) {
        resolved.tag2opti[i] = geometry_msgs.msg.Point.Resolve(msg.tag2opti[i]);
      }
    }
    else {
      resolved.tag2opti = []
    }

    return resolved;
    }
};

class ModelDetectorCalibResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.succeed = null;
      this.message = null;
      this.map2opti = null;
      this.json_string = null;
    }
    else {
      if (initObj.hasOwnProperty('succeed')) {
        this.succeed = initObj.succeed
      }
      else {
        this.succeed = false;
      }
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
      if (initObj.hasOwnProperty('map2opti')) {
        this.map2opti = initObj.map2opti
      }
      else {
        this.map2opti = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('json_string')) {
        this.json_string = initObj.json_string
      }
      else {
        this.json_string = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ModelDetectorCalibResponse
    // Serialize message field [succeed]
    bufferOffset = _serializer.bool(obj.succeed, buffer, bufferOffset);
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    // Serialize message field [map2opti]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.map2opti, buffer, bufferOffset);
    // Serialize message field [json_string]
    bufferOffset = _serializer.string(obj.json_string, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ModelDetectorCalibResponse
    let len;
    let data = new ModelDetectorCalibResponse(null);
    // Deserialize message field [succeed]
    data.succeed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [map2opti]
    data.map2opti = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [json_string]
    data.json_string = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    length += object.json_string.length;
    return length + 65;
  }

  static datatype() {
    // Returns string type for a service object
    return 'emma_tools_msgs/ModelDetectorCalibResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a2f24427982b62dcd76237523158d347';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool succeed
    string message
    geometry_msgs/Pose map2opti
    string json_string
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ModelDetectorCalibResponse(null);
    if (msg.succeed !== undefined) {
      resolved.succeed = msg.succeed;
    }
    else {
      resolved.succeed = false
    }

    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    if (msg.map2opti !== undefined) {
      resolved.map2opti = geometry_msgs.msg.Pose.Resolve(msg.map2opti)
    }
    else {
      resolved.map2opti = new geometry_msgs.msg.Pose()
    }

    if (msg.json_string !== undefined) {
      resolved.json_string = msg.json_string;
    }
    else {
      resolved.json_string = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: ModelDetectorCalibRequest,
  Response: ModelDetectorCalibResponse,
  md5sum() { return 'cec4bb46ba7c4e6ef7a26adcbef9343e'; },
  datatype() { return 'emma_tools_msgs/ModelDetectorCalib'; }
};
