// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Submap {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.pose = null;
      this.num_range_data = null;
      this.resolution = null;
      this.max = null;
      this.num_x_cells = null;
      this.num_y_cells = null;
      this.cells = null;
      this.finished = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('num_range_data')) {
        this.num_range_data = initObj.num_range_data
      }
      else {
        this.num_range_data = 0;
      }
      if (initObj.hasOwnProperty('resolution')) {
        this.resolution = initObj.resolution
      }
      else {
        this.resolution = 0.0;
      }
      if (initObj.hasOwnProperty('max')) {
        this.max = initObj.max
      }
      else {
        this.max = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('num_x_cells')) {
        this.num_x_cells = initObj.num_x_cells
      }
      else {
        this.num_x_cells = 0;
      }
      if (initObj.hasOwnProperty('num_y_cells')) {
        this.num_y_cells = initObj.num_y_cells
      }
      else {
        this.num_y_cells = 0;
      }
      if (initObj.hasOwnProperty('cells')) {
        this.cells = initObj.cells
      }
      else {
        this.cells = [];
      }
      if (initObj.hasOwnProperty('finished')) {
        this.finished = initObj.finished
      }
      else {
        this.finished = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Submap
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [num_range_data]
    bufferOffset = _serializer.int32(obj.num_range_data, buffer, bufferOffset);
    // Serialize message field [resolution]
    bufferOffset = _serializer.float32(obj.resolution, buffer, bufferOffset);
    // Check that the constant length array field [max] has the right length
    if (obj.max.length !== 2) {
      throw new Error('Unable to serialize array field max - length must be 2')
    }
    // Serialize message field [max]
    bufferOffset = _arraySerializer.float32(obj.max, buffer, bufferOffset, 2);
    // Serialize message field [num_x_cells]
    bufferOffset = _serializer.int32(obj.num_x_cells, buffer, bufferOffset);
    // Serialize message field [num_y_cells]
    bufferOffset = _serializer.int32(obj.num_y_cells, buffer, bufferOffset);
    // Serialize message field [cells]
    bufferOffset = _arraySerializer.uint16(obj.cells, buffer, bufferOffset, null);
    // Serialize message field [finished]
    bufferOffset = _serializer.bool(obj.finished, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Submap
    let len;
    let data = new Submap(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [num_range_data]
    data.num_range_data = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [resolution]
    data.resolution = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [max]
    data.max = _arrayDeserializer.float32(buffer, bufferOffset, 2)
    // Deserialize message field [num_x_cells]
    data.num_x_cells = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [num_y_cells]
    data.num_y_cells = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [cells]
    data.cells = _arrayDeserializer.uint16(buffer, bufferOffset, null)
    // Deserialize message field [finished]
    data.finished = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += 2 * object.cells.length;
    return length + 85;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cartographer_ros_msgs/Submap';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '1873a9328391d7130fd1894c6a9bc510';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Copyright 2016 The Cartographer Authors
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #      http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.
    
    std_msgs/Header header
    geometry_msgs/Pose pose
    int32 num_range_data
    float32 resolution
    float32[2] max
    int32 num_x_cells
    int32 num_y_cells
    uint16[] cells
    bool finished
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Submap(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.num_range_data !== undefined) {
      resolved.num_range_data = msg.num_range_data;
    }
    else {
      resolved.num_range_data = 0
    }

    if (msg.resolution !== undefined) {
      resolved.resolution = msg.resolution;
    }
    else {
      resolved.resolution = 0.0
    }

    if (msg.max !== undefined) {
      resolved.max = msg.max;
    }
    else {
      resolved.max = new Array(2).fill(0)
    }

    if (msg.num_x_cells !== undefined) {
      resolved.num_x_cells = msg.num_x_cells;
    }
    else {
      resolved.num_x_cells = 0
    }

    if (msg.num_y_cells !== undefined) {
      resolved.num_y_cells = msg.num_y_cells;
    }
    else {
      resolved.num_y_cells = 0
    }

    if (msg.cells !== undefined) {
      resolved.cells = msg.cells;
    }
    else {
      resolved.cells = []
    }

    if (msg.finished !== undefined) {
      resolved.finished = msg.finished;
    }
    else {
      resolved.finished = false
    }

    return resolved;
    }
};

module.exports = Submap;
