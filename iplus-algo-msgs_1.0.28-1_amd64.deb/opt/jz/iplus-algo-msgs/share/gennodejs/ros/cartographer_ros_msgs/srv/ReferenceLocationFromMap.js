// Auto-generated. Do not edit!

// (in-package cartographer_ros_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class ReferenceLocationFromMapRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.mapPose = null;
    }
    else {
      if (initObj.hasOwnProperty('mapPose')) {
        this.mapPose = initObj.mapPose
      }
      else {
        this.mapPose = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ReferenceLocationFromMapRequest
    // Serialize message field [mapPose]
    // Serialize the length for message field [mapPose]
    bufferOffset = _serializer.uint32(obj.mapPose.length, buffer, bufferOffset);
    obj.mapPose.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ReferenceLocationFromMapRequest
    let len;
    let data = new ReferenceLocationFromMapRequest(null);
    // Deserialize message field [mapPose]
    // Deserialize array length for message field [mapPose]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.mapPose = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.mapPose[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 56 * object.mapPose.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/ReferenceLocationFromMapRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '02bcda53caf7fe8ea92aa1dabf2e4705';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    geometry_msgs/Pose[] mapPose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ReferenceLocationFromMapRequest(null);
    if (msg.mapPose !== undefined) {
      resolved.mapPose = new Array(msg.mapPose.length);
      for (let i = 0; i < resolved.mapPose.length; ++i) {
        resolved.mapPose[i] = geometry_msgs.msg.Pose.Resolve(msg.mapPose[i]);
      }
    }
    else {
      resolved.mapPose = []
    }

    return resolved;
    }
};

class ReferenceLocationFromMapResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.reference_id = null;
      this.referencePose = null;
      this.worldPose = null;
      this.error_message = null;
    }
    else {
      if (initObj.hasOwnProperty('reference_id')) {
        this.reference_id = initObj.reference_id
      }
      else {
        this.reference_id = [];
      }
      if (initObj.hasOwnProperty('referencePose')) {
        this.referencePose = initObj.referencePose
      }
      else {
        this.referencePose = [];
      }
      if (initObj.hasOwnProperty('worldPose')) {
        this.worldPose = initObj.worldPose
      }
      else {
        this.worldPose = [];
      }
      if (initObj.hasOwnProperty('error_message')) {
        this.error_message = initObj.error_message
      }
      else {
        this.error_message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ReferenceLocationFromMapResponse
    // Serialize message field [reference_id]
    bufferOffset = _arraySerializer.int32(obj.reference_id, buffer, bufferOffset, null);
    // Serialize message field [referencePose]
    // Serialize the length for message field [referencePose]
    bufferOffset = _serializer.uint32(obj.referencePose.length, buffer, bufferOffset);
    obj.referencePose.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [worldPose]
    // Serialize the length for message field [worldPose]
    bufferOffset = _serializer.uint32(obj.worldPose.length, buffer, bufferOffset);
    obj.worldPose.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [error_message]
    bufferOffset = _serializer.string(obj.error_message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ReferenceLocationFromMapResponse
    let len;
    let data = new ReferenceLocationFromMapResponse(null);
    // Deserialize message field [reference_id]
    data.reference_id = _arrayDeserializer.int32(buffer, bufferOffset, null)
    // Deserialize message field [referencePose]
    // Deserialize array length for message field [referencePose]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.referencePose = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.referencePose[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [worldPose]
    // Deserialize array length for message field [worldPose]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.worldPose = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.worldPose[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [error_message]
    data.error_message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.reference_id.length;
    length += 56 * object.referencePose.length;
    length += 56 * object.worldPose.length;
    length += object.error_message.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cartographer_ros_msgs/ReferenceLocationFromMapResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2cea89e67d6cb5f075ce90c49afd2b74';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int32[] reference_id
    geometry_msgs/Pose[] referencePose
    geometry_msgs/Pose[] worldPose
    string error_message
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ReferenceLocationFromMapResponse(null);
    if (msg.reference_id !== undefined) {
      resolved.reference_id = msg.reference_id;
    }
    else {
      resolved.reference_id = []
    }

    if (msg.referencePose !== undefined) {
      resolved.referencePose = new Array(msg.referencePose.length);
      for (let i = 0; i < resolved.referencePose.length; ++i) {
        resolved.referencePose[i] = geometry_msgs.msg.Pose.Resolve(msg.referencePose[i]);
      }
    }
    else {
      resolved.referencePose = []
    }

    if (msg.worldPose !== undefined) {
      resolved.worldPose = new Array(msg.worldPose.length);
      for (let i = 0; i < resolved.worldPose.length; ++i) {
        resolved.worldPose[i] = geometry_msgs.msg.Pose.Resolve(msg.worldPose[i]);
      }
    }
    else {
      resolved.worldPose = []
    }

    if (msg.error_message !== undefined) {
      resolved.error_message = msg.error_message;
    }
    else {
      resolved.error_message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: ReferenceLocationFromMapRequest,
  Response: ReferenceLocationFromMapResponse,
  md5sum() { return '37d5b050180c2d12ab76cffccc0f3da6'; },
  datatype() { return 'cartographer_ros_msgs/ReferenceLocationFromMap'; }
};
