
"use strict";

let IplusPerceptionReq = require('./IplusPerceptionReq.js')
let Model3DTeaching = require('./Model3DTeaching.js')
let DualCameraInitialPose = require('./DualCameraInitialPose.js')
let GetRobotDepthError = require('./GetRobotDepthError.js')
let Model3DGuard = require('./Model3DGuard.js')
let TemplateGenerator = require('./TemplateGenerator.js')
let VisualServoTeaching = require('./VisualServoTeaching.js')
let TextureTeaching = require('./TextureTeaching.js')
let PalletTeaching = require('./PalletTeaching.js')
let TemplatedLaserLocalization = require('./TemplatedLaserLocalization.js')
let TfPerceptionTeaching = require('./TfPerceptionTeaching.js')
let LaserScanMatcher = require('./LaserScanMatcher.js')
let GetLandmarkList = require('./GetLandmarkList.js')
let VModelTeaching = require('./VModelTeaching.js')
let TrayTeaching = require('./TrayTeaching.js')
let PrecisonSingleGet = require('./PrecisonSingleGet.js')
let QRcodeTeaching = require('./QRcodeTeaching.js')
let GetTrajectory = require('./GetTrajectory.js')
let ObstacleStopInfor = require('./ObstacleStopInfor.js')
let DualCameraPoseTeaching = require('./DualCameraPoseTeaching.js')
let CommonInterface = require('./CommonInterface.js')
let IbvsTeaching = require('./IbvsTeaching.js')
let AlertRegion = require('./AlertRegion.js')
let PrecisionCheck = require('./PrecisionCheck.js')
let Laser3DTeaching = require('./Laser3DTeaching.js')

module.exports = {
  IplusPerceptionReq: IplusPerceptionReq,
  Model3DTeaching: Model3DTeaching,
  DualCameraInitialPose: DualCameraInitialPose,
  GetRobotDepthError: GetRobotDepthError,
  Model3DGuard: Model3DGuard,
  TemplateGenerator: TemplateGenerator,
  VisualServoTeaching: VisualServoTeaching,
  TextureTeaching: TextureTeaching,
  PalletTeaching: PalletTeaching,
  TemplatedLaserLocalization: TemplatedLaserLocalization,
  TfPerceptionTeaching: TfPerceptionTeaching,
  LaserScanMatcher: LaserScanMatcher,
  GetLandmarkList: GetLandmarkList,
  VModelTeaching: VModelTeaching,
  TrayTeaching: TrayTeaching,
  PrecisonSingleGet: PrecisonSingleGet,
  QRcodeTeaching: QRcodeTeaching,
  GetTrajectory: GetTrajectory,
  ObstacleStopInfor: ObstacleStopInfor,
  DualCameraPoseTeaching: DualCameraPoseTeaching,
  CommonInterface: CommonInterface,
  IbvsTeaching: IbvsTeaching,
  AlertRegion: AlertRegion,
  PrecisionCheck: PrecisionCheck,
  Laser3DTeaching: Laser3DTeaching,
};
